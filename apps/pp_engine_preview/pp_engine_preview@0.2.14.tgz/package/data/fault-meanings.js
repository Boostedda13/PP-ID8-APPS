'use strict';

// Factual summaries of BMW fault codes. Source bulletins are listed in PROJECT-NOTES.md.
const engine = {
    '11A002': 'High-pressure fuel supply fell below the expected pressure.',
    '118001': 'The fuel and air mixture is too lean.',
    '118002': 'The fuel and air mixture is too rich.',
    '118401': 'The mixture is substantially leaner than commanded.',
    '120208': 'Measured boost is higher than the control system expects.',
    '120308': 'Measured boost is below the requested pressure.',
    '120408': 'Boost control was disabled, preventing pressure from building.',
    '123518': 'The second electronic turbo wastegate was difficult to move.',
    '140001': 'Fuel injection stopped after multiple cylinders misfired.',
    '140010': 'Misfires registered on more than one cylinder.',
    '140101': 'Fuel injection stopped in cylinder 1 after a misfire.',
    '140110': 'Cylinder 1 misfire detected.',
    '140201': 'Fuel injection stopped in cylinder 2 after a misfire.',
    '140210': 'Cylinder 2 misfire detected.',
    '140301': 'Fuel injection stopped in cylinder 3 after a misfire.',
    '140310': 'Cylinder 3 misfire detected.',
    '140401': 'Fuel injection stopped in cylinder 4 after a misfire.',
    '140410': 'Cylinder 4 misfire detected.',
    '140510': 'Cylinder 5 misfire detected.',
    '140610': 'Cylinder 6 misfire detected.',
    '190302': 'The fuel vapor system detected a small leak above its 0.5 mm threshold.',
    '191C02': 'Fault at the second discharge point of the fuel-tank ventilation system.',
    '195014': 'The fuel tank vent valve differential pressure reading stayed fixed.',
    '1A2806': 'The engine cooling fan reported limited operation.',
    '1A4007': 'The reported cooling fan operating mode was implausible.',
    '1E0101': 'Idle speed was too high on a cold start.',
    '1F053C': 'Acceleration exceeded the limit monitored by the drive safety function.',
    '1F140A': 'The drive safety monitor detected unrequested acceleration from a stop.',
    CDB804: 'The engine controller did not receive the climate system request.',
    'CDBA3B': 'Fuel level and remaining range message missing on the vehicle network.',
};

module.exports = {
    0x01: {
        '930949': 'The driver knee airbag circuit is shorted to ground.',
        '93094F': 'The passenger knee airbag circuit is shorted to ground.',
        '93094C': 'The driver knee airbag circuit resistance is too high.',
        '930952': 'The passenger knee airbag circuit resistance is too high.',
    },
    0x12: engine,
    0x13: engine,
    0x18: {
        '420041': 'The transmission pressure control valve C circuit is open or shorted to ground.',
    },
    0x29: {
        '480705': 'Internal ASG hardware fault reported in the brake control electronics.',
        '480706': 'Internal ASG hardware fault reported by the brake controller.',
    },
    0x40: {
        '80402F': 'The body controller recorded a fully discharged battery.',
        '80411B': 'The body controller detected a fault in the left luggage-compartment antenna circuit.',
        '80422D': 'The body controller did not detect the secondary self-leveling suspension unit.',
        '8044FC': 'The body controller detected an unexpected number of interior lights on LIN bus 2.',
    },
    0x63: {
        B7F856: 'The head unit recorded a DVD drive hardware fault.',
        B7F8E5: 'Head unit debug mode is active.',
        B7F8F9: 'The head unit recorded a watchdog reset.',
    },
};
