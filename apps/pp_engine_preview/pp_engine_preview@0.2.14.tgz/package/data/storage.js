'use strict';

const fs = require('fs');

function read(file) {
    try {
        const data = JSON.parse(fs.readFileSync(file, 'utf8'));
        if (data && typeof data === 'object' && !Array.isArray(data)) return data;
    } catch (error) { /* Optional app data may be missing or invalid. */ }
    return {};
}

function write(file, value) {
    const temporary = file + '.tmp';
    try {
        fs.writeFileSync(temporary, JSON.stringify(value));
        fs.renameSync(temporary, file);
    } catch (error) {
        try { fs.unlinkSync(temporary); } catch (cleanupError) { /* Nothing removable. */ }
        console.warn('PP DATA storage:', error.message);
    }
}

module.exports = { read, write };
