'use strict';

const { ReadOnlyDiag } = require('./kit/readonly-diag');
const { OBD, ENUMS } = require('./kit/std');
const { decode } = require('./kit/sgbd');

const DME = 0x12;
const EGS = 0x18;
const MIN_READ_INTERVAL_MS = 500;
const IRREVERSIBLE_REFUSALS = [0x11, 0x12, 0x31];

function uds(id, interval, ecu) { return { id, interval, ecu: ecu || DME, service: 0x22 }; }
function obd(id, interval) { return { id, interval, ecu: DME, service: 0x01 }; }
function key({ ecu, service, id }) { return [ecu, service, id].join('/'); }

class Diagnostics {
    constructor(connect) {
        this.connect = connect;
        this.records = new Map();
        this.generation = 0;
        this.pending = false;
        this.retryAt = 0;
        this.next = 0;
        this.status = 'Not queried';
    }

    reset() {
        this.generation++;
        if (this.link) {
            this.link.cancel();
            this.link.wake();
        }
    }

    async getLink() {
        if (this.link) return this.link;
        if (this.connecting) return this.connecting;
        this.connecting = this.initialize();
        try {
            return await this.connecting;
        } finally {
            this.connecting = null;
        }
    }

    async initialize() {
        let subscribed = false;
        const signals = {
            proxy: (name, instance) => this.connect(name, instance, { timeoutMs: 5000 }),
            on: async (proxy, event, receive) => {
                await proxy[event].subscribe(receive);
                subscribed = true;
            },
            onAvailable: (proxy, report) => report(subscribed),
            call: (proxy, method, args) => proxy[method](args),
        };
        const link = new ReadOnlyDiag(signals, console, { gapMs: 150, silentAfter: 3 });
        await link.init();
        if (!subscribed) throw new Error('TASU response subscription unavailable');
        this.link = link;
        return link;
    }

    get faultScanReadyAt() { return this.link ? this.link.faultScanReadyAt : 0; }

    get mhdReadyAt() { return this.link ? this.link.mhdReadyAt : 0; }

    scanFaults(beforeSend) { return this.operation((link) => link.scanFaults(beforeSend)); }

    identifyFaultUnits(beforeSend) { return this.operation((link) => link.identifyFaultUnits(beforeSend)); }

    clearFaults(target, beforeSend) { return this.operation((link) => link.clearFaults(target, beforeSend)); }

    adjustMhd(selector, value, beforeSend) {
        return this.operation((link) => link.adjustMhd(selector, value, beforeSend));
    }

    async operation(request) {
        const generation = this.generation;
        const link = await this.getLink();
        if (generation !== this.generation) return undefined;
        return request(link);
    }

    hasRequested(request) { return this.records.has(key(request)); }

    tick(requests, now, preferred = []) {
        if (this.pending || now < this.retryAt || now < this.next || !requests.length) return;
        for (const request of preferred) {
            if (!request) continue;
            const record = this.records.get(key(request));
            const dueAfterSuccess = record && record.at >= record.startedAt && now >= record.startedAt + request.interval;
            if (!record || record.next <= now || dueAfterSuccess) {
                this.poll(request, this.generation, now);
                return;
            }
        }
        // Prefer the longest overdue request so slow pages remain fair to every field.
        let due;
        let earliest = Infinity;
        for (const request of requests) {
            const record = this.records.get(key(request));
            const at = record ? record.next : 0;
            if (at <= now && at < earliest) { earliest = at; due = request; }
        }
        if (!due) return;
        this.poll(due, this.generation, now);
    }

    async poll(request, generation, now) {
        this.pending = true;
        const id = key(request);
        const record = this.records.get(id) || {};
        record.startedAt = now;
        record.next = now + request.interval;
        this.records.set(id, record);
        try {
            if (!this.link) {
                this.status = 'Connecting';
                await this.getLink();
            }
            if (generation !== this.generation) return;
            const { ecu, service, id: identifier } = request;
            if (this.link.silent(ecu)) this.link.wake(ecu);
            const reply = service === 0x22 ? await this.link.read(ecu, identifier, 1000)
                : await this.link.physical(ecu, 0x01, [identifier], 1000,
                    (data) => (data[0] === 0x41 && data[1] === identifier) || (data[0] === 0x7f && data[1] === 1));
            if (generation !== this.generation) return;
            if (!reply) {
                this.status = 'Waiting for ECU';
                if (this.link.silent(ecu)) {
                    if (request.optional) record.next = Math.max(record.next, Date.now() + 10000);
                    else this.retryAt = Date.now() + 10000;
                }
            } else if (reply[0] === 0x7f) {
                this.status = 'ECU connected';
                if (IRREVERSIBLE_REFUSALS.includes(reply[2])) {
                    record.reply = undefined;
                    record.next = Infinity;
                }
            } else {
                this.status = 'ECU connected';
                record.reply = reply;
                record.at = Date.now();
            }
        } catch (error) {
            this.status = 'Diagnostic service unavailable';
            if (request.optional && this.link) record.next = Math.max(record.next, Date.now() + 15000);
            else this.retryAt = Date.now() + 15000;
        } finally {
            this.pending = false;
            this.next = Math.max(now + MIN_READ_INTERVAL_MS, Date.now() + 150);
        }
    }

    reply(request, now, maxAge) {
        const record = this.records.get(key(request));
        return record && now - record.at < maxAge ? record.reply : undefined;
    }

    obdValue(pid, now, maxAge = 15000) {
        const definition = OBD['OBD ' + pid.toString(16).toUpperCase().padStart(2, '0')];
        const reply = this.reply(obd(pid), now, maxAge);
        const values = definition && decode(definition, reply, ENUMS);
        return values && values[0] ? values[0].value : undefined;
    }
}

module.exports = { Diagnostics, uds, obd, DME, EGS, key };
