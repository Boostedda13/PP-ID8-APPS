'use strict';

const path = require('path');
const { FAULTS } = require('./kit/readonly-diag');
const { hex, parseDtcReply, statusInfo } = require('./kit/diag');
const MEANINGS = require('./fault-meanings');
const { read: readData, write: writeData } = require('./storage');

// ReadDTCInformation and status priority follow IterioDev Fault Codes 1.2.0.
const UNITS = {
    0x01: 'Airbag', 0x06: 'Camera', 0x10: 'Gateway', 0x12: 'Engine', 0x13: 'Engine 2',
    0x18: 'Transmission', 0x29: 'Stability control', 0x30: 'Steering', 0x37: 'Audio',
    0x38: 'Transfer case', 0x40: 'Body controller', 0x56: 'Roof', 0x5D: 'Driver assistance',
    0x60: 'Instrument cluster', 0x61: 'Telematics', 0x63: 'Head unit', 0x64: 'Parking assistance',
    0x76: 'Dampers', 0x78: 'Climate',
};
const UNITS_PER_PAGE = 6;
const CODES_PER_PAGE = 4;
const RESCAN_DELAY_MS = 1500;
const IDLE = { text: '', tone: 'ready' };

function decodeScan(replies) {
    const units = [];
    let read = 0;
    let count = 0;
    for (const [address, reply] of replies) {
        // An incomplete positive record cannot prove that a module is clean.
        if (reply.length < 3 || (reply.length - 3) % 4 !== 0) continue;
        const result = parseDtcReply(reply, FAULTS);
        if (!result.ok) continue;
        read++;
        if (!result.dtcs.length) continue;
        count += result.dtcs.length;
        const codes = result.dtcs.map(({ code, status }) => {
            const { label, sev } = statusInfo(status);
            return { code, label, severity: sev, status, flag: '0x' + hex(status) };
        });
        codes.sort((a, b) => (b.status & 1) - (a.status & 1) || a.code.localeCompare(b.code));
        units.push({ address, codes });
    }
    units.sort((a, b) => b.codes.length - a.codes.length || a.address - b.address);
    return { units, count, read, incomplete: replies.size - read };
}

function unitIndex(reply) {
    if (!reply || reply.length < 6 || reply[0] !== 0x62 || reply[1] !== 0xF1 || reply[2] !== 0x50) return '';
    return hex((reply[3] << 16) | (reply[4] << 8) | reply[5], 6);
}

function displayText(text) {
    return typeof text === 'string' ? text.replace(/[^\x20-\x7E]/g, ' ').replace(/ +/g, ' ').trim() : '';
}

class Faults {
    constructor(diagnostics, dataDirectory, blockReason) {
        this.diagnostics = diagnostics;
        this.dataDirectory = dataDirectory;
        this.historyFile = path.join(dataDirectory, 'pp-last-fault-scan.json');
        this.lastScan = undefined;
        this.blockReason = blockReason;
        this.indices = new Map();
        this.operation = null;
        this.confirmation = null;
        this.rescan = null;
        this.result = null;
        this.unitPage = 0;
        this.codePage = 0;
        this.selected = null;
        this.status = IDLE;
    }

    requireReady(operation) {
        const reason = this.operation === operation ? this.blockReason(Date.now(), operation.parked) : { text: 'Fault operation stopped' };
        if (reason) {
            const error = new Error(reason.text);
            error.code = 'FAULT_OPERATION_BLOCKED';
            throw error;
        }
    }

    canStart(now, parked) {
        return !this.operation && !this.confirmation && !this.rescan &&
            now >= this.diagnostics.faultScanReadyAt && !this.blockReason(now, parked);
    }

    async start(clearStatus) {
        const parked = !!clearStatus;
        if (!this.canStart(Date.now(), parked)) return;
        const prefix = clearStatus ? clearStatus.text + ' · ' : '';
        const scan = { kind: 'scan', parked };
        this.operation = scan;
        this.result = null;
        this.unitPage = this.codePage = 0;
        this.selected = null;
        this.status = { text: prefix + 'Reading fault memory...', tone: 'info' };
        const beforeSend = () => this.requireReady(scan);
        try {
            const replies = await this.diagnostics.scanFaults(beforeSend);
            if (this.operation !== scan || !replies) return;
            const result = decodeScan(replies);
            const newUnits = result.units.filter(({ address }) => !this.indices.has(address));
            if (newUnits.length) {
                this.status = { text: prefix + 'Identifying control units...', tone: 'info' };
                try {
                    const identities = await this.diagnostics.identifyFaultUnits(beforeSend);
                    if (this.operation !== scan) return;
                    if (identities) {
                        for (const { address } of newUnits) {
                            const index = unitIndex(identities.get(address));
                            if (index) this.indices.set(address, index);
                        }
                    }
                } catch (error) {
                    if (this.operation !== scan) return;
                    if (error.code === 'FAULT_OPERATION_BLOCKED') throw error;
                    console.warn('PP DATA fault unit identification:', error.message);
                }
            }
            if (this.operation !== scan) return;
            this.result = this.describe(result);
            this.selected = this.result.units.length ? this.result.units[0].address : null;
            const { count, read, incomplete } = result;
            if (read) {
                this.lastScan = { at: Date.now(), count, modules: read };
                writeData(this.historyFile, this.lastScan);
            }
            this.status = {
                text: prefix + (replies.size ? `${count} codes · ${read} modules read` + (incomplete ? ` · ${incomplete} incomplete` : '')
                    : 'No control units answered · check ignition'),
                tone: !read || incomplete || (clearStatus && clearStatus.tone === 'warning') ? 'warning' : 'ready',
            };
        } catch (error) {
            if (this.operation === scan) {
                this.status = {
                    text: prefix + (error.code === 'FAULT_OPERATION_BLOCKED' ? 'Scan stopped · ' + error.message : 'Scan unavailable · try again'),
                    tone: 'error',
                };
                if (error.code !== 'FAULT_OPERATION_BLOCKED') console.warn('PP DATA fault scan:', error.message);
            }
        } finally {
            if (this.operation === scan) this.operation = null;
        }
    }

    requestClear(all) {
        if (!this.result || !this.canStart(Date.now(), true)) return;
        const targets = this.result.units.filter((unit) => all || unit.address === this.selected);
        if (!targets.length) return;
        const target = all ? `${targets.length} control unit${targets.length === 1 ? '' : 's'}`
            : `${targets[0].name} (${targets[0].addressLabel})`;
        this.confirmation = { target, targets };
    }

    async confirmClear() {
        const confirmation = this.confirmation;
        if (!confirmation) return;
        this.confirmation = null;
        if (!this.canStart(Date.now(), true)) return;
        const clear = { kind: 'clear', parked: true, count: confirmation.targets.length, accepted: 0, sent: 0 };
        this.operation = clear;
        this.result = null;
        this.selected = null;
        const beforeSend = () => { this.requireReady(clear); clear.sent++; };
        try {
            for (const unit of confirmation.targets) {
                this.requireReady(clear);
                this.status = { text: `Clearing ${unit.name} (${unit.addressLabel})...`, tone: 'info' };
                try {
                    const reply = await this.diagnostics.clearFaults(unit.address, beforeSend);
                    if (this.operation !== clear) return;
                    if (reply && reply[0] === 0x54) clear.accepted++;
                } catch (error) {
                    if (this.operation !== clear) return;
                    if (error.code === 'FAULT_OPERATION_BLOCKED') throw error;
                    console.warn('PP DATA fault clear', unit.addressLabel + ':', error.message);
                }
            }
            const status = { text: this.clearSummary(clear), tone: clear.accepted === clear.count ? 'ready' : 'warning' };
            if (clear.sent) this.rescan = { at: Date.now() + RESCAN_DELAY_MS, status };
            this.status = clear.sent ? { text: status.text + ' · preparing rescan', tone: 'info' } : status;
        } catch (error) {
            if (this.operation === clear) this.status = {
                text: this.clearSummary(clear) + ' · ' + error.message, tone: 'error',
            };
        } finally {
            if (this.operation === clear) this.operation = null;
        }
    }

    clearSummary({ accepted, count }) { return `Clear accepted by ${accepted} of ${count} units`; }

    cancel(reason) {
        const { operation, rescan, confirmation } = this;
        this.operation = this.rescan = this.confirmation = null;
        if (operation) {
            const text = operation.kind === 'clear' ? this.clearSummary(operation) + ' · Clear stopped' : 'Scan stopped';
            this.status = { text: reason ? text + ' · ' + reason.text : text, tone: 'error' };
        } else if (rescan) this.status = { text: rescan.status.text + ' · Rescan cancelled', tone: 'warning' };
        return !!(operation || rescan || confirmation);
    }

    describe(result) {
        if (!result.units.length) return result;
        const overrides = readData(path.join(this.dataDirectory, 'fault-texts.json'));
        const local = path.join(this.dataDirectory, 'fault-texts');
        const variants = readData(path.join(local, 'sgbd_index.json'));
        const names = readData(path.join(local, 'unit_names.json'));
        const codesByAddress = readData(path.join(local, 'dtc_texts.json'));
        const codesByVariant = new Map();
        for (const unit of result.units) {
            const { address } = unit;
            const addressHex = hex(address);
            const index = this.indices.get(address);
            const customUnit = index && overrides.modules && overrides.modules[`${addressHex}:${index}`];
            const variant = index && variants[`${addressHex} ${index}`];
            if (typeof variant === 'string' && /^[\w-]{1,64}$/.test(variant) && !codesByVariant.has(variant)) {
                codesByVariant.set(variant, readData(path.join(local, 'texts', variant + '.json')));
            }
            const localCodes = codesByVariant.get(variant);
            unit.name = displayText(customUnit && customUnit.name) || displayText(names[variant]) || UNITS[address] || 'ECU';
            unit.addressLabel = '0x' + addressHex;
            unit.index = index || '';
            for (const fault of unit.codes) {
                const key = `${addressHex}:${fault.code}`;
                const specific = customUnit && customUnit.codes && customUnit.codes[fault.code];
                const custom = overrides.codes && overrides.codes[key];
                fault.meaning = displayText(specific) || displayText(custom) ||
                    displayText(codesByAddress[key]) || displayText(localCodes && localCodes[fault.code]) ||
                    (MEANINGS[address] && MEANINGS[address][fault.code]) || 'Description unavailable';
            }
        }
        return result;
    }

    action(id) {
        if (id === 'scan') { this.start(); return; }
        if (id === 'clear-unit' || id === 'clear-all') { this.requestClear(id === 'clear-all'); return; }
        if (id === 'clear-confirm') { this.confirmClear(); return; }
        if (id === 'clear-cancel') { this.confirmation = null; return; }
        if (this.confirmation) return;
        const units = this.result ? this.result.units : [];
        if (id.indexOf('fault-unit:') === 0) {
            const address = Number(id.slice(11));
            if (units.some((unit) => unit.address === address)) {
                this.selected = address;
                this.codePage = 0;
            }
            return;
        }
        const selected = units.find(({ address }) => address === this.selected);
        if (id === 'previous' && this.codePage > 0) this.codePage--;
        if (id === 'next' && selected && (this.codePage + 1) * CODES_PER_PAGE < selected.codes.length) this.codePage++;
        if (id === 'unit-previous' && this.unitPage > 0) this.unitPage--;
        if (id === 'unit-next' && (this.unitPage + 1) * UNITS_PER_PAGE < units.length) this.unitPage++;
    }

    update(now) {
        const scanBlocked = this.blockReason(now, false);
        const clearBlocked = scanBlocked || this.blockReason(now, true);
        const needsParked = this.confirmation || this.rescan || (this.operation && this.operation.parked);
        const blocked = needsParked ? clearBlocked : scanBlocked;
        if (blocked && this.cancel(blocked)) this.diagnostics.reset();
        if (!clearBlocked && this.rescan && now >= this.rescan.at) {
            const { status } = this.rescan;
            this.rescan = null;
            this.start(status);
        }
        return this.view(now, scanBlocked, clearBlocked);
    }

    view(now, scanBlocked, clearBlocked) {
        if (this.lastScan === undefined) {
            const { at, count, modules } = readData(this.historyFile);
            const valid = Number.isSafeInteger(at) && at > 0 && Number.isFinite(new Date(at).getTime()) &&
                Number.isSafeInteger(count) && count >= 0 && Number.isSafeInteger(modules) && modules > 0;
            this.lastScan = valid ? { at, count, modules } : null;
        }
        const units = this.result ? this.result.units : [];
        const selected = units.find(({ address }) => address === this.selected);
        const codes = selected ? selected.codes : [];
        const codeStart = this.codePage * CODES_PER_PAGE;
        const unitStart = this.unitPage * UNITS_PER_PAGE;
        const waiting = now < this.diagnostics.faultScanReadyAt;
        const clearing = this.operation && this.operation.kind === 'clear';
        const busy = !!this.operation || !!this.rescan || waiting;
        const canScan = !scanBlocked && !busy && !this.confirmation;
        const canClear = !clearBlocked && !busy;
        const controls = this.confirmation ? [
            { id: 'clear-cancel', label: 'Cancel', tone: 'info' },
            { id: 'clear-confirm', label: 'Confirm Clear', tone: 'error' },
        ] : [
            { id: 'scan', label: this.operation ? (clearing ? 'Clearing...' : 'Scanning...') : 'Scan',
                tone: canScan ? 'ready' : 'warning', disabled: !canScan },
            { id: 'clear-unit', label: 'Clear Unit', tone: 'error', disabled: !canClear || !selected },
            { id: 'clear-all', label: 'Clear All', tone: 'error', disabled: !canClear || units.length < 2 },
        ];
        let status = this.status;
        if (scanBlocked) status = scanBlocked;
        else if (this.confirmation) status = { text: 'Clear awaiting confirmation', tone: 'warning' };
        else if (waiting && !this.operation && !this.rescan) status = { text: 'Previous diagnostic request still settling', tone: 'warning' };
        let message = '';
        if (this.result && this.result.read) message = 'No pending or confirmed codes in the responding modules';
        return {
            subtitle: status.text,
            faults: {
                statusTone: status.tone,
                canScan,
                clearWarning: scanBlocked ? null : clearBlocked,
                lastScan: this.lastScan,
                controls,
                codePaginated: codes.length > CODES_PER_PAGE,
                codePrevious: codeStart > 0,
                codeNext: codeStart + CODES_PER_PAGE < codes.length,
                units: units.slice(unitStart, unitStart + UNITS_PER_PAGE).map((unit) => ({
                    address: unit.address, addressLabel: unit.addressLabel, name: unit.name,
                    count: unit.codes.length, selected: unit.address === this.selected,
                })),
                unitPrevious: this.unitPage > 0,
                unitNext: unitStart + UNITS_PER_PAGE < units.length,
                heading: selected ? `${selected.name} · ${selected.addressLabel}` + (selected.index ? ` · ${selected.index}` : '') : '',
                codes: codes.slice(codeStart, codeStart + CODES_PER_PAGE),
                message,
                confirmation: this.confirmation ? this.confirmation.target : '',
            },
        };
    }
}

module.exports = Faults;
