'use strict';

// Canonical readings and saved scale settings stay in their original units.
const SAE = {
    '°C': ['°F', 1.8, 32],
    bar: ['psi', 14.5037738],
    hPa: ['psi', 0.0145037738],
    Nm: ['lb-ft', 0.737562149],
    'km/h': ['mph', 0.621371192],
    km: ['mi', 0.621371192],
    l: ['gal', 1 / 3.785411784],
    'l/h': ['gal/h', 1 / 3.785411784],
    'L/h': ['gal/h', 1 / 3.785411784],
};

function displayUnit(unit, sae) {
    return sae && SAE[unit] ? SAE[unit][0] : unit;
}

function toDisplay(value, unit, sae, difference = false) {
    if (!sae || !SAE[unit]) return value;
    const [, factor, offset = 0] = SAE[unit];
    return value * factor + (difference ? 0 : offset);
}

function fromDisplay(value, unit, sae, difference = false) {
    if (!sae || !SAE[unit]) return value;
    const [, factor, offset = 0] = SAE[unit];
    return (value - (difference ? 0 : offset)) / factor;
}

module.exports = { displayUnit, toDisplay, fromDisplay };
