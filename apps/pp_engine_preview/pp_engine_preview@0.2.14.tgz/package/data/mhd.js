'use strict';

const GROUPS = [
    { name: 'Map', selector: 1, labels: ['1', '2', '3', '4'] },
    { name: 'Exhaust', selector: 2, labels: ['OEM', 'Open', 'Closed'] },
    { name: 'Max Cooling', selector: 3, labels: ['Off', 'On'] },
];
class Mhd {
    constructor(diagnostics, canAdjust) {
        this.diagnostics = diagnostics;
        this.canAdjust = canAdjust;
        this.accepted = [];
        this.unsupported = new Set();
        this.cancel();
    }

    cancel() {
        this.pending = null;
    }

    view() {
        const coolingReady = this.canAdjust(true);
        const action = this.pending;
        const ready = !action && Date.now() >= this.diagnostics.mhdReadyAt;
        const groups = GROUPS.map(({ name, selector, labels }) => ({
            name,
            controls: labels.map((label, value) => ({
                id: 'mhd:' + selector + ':' + value,
                label,
                active: this.accepted[selector] === value,
                pending: !!action && action.selector === selector && action.value === value,
                enabled: ready && !this.unsupported.has(selector + ':' + value) && (selector !== 3 || value !== 1 || coolingReady),
            })),
        }));
        return { groups };
    }

    action(id) {
        if (this.pending || Date.now() < this.diagnostics.mhdReadyAt) return;
        const match = /^mhd:([1-3]):([0-3])$/.exec(id);
        if (!match) return;
        const selector = Number(match[1]);
        const value = Number(match[2]);
        const { labels } = GROUPS[selector - 1];
        if (value >= labels.length || this.unsupported.has(selector + ':' + value)) return;
        if (!this.canAdjust(selector === 3 && value === 1)) return;
        this.send({ selector, value });
    }

    async send(action) {
        const { selector, value } = action;
        this.pending = action;
        const coolingOn = selector === 3 && value === 1;
        try {
            const reply = await this.diagnostics.adjustMhd(selector, value, () => {
                if (this.pending !== action || !this.canAdjust(coolingOn)) throw new Error('Adjustment cancelled before dispatch');
            });
            if (this.pending !== action || !reply) return;
            if (reply[0] === 0x6f) {
                this.accepted[selector] = value;
            } else if (reply[2] === 0x11 || reply[2] === 0x31) {
                this.unsupported.add(selector + ':' + value);
            }
        } catch (error) {
            if (this.pending === action) console.warn('PP DATA MHD:', error.message);
        } finally {
            if (this.pending === action) this.pending = null;
        }
    }
}

module.exports = { Mhd };
