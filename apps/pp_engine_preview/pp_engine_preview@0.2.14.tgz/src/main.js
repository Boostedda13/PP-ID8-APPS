'use strict';

const OnlineApp = require('oap-sdk/src/core/OnlineApp.js');
const someipBuilders = require('oap-sdk/src/someip/someipBuilders');
const path = require('path');
const { id, rows } = require('./engine-config.js');
const { Telemetry, readings } = require('./telemetry.js');
const connect = (name, instance, options) => someipBuilders.buildAndInitTypedProxy(name, instance, options);
const SOURCE = typeof __dirname === 'string' ? path.join(__dirname, '..') :
    path.join('/var/opt/public/oap', 'oap_' + process.getuid(), 'source');
const FOCUS_GRACE_MS = 300;
const RENDERER_RESUME_MS = FOCUS_GRACE_MS + 100;

class EnginePage extends OnlineApp {
    constructor() {
        super();
        this.initialization = null;
        this.entryUuid = null;
        this.stopping = false;
        this.appVisible = true;
        this.screenVisible = false;
        this.focused = true;
        this.focusTimer = null;
        this.rendererResume = null;
        this.fields = {};
        this.painting = false;
        this.dashboard = null;
        this.features = null;
        this.latest = null;
        this.telemetry = new Telemetry(connect, (raw, now) => this.paint(raw, now));
        this.on('initialized', () => {
            if (this.initialization) return;
            this.initialization = this.setup().catch((error) => console.error('PP DATA setup:', error.message));
        });
        this.on('entryPointExecute', (uuid) => {
            if (!this.initialization) return;
            this.initialization.then(() => this.open(uuid))
                .catch((error) => console.error('PP DATA open:', error.message));
        });
        this.on('shutdown', () => this.stop());
        this.on('changeVisibility', (event) => {
            if (!event || event.visible == null) return;
            const visible = flag(event.visible);
            if (visible === this.appVisible) return;
            this.appVisible = visible;
            this.updateTelemetry();
        });
        this.on('error', (error) => console.error('PP DATA:', error.message));
    }

    async setup() {
        const rhmi = this.rhmiApplication;
        if (!rhmi) return this.initialized();

        const screen = rhmi.getByName('ENGINE');
        if (!screen) throw new Error('ENGINE state unavailable');
        await screen.updateResources();
        try {
            // The Store links this file into javascript/app.js. The renderer is loaded from the installed package.
            const { EngineDashboard } = require(path.join(SOURCE, 'renderer', 'dashboard.js'));
            const { Features } = require(path.join(SOURCE, 'data', 'features.js'));
            this.features = new Features(connect, path.join(SOURCE, '..', 'data'),
                (now, parked) => this.faultBlockReason(now, parked),
                (coolingOn) => this.canAdjustMhd(coolingOn));
            this.dashboard = new EngineDashboard(id, (action, held) => {
                if (!this.latest || !this.isActive() || this.focusTimer) return false;
                const page = this.features.page;
                const changed = this.features.action(action, held);
                if (held && !changed) return false;
                if (this.features.page !== page) this.telemetry.show(this.features.page);
                else this.paint(...this.latest);
                return true;
            }, () => {
                this.pauseActions();
                this.scheduleRendererResume();
            }, () => this.features.flushSettings());
        } catch (error) {
            console.warn('PP DATA dashboard unavailable:', error.message);
        }
        for (const key of Object.keys(rows)) {
            const component = rhmi.getByName('METRIC_' + key.toUpperCase());
            if (component) this.fields[key] = { component, shown: null };
        }
        screen.on('visible', (event) => this.setScreenVisible(!!event && flag(event.visible)));
        screen.on('focus', (event) => {
            clearTimeout(this.focusTimer);
            this.focusTimer = null;
            if (event && flag(event.focus)) {
                this.focused = true;
                this.updateTelemetry();
            } else if (this.screenVisible) {
                this.pauseActions();
                // HMI transitions briefly drop focus. Pause only for sustained focus loss.
                this.focusTimer = setTimeout(() => {
                    this.focusTimer = null;
                    this.focused = false;
                    this.updateTelemetry();
                }, FOCUS_GRACE_MS);
            }
        });

        const descriptor = this.appDescription.application.entryPoints[0];
        const entry = this.getEntryPoints().find((item) => item.getDescription().uuid === descriptor.uuid);
        if (entry) {
            await entry.init();
            await rhmi.mapEntryState(descriptor.uuid, screen);
            try {
                await entry.entryPoint.setText(descriptor.textId);
                await entry.entryPoint.setIcon(descriptor.icon);
            } catch (error) {
                console.warn('PP DATA tile resources:', error.message);
            }
            await entry.setAvailability('ENABLED');
            this.entryUuid = descriptor.uuid;
        }

        const lastEntry = this.getLastExecutedEntryPointUuid && this.getLastExecutedEntryPointUuid();
        const visibility = this.getVisibilityData && this.getVisibilityData();
        if (lastEntry || (visibility && visibility.visible)) {
            try {
                await this.registerActive();
            } catch (error) {
                console.warn('PP DATA active status:', error.message);
            }
        }
        await this.initialized();
        if (lastEntry) await this.open(lastEntry);
    }

    async open(uuid) {
        if (this.stopping || !this.entryUuid || uuid !== this.entryUuid) return;
        await this.rhmiApplication.openEntryState(uuid);
    }

    setScreenVisible(visible) {
        if (visible === this.screenVisible) return;
        clearTimeout(this.focusTimer);
        this.focusTimer = null;
        this.screenVisible = visible;
        if (visible) {
            // A newly shown RHMI screen can be the first foreground event on re-entry.
            this.appVisible = true;
            this.focused = true;
        }
        this.updateTelemetry();
    }

    isActive() {
        return this.appVisible && this.screenVisible && this.focused && !this.stopping;
    }

    faultBlockReason(now, parked) {
        if (!this.isActive() || this.focusTimer || !this.features || this.features.page !== 'faults' ||
            !this.dashboard || !this.dashboard.client || !this.dashboard.client.ready || !this.dashboard.client.visible) {
            return { text: 'Open the Fault Codes tab', tone: 'warning' };
        }
        return parked ? this.telemetry.faultBlockReason(now) : null;
    }

    canAdjustMhd(coolingOn) {
        const client = this.dashboard && this.dashboard.client;
        if (!this.isActive() || this.focusTimer || !client || !client.ready || !client.visible ||
            this.features.page !== 'engine' || !this.features.display.mhdStrip) return false;
        if (!coolingOn) return true;
        const now = Date.now();
        const live = this.telemetry.freshEngineRpm(now);
        const rpm = live === undefined ? this.features.diagnostics.obdValue(0x0c, now, 5000) : live;
        return rpm > 500;
    }

    pauseActions() {
        if (this.dashboard) this.dashboard.cancelPress();
        if (this.features) this.features.cancelMhdOperation();
        if (!this.features || this.features.page !== 'faults') return;
        this.features.cancelFaultOperation();
        this.telemetry.hide();
    }

    updateTelemetry() {
        clearTimeout(this.rendererResume);
        this.rendererResume = null;
        if (this.isActive()) {
            if (this.focusTimer) return;
            if (this.dashboard) this.dashboard.show();
            this.telemetry.show(this.features ? this.features.page : 'engine');
        } else {
            if (this.dashboard) this.dashboard.hide();
            if (this.features && this.latest) this.features.pause();
            this.latest = null;
            this.telemetry.hide();
        }
    }

    scheduleRendererResume() {
        clearTimeout(this.rendererResume);
        this.rendererResume = setTimeout(() => {
            this.rendererResume = null;
            // A tap outside the overlay need not navigate away from the app (for example, the title).
            if (this.isActive() && !this.focusTimer) this.updateTelemetry();
        }, RENDERER_RESUME_MS);
    }

    async paint(raw, now) {
        this.latest = [raw, now];
        const preference = this.features ? this.features.display.override : undefined;
        const values = readings(raw, this.features ? this.features.page : 'engine', preference);
        let view = { page: 'engine', pages: [], engine: values };
        if (this.features) {
            try {
                view = this.features.update(values, raw, now);
            } catch (error) {
                if (!this.featureError) console.warn('PP DATA pages:', error.message);
                this.featureError = true;
            }
        }
        if (this.dashboard && this.dashboard.update(view)) return;
        if (this.painting) return;
        const engine = view.engine || this.features.enginePage(readings(raw, 'engine', preference), raw, now);
        this.painting = true;
        try {
            await Promise.all(Object.keys(this.fields).map(async (key) => {
                const field = this.fields[key];
                const text = rows[key] + '  ' + (engine[key] || '--').replace('°', 'deg ');
                if (field.shown === text) return;
                try {
                    await field.component.setValue(0, 'Text', text, 'Text');
                    field.shown = text;
                } catch (error) {
                    // The state can disappear while the SDK is updating a cell.
                }
            }));
        } finally {
            this.painting = false;
        }
    }

    async stop() {
        if (this.stopping) return;
        this.stopping = true;
        clearTimeout(this.focusTimer);
        this.updateTelemetry();
        try {
            if (this.initialization) await this.initialization;
            await this.destroyBundles();
        } catch (error) {
            console.error('PP DATA shutdown:', error.message);
        }
        process.exit(0);
    }
}

const flag = (value) => value === true || value === 1 || value === 'true' || value === '1';
const app = new EnginePage();
app.start().catch((error) => console.error('PP DATA start:', error.message));
