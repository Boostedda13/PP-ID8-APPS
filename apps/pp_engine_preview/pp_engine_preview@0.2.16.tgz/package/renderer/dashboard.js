'use strict';

const { Recorder, makeLayer, dropLayer } = require('./kit/record');
const { RenderClient } = require('./kit/renderd');
const { ContentGrid, drawTabs, drawEngineStrip, SCREEN, APP } = require('./pages');
const { METRIC_COLORS, THRESHOLD_COLORS } = require('./colors');
const { displayUnit, toDisplay } = require('../data/units');
const { translator } = require('../data/language');

const INSET = 40;
const KEEPALIVE_MS = 1000;
const HOLD_DELAY_MS = 450;
const HOLD_REPEAT_MS = 180;
const BAR_SLOPE = 0.28;
const BAR_EDGE_LENGTH = Math.sqrt(1 + BAR_SLOPE * BAR_SLOPE);

const WHITE = '#ffffff';
const VALUE_FONT = { font: 'value' };
const CARD_LABEL_SIZE = 37;
const INTAKE_BAR_X = 520;
const INTAKE_ROW_H = 72;

const WIDE = { labelY: 68, valueY: 95, size: 89, align: 'right', trackY: 123, trackH: 28, tickY: 196, tickMarks: true, peakY: 103 };
const SMALL = { labelY: 52, valueY: 118, size: 70, trackY: 135, trackH: 20, tickY: 196, tickMarks: true };
const FOOTER = { labelY: 66, valueY: 88, size: 65, align: 'right', trackY: 111, trackH: 9, tickY: 151 };
const FOOTER_READOUT = { labelY: 58, valueY: 134, size: 78 };
const INTAKE = { labelY: 52, valueY: 55, size: 50, trackY: 29, trackH: 15, tickY: 72 };
const SPEED = { labelY: 68, valueY: 179, size: 119 };
const STRIP_STYLES = new Map([
    [WIDE, Object.assign({}, WIDE, { labelY: 57, valueY: 87, trackY: 111, tickY: 177, peakY: 92 })],
    [SMALL, Object.assign({}, SMALL, { labelY: 44, valueY: 103, trackY: 119, tickY: 174 })],
    [SPEED, Object.assign({}, SPEED, { labelY: 57, valueY: 160 })],
]);

const CARDS = [
    { key: 'rpm', label: 'Engine speed', unit: 'rpm', x: 40, y: 78, w: 1780, h: 224,
        style: WIDE, ticks: [0, 2000, 4000, 6000, 8000] },
    { key: 'boost', label: 'Boost', unit: 'bar', x: 40, y: 322, w: 1780, h: 224,
        style: WIDE, ticks: [0, 0.5, 1, 1.5, 2, 2.5] },
    { key: 'power', label: 'Power', unit: 'hp', x: 1840, y: 322, w: 490, h: 224,
        style: SMALL, ticks: [0, 250, 500] },
    { key: 'torque', label: 'Torque', unit: 'Nm', x: 2350, y: 322, w: 490, h: 224,
        style: SMALL, ticks: [0, 350, 700] },
    { key: 'speed', label: 'Vehicle speed', unit: 'km/h', x: 1840, y: 78, w: 1000, h: 224,
        style: SPEED },
    { key: 'oil', label: 'Engine oil', unit: '°C', x: 40, y: 566, w: 560, h: 174,
        style: FOOTER, ticks: [0, 150] },
    { key: 'coolant', label: 'Coolant', unit: '°C', x: 620, y: 566, w: 560, h: 174,
        style: FOOTER, ticks: [0, 130] },
    { key: 'intake', label: 'Intake air', unit: '°C', x: 1200, y: 566, w: 1200, h: 174,
        style: INTAKE, ticks: [0, 80] },
    { key: 'voltage', label: 'Vbatt', unit: 'V', x: 2420, y: 566, w: 420, h: 174, style: FOOTER_READOUT },
];

function barFraction(value, ticks) {
    return (value - ticks[0]) / (ticks[ticks.length - 1] - ticks[0]);
}

function slantedBar(canvas, x, y, width, height, fraction, color) {
    const span = (width - height * BAR_SLOPE) * fraction;
    if (!(span > 0)) return;

    // Round the four vertices by stroking an inset parallelogram with round caps.
    const corner = Math.min(3.5, height * 0.18);
    const radius = Math.min(corner, span / (2 * BAR_EDGE_LENGTH));
    // Keep a very short fill inside the track's rounded leading edge.
    const inset = radius * BAR_EDGE_LENGTH + (corner - radius) * (BAR_EDGE_LENGTH + BAR_SLOPE);
    const topX = x + inset + (height - radius) * BAR_SLOPE;
    const bottomX = x + inset + radius * BAR_SLOPE;
    const top = y + radius;
    const bottom = y + height - radius;
    const innerWidth = span - 2 * radius * BAR_EDGE_LENGTH;
    if (innerWidth < 0.001) {
        canvas.line(topX, top, bottomX, bottom, 2 * radius, color);
        return;
    }
    const corners = [[topX, top], [topX + innerWidth, top],
        [bottomX + innerWidth, bottom], [bottomX, bottom]];
    canvas.quad(corners, color);
    canvas.polyline(corners.concat([corners[0]]), 2 * radius, color);
}

function drawThresholds(canvas, x, y, width, height, ticks, limits) {
    if (!limits) return;
    const fraction = (value) => Number.isFinite(value) ? Math.max(0, Math.min(1, barFraction(value, ticks))) : 1;
    const warn = fraction(limits.warn);
    const alarm = fraction(limits.alarm);
    const span = width - height * BAR_SLOPE;
    // Keep the scale markers outside the live fill, which is drawn after the cached layer.
    const thickness = height < 15 ? 2 : 3;
    const edge = 0.75;
    const mark = (start, end, color) => {
        const length = (end - start) * span;
        if (!(length > 0)) return;
        const left = x + start * span;
        canvas.fillRect(left + height * BAR_SLOPE, y - thickness - edge, length, thickness, color);
        canvas.fillRect(left, y + height + edge, length, thickness, color);
        if (end === 1) {
            const right = x + width + edge;
            const lower = x + span + edge;
            canvas.quad([[right, y - thickness - edge], [right + thickness, y - thickness - edge],
                [lower + thickness, y + height + thickness + edge], [lower, y + height + thickness + edge]], color);
        }
    };
    mark(warn, alarm, THRESHOLD_COLORS.warn);
    mark(alarm, 1, THRESHOLD_COLORS.alarm);
}

function drawScale(canvas, left, y, trackW, style, ticks, limits, tickDigits = 0) {
    const trackY = y + style.trackY;
    slantedBar(canvas, left, trackY, trackW, style.trackH, 1, '#292929');
    drawThresholds(canvas, left, trackY, trackW, style.trackH, ticks, limits);
    ticks.forEach((value, index) => {
        const tickX = left + barFraction(value, ticks) * (trackW - style.trackH * BAR_SLOPE);
        const align = index === 0 ? 'left' : index === ticks.length - 1 ? 'right' : 'center';
        if (style.tickMarks) canvas.fillRect(tickX - 1, trackY + style.trackH + 7, 2, 8, '#8c8c8c');
        const label = String(Number(value.toFixed(tickDigits)));
        canvas.text(label, tickX, y + style.tickY, 26, WHITE, { align, font: 'value' });
    });
}

function drawCard(canvas, { x, y, w, h, label, style, ticks, color, intakeRows, limits, tickDigits }) {
    const left = x + INSET;
    canvas.strokeRoundRect(x, y, w, h, 18, 2, '#282828');
    if (intakeRows) {
        intakeRows.forEach((row, index) => {
            const rowY = y + index * INTAKE_ROW_H;
            canvas.text(row.label, left, rowY + style.labelY, 34, row.color);
            drawScale(canvas, x + INTAKE_BAR_X, rowY, w - INTAKE_BAR_X - INSET, style, row.ticks, row.limits);
        });
        return;
    }
    canvas.text(label, left, y + style.labelY, CARD_LABEL_SIZE, color);
    if (ticks) drawScale(canvas, left, y, w - INSET * 2, style, ticks, limits, tickDigits);
}

function drawValue(canvas, value, unit, size, color, left, right, baseline) {
    const text = value === '--' ? '—' : value;
    const numOptions = { font: 'num' };
    const valueWidth = canvas.textWidth(text, size, numOptions);
    const unitOffset = 18;
    const unitSize = 34;
    const unitWidth = value === '--' ? 0 : unitOffset + canvas.textWidth(unit, unitSize);
    const start = right === null ? left : right - valueWidth - unitWidth;
    canvas.text(text, start, baseline, size, WHITE, numOptions);
    if (unitWidth) canvas.text(unit, start + valueWidth + unitOffset, baseline, unitSize, color);
}

function drawProgress(canvas, value, ticks, x, y, width, height, color) {
    const fraction = Math.max(0, Math.min(1, barFraction(Number(value), ticks)));
    slantedBar(canvas, x, y, width, height, fraction, color);
}

function drawReading(canvas, { x, y, w, key, unit, style, ticks, color, intakeRows }, value, peak, gear, heat, boost, t) {
    if (intakeRows) {
        const readings = [value, heat];
        intakeRows.forEach((row, index) => {
            const rowY = APP.y + y + index * INTAKE_ROW_H;
            drawValue(canvas, readings[index], unit, style.size, row.color, x + INSET, x + INTAKE_BAR_X - 27, rowY + style.valueY);
            drawProgress(canvas, readings[index], row.ticks, x + INTAKE_BAR_X, rowY + style.trackY,
                w - INTAKE_BAR_X - INSET, style.trackH, row.color);
        });
        return;
    }
    const baseline = APP.y + y + style.valueY;
    const right = style.align === 'right' ? x + w - INSET : null;
    drawValue(canvas, value, unit, style.size, color, x + INSET, right, baseline);
    if (Number.isFinite(peak)) {
        const peakValue = key === 'boost' && unit === 'psi' ? String(Math.round(peak)) : peak.toFixed(key === 'boost' ? 2 : 0);
        const size = style.peakY ? 25 : 24;
        const rowY = APP.y + y + (style.peakY || style.labelY);
        const label = t('Peak') + '  ';
        const peakWidth = canvas.textWidth(label, size) + canvas.textWidth(peakValue, size, VALUE_FONT);
        const peakX = style.peakY ? x + INSET : x + w - INSET - peakWidth;
        const advance = canvas.text(label, peakX, rowY, size, color);
        canvas.text(peakValue, peakX + advance, rowY, size, WHITE, VALUE_FONT);
    }
    if (key === 'speed') {
        const edge = x + w - INSET;
        const displayedGear = gear || '—';
        const gearCenter = edge - canvas.textWidth(displayedGear, style.size, { font: 'num' }) / 2;
        canvas.text(t('Gear'), gearCenter, APP.y + y + style.labelY, CARD_LABEL_SIZE, color, { align: 'center' });
        canvas.text(displayedGear, edge, baseline, style.size, WHITE, { align: 'right', font: 'num' });
    }
    // Keep the reading visible at its actual value when it exceeds the bar scale.
    const barValue = key === 'boost' && Number.isFinite(boost) ? boost : value;
    if (ticks) drawProgress(canvas, barValue, ticks, x + INSET, APP.y + y + style.trackY, w - INSET * 2, style.trackH, color);
}

const STRIP_CARDS = CARDS.map((card) => {
    const style = STRIP_STYLES.get(card.style);
    if (!style) return card;
    const top = card.y === 78;
    return Object.assign({}, card, { style, y: top ? 126 : 348, h: top ? 202 : 198 });
});

function inUnits(card, sae, scales, thresholds, t) {
    const unit = displayUnit(card.unit, sae);
    let ticks = card.ticks;
    const max = scales[card.key];
    if (ticks) {
        const min = ticks[0];
        const endpoint = Number.isFinite(max) ? max : ticks[ticks.length - 1];
        ticks = ticks.map((tick) => toDisplay(min + barFraction(tick, ticks) * (endpoint - min), card.unit, sae));
    }
    const color = METRIC_COLORS[card.key];
    const limitsFor = (key, difference) => {
        const range = thresholds[key];
        if (!range) return;
        const convert = (value) => Number.isFinite(value) ? toDisplay(value, card.unit, sae, difference) : undefined;
        return { warn: range.warnOff ? undefined : convert(range.warn), alarm: range.alarmOff ? undefined : convert(range.alarm) };
    };
    const limits = limitsFor(card.key, false);
    const tickDigits = card.key === 'boost' && !sae ? 2 : 0;
    const heatMax = Number.isFinite(scales.heat) ? toDisplay(scales.heat, '°C', sae, true) : undefined;
    const label = t(card.label);
    const intakeRows = card.key === 'intake' ? [
        { label, color, ticks, limits },
        { label: t('Above outside'), color: METRIC_COLORS.heat, ticks: [0, heatMax === undefined ? ticks[ticks.length - 1] - ticks[0] : heatMax],
            limits: limitsFor('heat', true) },
    ] : null;
    return Object.assign({}, card, { label, unit, ticks, color, intakeRows, limits, tickDigits });
}

class MetricGrid {
    constructor(scale) {
        this.scale = scale;
        this.recording = new Recorder(SCREEN.w, SCREEN.h, { textScale: scale });
        this.values = [];
        this.background = null;
        this.styleKey = '';
        this.contentKey = '';
        this.targets = [];
    }

    update(values, pages, language) {
        // The existing telemetry reports rounded values with a unit suffix, or '--'.
        const number = (key) => (values[key] || '--').split(' ', 1)[0];
        const numbers = CARDS.map(({ key }) => number(key));
        const heat = number('heat');
        const sae = values.sae === true;
        const boost = toDisplay(values.boostBar, 'bar', sae);
        const scales = values.scales || {};
        const thresholds = values.thresholds || {};
        const peaks = values.peaks || {};
        const t = translator(language);
        const strip = !!values.mhd || language === 'es';
        const styleKey = JSON.stringify([sae, scales, thresholds, strip, language]);
        if (styleKey !== this.styleKey) {
            const layout = strip ? STRIP_CARDS : CARDS;
            this.cards = layout.map((card) => inUnits(card, sae, scales, thresholds, t));
            this.dispose();
            this.background = makeLayer(SCREEN.w, APP.h, (canvas) => {
                canvas.clear('#000000');
                for (const card of this.cards) drawCard(canvas, card);
            }, this.scale);
            this.styleKey = styleKey;
        }
        const contentKey = JSON.stringify([styleKey, pages, numbers, heat, boost, peaks, values.gear, values.mhd]);
        if (contentKey === this.contentKey) return false;

        const canvas = this.recording.reset().clear().blit(this.background, 0, APP.y);
        this.cards.forEach((card, index) => drawReading(canvas, card, numbers[index], peaks[card.key], values.gear, heat, boost, t));
        this.targets = drawTabs(canvas, pages || [], 'engine', t);
        drawEngineStrip(canvas, values.mhd, this.targets, language);
        this.values = numbers;
        this.contentKey = contentKey;
        return true;
    }

    dispose() {
        if (this.background) dropLayer(this.background);
    }
}

class EngineDashboard {
    constructor(appId, onAction, onClosed, onHoldEnd) {
        this.appId = appId;
        this.onAction = onAction;
        this.onClosed = onClosed;
        this.onHoldEnd = onHoldEnd;
        this.client = null;
        this.grid = null;
        this.frame = { page: 'engine', pages: [], engine: {} };
        this.lastFrameAt = 0;
        this.failed = false;
    }

    show() {
        if (this.failed) return;
        if (this.client) {
            // The renderer can hide the layer while the RHMI state stays open.
            if (this.client.ready && !this.client.visible) this.present();
            return;
        }
        const client = new RenderClient(this.appId);
        this.client = client;
        client.on('rendererError', (error) => {
            if (this.client === client) this.fail(error);
        });
        const onClosed = () => {
            if (this.client !== client) return;
            this.cancelPress();
            if (this.onClosed) this.onClosed();
        };
        client.on('closed', onClosed);
        client.on('close', onClosed);
        client.on('ready', ({ w, h }) => {
            if (this.client !== client) return;
            try {
                const scale = Math.min(w / SCREEN.w, h / SCREEN.h);
                if (!(scale > 0)) throw new Error('Invalid renderer screen size');
                if (!this.grid || this.grid.scale !== scale) {
                    if (this.grid) this.grid.dispose();
                    this.grid = new MetricGrid(scale);
                    this.content = new ContentGrid(scale);
                }
                client.place({ x: 0, y: 0, w, h, scale,
                    ox: (w - SCREEN.w * scale) / 2, oy: (h - SCREEN.h * scale) / 2 });
                if (this.onAction) client.claim([{ x: 0, y: APP.y, w: SCREEN.w, h: APP.h }]);
                this.present();
            } catch (error) {
                this.fail(error);
            }
        });
        client.on('touch', (phase, x, y) => {
            if (this.client !== client || !client.ready || !client.visible || !this.onAction || !this.rendered) return;
            const hit = this.rendered.targets.find((target) => x >= target.x && x < target.x + target.w &&
                y >= target.y && y < target.y + target.h);
            if (phase === 'down') this.startPress(hit);
            if (phase === 'move' && this.holdTimer && (!hit || hit.id !== this.pressed)) this.cancelPress();
            if (phase === 'up') {
                const pressed = this.pressed;
                const held = this.held;
                this.cancelPress();
                if (!held && hit && hit.id === pressed) this.onAction(pressed);
            }
        });
        try {
            client.connect();
        } catch (error) {
            this.fail(error);
        }
    }

    startPress(target) {
        this.cancelPress();
        if (!target) return;
        this.pressed = target.id;
        if (!target.repeat) return;
        const repeat = () => {
            this.holdTimer = null;
            if (!this.rendered.targets.some(({ id }) => id === target.id)) return;
            this.held = true;
            if (this.onAction(target.id, true) && this.pressed === target.id) this.holdTimer = setTimeout(repeat, HOLD_REPEAT_MS);
        };
        this.holdTimer = setTimeout(repeat, HOLD_DELAY_MS);
    }

    cancelPress() {
        clearTimeout(this.holdTimer);
        this.holdTimer = null;
        this.pressed = null;
        const held = this.held;
        this.held = false;
        if (held && this.onHoldEnd) this.onHoldEnd();
    }

    present() {
        try {
            this.sendFrame(true);
            this.client.show(true);
        } catch (error) {
            this.fail(error);
        }
    }

    hide() {
        const client = this.client;
        this.client = null;
        this.frame = { page: 'engine', pages: [], engine: {} };
        this.cancelPress();
        this.failed = false;
        if (!client) return;
        client.show(false);
        client.close();
    }

    update(view) {
        this.frame = view;
        if (!this.client || !this.client.ready || !this.client.visible) return false;
        try {
            this.sendFrame(false);
            return true;
        } catch (error) {
            this.fail(error);
            return false;
        }
    }

    sendFrame(force) {
        // Keep only the newest view while the renderer is still draining its socket.
        if (this.client.backpressured) return;
        const view = this.frame;
        const engine = view.page === 'engine';
        const background = this.grid.background;
        const changed = engine ? this.grid.update(view.engine, view.pages, view.language) : this.content.update({
            page: view.page, pages: view.pages, content: view.content, language: view.language,
        });
        const rendering = engine ? this.grid : this.content;
        const now = Date.now();
        if (!force && !changed && this.rendered === rendering && now - this.lastFrameAt < KEEPALIVE_MS) return;
        this.client.frame(rendering.recording);
        this.rendered = rendering;
        if (background && background !== this.grid.background) this.client.dropLayer(background.layerId);
        this.lastFrameAt = now;
    }

    fail(error) {
        this.hide();
        this.failed = true;
        console.warn('PP DATA dashboard:', error.message);
    }
}

module.exports = { EngineDashboard, MetricGrid, SCREEN, APP };
