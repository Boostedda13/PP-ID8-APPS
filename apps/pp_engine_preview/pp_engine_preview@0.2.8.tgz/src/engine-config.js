'use strict';
module.exports = {
  "id": "pp_engine_preview",
  "rows": {
    "rpm": "Engine speed",
    "boost": "Boost",
    "power": "Power",
    "torque": "Torque",
    "speed": "Speed",
    "oil": "Engine oil",
    "coolant": "Coolant",
    "voltage": "Vbatt",
    "intake": "Intake air",
    "heat": "Intake above outside",
    "gear": "Gear"
  },
  "sources": [
    {
      "interface": "de.bmw.infotainment.vehicle.CDS",
      "instance": "1",
      "intervalMs": 500,
      "fast": [
        "statusEngineSpeed2"
      ],
      "pages": [
        "engine",
        "details",
        "faults"
      ],
      "fieldPages": {
        "statusEngineTemperature": [
          "engine"
        ]
      },
      "attributes": {
        "statusEngineSpeed2": {
          "rpm": "actualValueRPMEngineCrankshaft"
        },
        "statusEngineTemperature": {
          "oil": "temperatureEngineOilDrive",
          "coolant": "temperatureEngineDrive"
        }
      }
    },
    {
      "interface": "de.bmw.infotainment.vehicle.Vehicle2",
      "instance": "1",
      "intervalMs": 500,
      "fast": [
        "statusCarSpeed2"
      ],
      "pages": [
        "engine",
        "details",
        "faults"
      ],
      "attributes": {
        "statusCarSpeed2": {
          "speed": "speedVehicleCentreOfGravity"
        }
      }
    },
    {
      "interface": "de.bmw.infotainment.drivingexcitement.FES",
      "instance": "1",
      "intervalMs": 500,
      "fast": [
        "statusActualValueTorque2",
        "statusSwitchDriveDynamicSport2"
      ],
      "pages": [
        "engine",
        "fuel"
      ],
      "fieldPages": {
        "statusActualValueTorque2": [
          "engine"
        ]
      },
      "attributes": {
        "statusActualValueTorque2": {
          "torque": "actualValueTorqueCrankshaft"
        },
        "statusSwitchDriveDynamicSport2": {
          "boost": "displayBoostPressure"
        }
      }
    },
    {
      "interface": "de.bmw.infotainment.vehicle.Vehicle",
      "instance": "1",
      "intervalMs": 2000,
      "pages": [
        "engine",
        "fuel",
        "transmission"
      ],
      "attributes": {
        "statusNewCurrentUnitsStatusExt": {
          "pressureUnit": "unitOfMeasurementAirPressure"
        }
      }
    },
    {
      "interface": "com.harman.infotainment.systeminfrastructure.environment.levelmonitor.LevelMonitor",
      "instance": "Inst1",
      "intervalMs": 1000,
      "pages": [
        "engine",
        "details"
      ],
      "attributes": {
        "systemVoltage": {
          "voltage": "value"
        }
      }
    },
    {
      "interface": "de.bmw.infrastructure.VehicleInformation",
      "instance": "1",
      "intervalMs": 15000,
      "subscribeOnly": true,
      "pages": [
        "engine"
      ],
      "attributes": {
        "statusGearboxDrive": {
          "stage": "statusActualStageDrive",
          "gear": "statusActualGearDrive"
        }
      }
    },
    {
      "interface": "de.bmw.infotainment.displaydata.DisplayDataServer2",
      "instance": "1",
      "intervalMs": 500,
      "pages": [
        "engine"
      ],
      "attributes": {
        "functionalLibraryData": {
          "displayGear": "gear"
        }
      }
    },
    {
      "interface": "de.bmw.infrastructure.EnvironmentalInformation",
      "instance": "1",
      "intervalMs": 15000,
      "subscribeOnly": true,
      "pages": [
        "engine",
        "fuel"
      ],
      "attributes": {
        "ExteriorTemperature": {
          "outside": "temperatureExterior"
        }
      }
    },
    {
      "interface": "de.bmw.infotainment.vehicle.CDS2",
      "instance": "1",
      "intervalMs": 500,
      "pages": [
        "fuel"
      ],
      "attributes": {
        "statusInjectionVolume": {
          "injection": "injectionVolumeFuelEngine"
        }
      }
    }
  ]
};
