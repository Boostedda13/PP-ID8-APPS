'use strict';

const { uds, obd, EGS } = require('./diagnostics');
const useful = require('./kit/useful');
const engine = require('./kit/DME8FF_R.json');
const { OBD, ENUMS } = require('./kit/std');
const { decode } = require('./kit/sgbd');

const PAGES = [
    ['engine', 'Engine'], ['fuel', 'Fuel & Air'], ['transmission', 'Transmission'],
    ['details', 'Details'], ['faults', 'Fault Codes'], ['settings', 'Settings'],
];
const ENGINE_READS = [0x0f, 0x33, 0x70, 0x87, 0x0b, 0x0c, 0x0d, 0x05, 0x5c, 0xa4, 0x62, 0x63, 0x46].map((id) => obd(id, 5000))
    .concat(uds(0x580f, 10000));
const FUEL_READS = [
    ...[0x0f, 0x0a, 0x23, 0x0e, 0x33, 0x46, 0x70, 0x87, 0x0b].map((id) => obd(id, 5000)),
    uds(0x4ab0, 5000), uds(0x58f3, 10000),
    uds(0x5656, 3000), obd(0x5e, 3000), uds(0x4521, 6000),
];
const GEARBOX_ID = uds(0xf150, 15000, EGS);
const EGS_LIVE = [0xda2e, 0x6000, 0xda2a, 0xda34, 0xda22].map((id) => uds(id, 3000, EGS));
const EGS_HISTORY = [0x413a, 0x4140, 0x4130, 0x4131, 0x4441, 0x6081].map((id) => uds(id, 600000, EGS));

function candidateFor(c) {
    const [name, at] = c.split('/');
    const entry = engine[name] || OBD[name];
    if (!entry) return null;
    const service = entry.sid || 0x22;
    const id = entry.id === undefined ? parseInt(name, 16) : entry.id;
    const request = service === 0x22 ? uds(id, 15000) : obd(id, 15000);
    const index = Number(at || 0);
    return entry.f[index] ? { entry, index, request } : null;
}

const ENGINE_GROUPS = useful[0x12].filter(({ group }) => [
    'Engine', 'Temperatures', 'Oil', 'Fuel', 'Ignition and knock', 'VANOS and Valvetronic', 'Mixture and injectors',
].includes(group)).map(({ group, items }) => ({
    group,
    items: (group === 'Fuel' ? items.concat(useful[0x12].find((entry) => entry.group === 'Fuel quality').items) : items)
        .filter((item) => item.only !== 'twin').map((item) => Object.assign({}, item, {
        candidates: (item.c || item.minus || []).map(candidateFor).filter(Boolean),
    })).filter((item) => item.candidates.length),
}));
const DETAIL_CARDS = [];
const DETAIL_ACCENTS = ['rpm', 'intake', 'oil', 'torque', 'power', 'speed', 'coolant', 'boost'];
for (const { group, items } of ENGINE_GROUPS) {
    for (let start = 0; start < items.length; start += 8) {
        const metric = DETAIL_ACCENTS[DETAIL_CARDS.length % DETAIL_ACCENTS.length];
        DETAIL_CARDS.push({ title: group + (start ? ' (continued)' : ''), metric, items: items.slice(start, start + 8) });
    }
}
DETAIL_CARDS.push({ title: 'Data links', metric: DETAIL_ACCENTS[DETAIL_CARDS.length % DETAIL_ACCENTS.length] });
const DETAIL_PAGES = [];
for (let start = 0; start < DETAIL_CARDS.length; start += 3) {
    const cards = DETAIL_CARDS.slice(start, start + 3);
    const requests = new Map();
    for (const { items = [] } of cards) {
        for (const { candidates } of items) {
            for (const { request } of candidates) requests.set(request.service + '/' + request.id, request);
        }
    }
    DETAIL_PAGES.push({ cards, requests: Array.from(requests.values()) });
}

function detailValue(item, diagnostics, now) {
    const converted = item.candidates.map(({ entry, index, request }) => {
        const values = decode(entry, diagnostics.reply(request, now, 90000), ENUMS);
        const value = values && values[index];
        if (!value || value.why || (item.bad && item.bad.includes(value.raw))) return undefined;
        if (item.map && item.map[value.raw] !== undefined) return item.map[value.raw];
        let n = value.value;
        if (!Number.isFinite(n)) return value.text || n;
        const conversion = useful.CONVERT[entry.f[index].u];
        if (conversion && conversion[item.u]) n *= conversion[item.u];
        if (item.lin) n = item.lin[0] + item.lin[1] * n;
        if (item.u === '°C' && n < -45) return undefined;
        return n;
    });
    if (item.minus) return converted.length === 2 && converted.every(Number.isFinite) ? converted[0] - converted[1] : undefined;
    return converted.find((value) => value !== undefined);
}

module.exports = { PAGES, ENGINE_READS, FUEL_READS, GEARBOX_ID, EGS_LIVE, EGS_HISTORY, DETAIL_PAGES, detailValue };
