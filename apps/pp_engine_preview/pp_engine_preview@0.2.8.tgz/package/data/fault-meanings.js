'use strict';

// Factual summaries for modern engine ECUs. Source bulletins are listed in PROJECT-NOTES.md.
const engine = {
    '11A002': 'High-pressure fuel supply fell below the expected pressure.',
    '118001': 'The fuel and air mixture is too lean.',
    '118002': 'The fuel and air mixture is too rich.',
    '120208': 'Measured boost is higher than the control system expects.',
    '120308': 'Measured boost is below the requested pressure.',
    '120408': 'Boost control was disabled, preventing pressure from building.',
    '140001': 'Fuel injection stopped after multiple cylinders misfired.',
    '140010': 'Misfires registered on more than one cylinder.',
    '140101': 'Fuel injection stopped in cylinder 1 after a misfire.',
    '140110': 'Cylinder 1 misfire detected.',
    '140201': 'Fuel injection stopped in cylinder 2 after a misfire.',
    '140210': 'Cylinder 2 misfire detected.',
    '140301': 'Fuel injection stopped in cylinder 3 after a misfire.',
    '140310': 'Cylinder 3 misfire detected.',
    '140401': 'Fuel injection stopped in cylinder 4 after a misfire.',
    '140410': 'Cylinder 4 misfire detected.',
    '191C02': 'Fault at the second discharge point of the fuel-tank ventilation system.',
    'CDBA3B': 'Fuel level and remaining range message missing on the vehicle network.',
};

const headUnit = {
    B7F8E5: 'Head unit debug mode is active.',
    B7F8F9: 'Head unit recorded a reset.',
};

module.exports = { 0x12: engine, 0x13: engine, 0x63: headUnit };
