'use strict';

const fs = require('fs');
const { FAULTS } = require('./kit/readonly-diag');
const { hex, parseDtcReply, statusInfo } = require('./kit/diag');
const MEANINGS = require('./fault-meanings');

// ReadDTCInformation and status priority follow IterioDev Fault Codes 1.2.0.
const UNITS = {
    0x01: 'Airbag', 0x06: 'Camera', 0x10: 'Gateway', 0x12: 'Engine', 0x13: 'Engine 2',
    0x18: 'Transmission', 0x29: 'Stability control', 0x30: 'Steering', 0x37: 'Audio',
    0x38: 'Transfer case', 0x40: 'Body controller', 0x56: 'Roof', 0x5D: 'Driver assistance',
    0x60: 'Instrument cluster', 0x61: 'Telematics', 0x63: 'Head unit', 0x64: 'Parking assistance',
    0x76: 'Dampers', 0x78: 'Climate',
};
const UNITS_PER_PAGE = 6;
const CODES_PER_PAGE = 4;
const RESCAN_DELAY_MS = 1500;

function decodeScan(replies) {
    const units = [];
    let read = 0;
    let count = 0;
    for (const [address, reply] of replies) {
        // An incomplete positive record cannot prove that a module is clean.
        if (reply.length < 3 || (reply.length - 3) % 4 !== 0) continue;
        const result = parseDtcReply(reply, FAULTS);
        if (!result.ok) continue;
        read++;
        if (!result.dtcs.length) continue;
        count += result.dtcs.length;
        const codes = result.dtcs.map(({ code, status }) => {
            const { label, sev } = statusInfo(status);
            return { code, label, severity: sev, status, flag: '0x' + hex(status) };
        });
        codes.sort((a, b) => (b.status & 1) - (a.status & 1) || a.code.localeCompare(b.code));
        units.push({ address, codes });
    }
    units.sort((a, b) => b.codes.length - a.codes.length || a.address - b.address);
    return { units, count, read, incomplete: replies.size - read };
}

function unitIndex(reply) {
    if (!reply || reply.length < 6 || reply[0] !== 0x62) return '';
    return reply.slice(3, 6).map((byte) => hex(byte)).join('');
}

function readCatalog(file) {
    try { return JSON.parse(fs.readFileSync(file, 'utf8')) || {}; }
    catch (error) { return {}; }
}

function displayText(text) {
    return typeof text === 'string' ? text.replace(/[^\x20-\x7E]/g, ' ').replace(/ +/g, ' ').trim() : '';
}

class Faults {
    constructor(diagnostics, catalogFile, blockReason) {
        this.diagnostics = diagnostics;
        this.catalogFile = catalogFile;
        this.blockReason = blockReason;
        this.indices = new Map();
        this.operation = null;
        this.confirmation = null;
        this.rescan = null;
        this.result = null;
        this.unitPage = 0;
        this.codePage = 0;
        this.selected = null;
        this.message = 'Ignition on, engine off · tap Scan';
    }

    requireReady(operation) {
        const reason = this.operation === operation ? this.blockReason() : 'Fault operation stopped';
        if (reason) {
            const error = new Error(reason);
            error.code = 'FAULT_OPERATION_BLOCKED';
            throw error;
        }
    }

    canStart(now) {
        return !this.operation && !this.confirmation && !this.rescan &&
            now >= this.diagnostics.faultScanReadyAt && !this.blockReason(now);
    }

    async start(prefix = '') {
        if (!this.canStart(Date.now())) return;
        const scan = { kind: 'scan' };
        this.operation = scan;
        this.result = null;
        this.unitPage = this.codePage = 0;
        this.selected = null;
        this.message = prefix + 'Reading fault memory...';
        const beforeSend = () => this.requireReady(scan);
        try {
            const replies = await this.diagnostics.scanFaults(beforeSend);
            if (this.operation !== scan || !replies) return;
            const result = decodeScan(replies);
            const newUnits = result.units.filter(({ address }) => !this.indices.has(address));
            if (newUnits.length) {
                this.message = prefix + 'Identifying control units...';
                try {
                    const identities = await this.diagnostics.identifyFaultUnits(beforeSend);
                    if (this.operation !== scan) return;
                    if (identities) {
                        for (const { address } of newUnits) {
                            const index = unitIndex(identities.get(address));
                            if (index) this.indices.set(address, index);
                        }
                    }
                } catch (error) {
                    if (this.operation !== scan) return;
                    if (error.code === 'FAULT_OPERATION_BLOCKED') throw error;
                    console.warn('PP DATA fault unit identification:', error.message);
                }
            }
            if (this.operation !== scan) return;
            const catalog = result.units.length ? readCatalog(this.catalogFile) : {};
            this.result = this.describe(result, catalog);
            this.selected = this.result.units.length ? this.result.units[0].address : null;
            const { count, read, incomplete } = result;
            this.message = prefix + (replies.size ? `${count} codes · ${read} modules read` + (incomplete ? ` · ${incomplete} incomplete` : '')
                : 'No control units answered · check ignition');
        } catch (error) {
            if (this.operation === scan) {
                this.message = prefix + (error.code === 'FAULT_OPERATION_BLOCKED' ? 'Scan stopped · ' + error.message : 'Scan unavailable · try again');
                if (error.code !== 'FAULT_OPERATION_BLOCKED') console.warn('PP DATA fault scan:', error.message);
            }
        } finally {
            if (this.operation === scan) this.operation = null;
        }
    }

    requestClear(all) {
        if (!this.result || !this.canStart(Date.now())) return;
        const targets = this.result.units.filter((unit) => all || unit.address === this.selected);
        if (!targets.length) return;
        const target = all ? `${targets.length} control unit${targets.length === 1 ? '' : 's'}`
            : `${targets[0].name} (${targets[0].addressLabel})`;
        this.confirmation = { target, targets };
    }

    async confirmClear() {
        const confirmation = this.confirmation;
        if (!confirmation) return;
        this.confirmation = null;
        if (!this.canStart(Date.now())) return;
        const clear = { kind: 'clear', count: confirmation.targets.length, accepted: 0, sent: 0 };
        this.operation = clear;
        this.result = null;
        this.selected = null;
        const beforeSend = () => { this.requireReady(clear); clear.sent++; };
        try {
            for (const unit of confirmation.targets) {
                this.requireReady(clear);
                this.message = `Clearing ${unit.name} (${unit.addressLabel})...`;
                try {
                    const reply = await this.diagnostics.clearFaults(unit.address, beforeSend);
                    if (this.operation !== clear) return;
                    if (reply && reply[0] === 0x54) clear.accepted++;
                } catch (error) {
                    if (this.operation !== clear) return;
                    if (error.code === 'FAULT_OPERATION_BLOCKED') throw error;
                    console.warn('PP DATA fault clear', unit.addressLabel + ':', error.message);
                }
            }
            const summary = this.clearSummary(clear);
            if (clear.sent) this.rescan = { at: Date.now() + RESCAN_DELAY_MS, summary };
            this.message = clear.sent ? summary + ' · preparing rescan' : summary;
        } catch (error) {
            if (this.operation === clear) this.message = this.clearSummary(clear) + ' · ' + error.message;
        } finally {
            if (this.operation === clear) this.operation = null;
        }
    }

    clearSummary({ accepted, count }) { return `Clear accepted by ${accepted} of ${count} units`; }

    cancel(reason) {
        const operation = this.operation;
        const pending = operation || this.rescan || this.confirmation;
        this.operation = this.rescan = this.confirmation = null;
        if (operation) {
            this.message = operation.kind === 'clear' ? this.clearSummary(operation) + ' · Clear stopped' : 'Scan stopped';
            if (reason) this.message += ' · ' + reason;
        } else if (pending && !this.result) this.message = 'Tap Scan to check the current fault memory';
        return !!pending;
    }

    describe(result, catalog) {
        for (const unit of result.units) {
            const { address } = unit;
            const addressHex = hex(address);
            const index = this.indices.get(address);
            const variantKey = `${addressHex}:${index}`;
            const variant = index && catalog.modules && catalog.modules[variantKey];
            unit.name = displayText(variant && variant.name) || UNITS[address] || 'ECU';
            unit.addressLabel = '0x' + addressHex;
            unit.index = index || '';
            for (const fault of unit.codes) {
                const specific = variant && variant.codes && variant.codes[fault.code];
                const custom = catalog.codes && catalog.codes[`${addressHex}:${fault.code}`];
                fault.meaning = displayText(specific) || displayText(custom) ||
                    (MEANINGS[address] && MEANINGS[address][fault.code]) || 'Description unavailable';
            }
        }
        return result;
    }

    action(id) {
        if (id === 'scan') { this.start(); return; }
        if (id === 'clear-unit' || id === 'clear-all') { this.requestClear(id === 'clear-all'); return; }
        if (id === 'clear-confirm') { this.confirmClear(); return; }
        if (id === 'clear-cancel') { this.confirmation = null; return; }
        if (this.confirmation) return;
        const units = this.result ? this.result.units : [];
        if (id.indexOf('fault-unit:') === 0) {
            const address = Number(id.slice(11));
            if (units.some((unit) => unit.address === address)) {
                this.selected = address;
                this.codePage = 0;
            }
            return;
        }
        const selected = units.find(({ address }) => address === this.selected);
        if (id === 'previous' && this.codePage > 0) this.codePage--;
        if (id === 'next' && selected && (this.codePage + 1) * CODES_PER_PAGE < selected.codes.length) this.codePage++;
        if (id === 'unit-previous' && this.unitPage > 0) this.unitPage--;
        if (id === 'unit-next' && (this.unitPage + 1) * UNITS_PER_PAGE < units.length) this.unitPage++;
    }

    update(now) {
        const blocked = this.blockReason(now);
        if (blocked && this.cancel(blocked)) this.diagnostics.reset();
        if (!blocked && this.rescan && now >= this.rescan.at) {
            const prefix = this.rescan.summary + ' · ';
            this.rescan = null;
            this.start(prefix);
        }
        return this.view(now, blocked);
    }

    view(now, blocked) {
        const units = this.result ? this.result.units : [];
        const selected = units.find(({ address }) => address === this.selected);
        const codes = selected ? selected.codes : [];
        const codeStart = this.codePage * CODES_PER_PAGE;
        const unitStart = this.unitPage * UNITS_PER_PAGE;
        const waiting = now < this.diagnostics.faultScanReadyAt;
        const clearing = this.operation && this.operation.kind === 'clear';
        const busy = !!blocked || !!this.operation || !!this.rescan || waiting;
        const controls = [];
        if (this.confirmation) {
            controls.push({ id: 'clear-cancel', label: 'Cancel' }, { id: 'clear-confirm', label: 'Confirm Clear', danger: true });
        } else {
            if (codes.length > CODES_PER_PAGE) {
                controls.push({ id: 'previous', label: 'Previous', disabled: this.codePage === 0 },
                    { id: 'next', label: 'Next', disabled: codeStart + CODES_PER_PAGE >= codes.length });
            }
            if (selected) controls.push({ id: 'clear-unit', label: 'Clear Unit', disabled: busy, danger: true });
            if (units.length > 1) controls.push({ id: 'clear-all', label: 'Clear All', disabled: busy, danger: true });
            controls.push({ id: 'scan', label: this.operation ? (clearing ? 'Clearing...' : 'Scanning...') : 'Scan', disabled: busy });
        }
        let message = '';
        if (this.result && this.result.read) message = 'No pending or confirmed codes in the responding modules';
        return {
            subtitle: blocked || (waiting ? 'Previous diagnostic request still settling' : this.message),
            controls,
            faults: {
                units: units.slice(unitStart, unitStart + UNITS_PER_PAGE).map((unit) => ({
                    address: unit.address, addressLabel: unit.addressLabel, name: unit.name,
                    count: unit.codes.length, selected: unit.address === this.selected,
                })),
                unitPrevious: this.unitPage > 0,
                unitNext: unitStart + UNITS_PER_PAGE < units.length,
                heading: selected ? `${selected.name} · ${selected.addressLabel}` + (selected.index ? ` · ${selected.index}` : '') : '',
                codes: codes.slice(codeStart, codeStart + CODES_PER_PAGE),
                message,
                confirmation: this.confirmation ? this.confirmation.target : '',
            },
        };
    }
}

module.exports = Faults;
