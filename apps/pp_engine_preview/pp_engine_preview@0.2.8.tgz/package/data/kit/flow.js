'use strict';

// Extracted from the MIT-licensed iDrive App Kit. See LICENSE and SOURCE.
/**
 * Fuel flow from the fuel injection signal, taken as a counter of injected fuel (16 bit, it wraps):
 * its rate in counts a second, over at least one second; l/h = rate x k. k is learned from the engine
 * unit's own consumption: learn(l/h) while both are known, the middle of the last ratios once they agree.
 */
class Flow {
    constructor(k) { this.k = k || null; this.last = null; this.acc = 0; this.accT = 0; this.rate = null; this.ratios = []; this.spread = null; }
    feed(raw, t) {
        if (typeof raw !== 'number' || !isFinite(raw)) return;
        if (this.last && t > this.last.t) {
            const d = (raw - this.last.raw + 65536) % 65536, dt = t - this.last.t;
            if (dt > 5000 || d > 40000) { this.acc = 0; this.accT = 0; }               // a gap or a reset: start again
            else {
                this.acc += d; this.accT += dt;
                if (this.accT >= 1000) { this.rate = this.acc / this.accT * 1000; this.rateT = t; this.acc = 0; this.accT = 0; }
            }
        }
        this.last = { raw, t };
    }
    /** counts a second now (0 once the signal stopped changing for 3 s: engine off) */
    rateAt(now) {
        if (!this.last) return null;
        if (now - this.last.t > 3000) return 0;
        return this.rate;
    }
    lph(now) { const r = this.rateAt(now); return r === null || !this.k ? null : r * this.k; }
    /** the engine unit's l/h at about the same time: true when k changed by more than 2 % */
    learn(lph, now) {
        const r = this.rateAt(now);
        if (!(r > 0) || !(lph > 0.5) || now - (this.rateT || 0) > 1500) return false;
        this.ratios.push(lph / r);
        if (this.ratios.length > 30) this.ratios.shift();
        if (this.ratios.length < 10) return false;
        const s = this.ratios.slice().sort((a, b) => a - b), q1 = s[Math.floor(s.length / 4)], q3 = s[Math.floor(s.length * 3 / 4)];
        this.spread = q3 / q1;
        if (this.spread > 1.3) return false;                                                // they don't agree (yet): not a counter?
        const k = s[Math.floor(s.length / 2)], old = this.k;
        this.k = k;
        return !old || Math.abs(k - old) / old > 0.02;
    }
}

module.exports = Flow;
