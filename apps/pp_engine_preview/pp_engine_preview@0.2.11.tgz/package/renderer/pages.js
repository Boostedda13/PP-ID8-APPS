'use strict';

const { Recorder } = require('./kit/record');
const { METRIC_COLORS, PAGE_COLORS, THRESHOLD_COLORS } = require('./colors');

const SCREEN = { w: 2880, h: 960 };
const APP = { y: 76, h: 764 };
const WHITE = '#ffffff';
const FAULT_RED = '#ff3030';
const FAULT_TONES = {
    ready: { text: '#00e676', fill: '#052717' },
    error: { text: FAULT_RED, fill: '#2c0707', disabled: '#843020' },
    warning: { text: '#ffb000', fill: '#291c00', disabled: '#a77722' },
    info: { text: '#00d9ff', fill: '#052530' },
};
const BORDER = '#282828';
const VALUE_FONT = { font: 'value' };
const GRID = { x: 40, y: 177, w: 2800, h: 639, gap: 20 };

function button(canvas, box, label, selected, disabled, color = WHITE) {
    const { x, y, w, h } = box;
    canvas.strokeRoundRect(x, y, w, h, 9, 2, selected ? color : BORDER);
    canvas.text(label, x + w / 2, y + h / 2 + 10, disabled ? 28 : 30, color, { align: 'center' });
}

function drawTabs(canvas, pages, active) {
    if (!pages.length) return [];
    const gap = 18;
    const width = (GRID.w - (pages.length - 1) * gap) / pages.length;
    return pages.map(([key, label], index) => {
        const box = { x: GRID.x + (width + gap) * index, y: APP.y + 12, w: width, h: 46 };
        button(canvas, box, label, key === active);
        return Object.assign({ id: 'page:' + key }, box);
    });
}

function fit(canvas, value, width, size, opts) {
    const str = String(value);
    if (canvas.textWidth(str, size, opts) <= width) return str;
    let end = str.length - 1;
    while (end > 1 && canvas.textWidth(str.slice(0, end) + '…', size, opts) > width) end--;
    return str.slice(0, end) + '…';
}

function plot(canvas, a, b, x, y, w, h, color) {
    const sample = a.concat(b).filter(Number.isFinite);
    if (!sample.length) return;
    const min = Math.min(...sample);
    const max = Math.max(...sample);
    const margin = (max - min) * 0.06 || 0.5;
    const lo = min - margin;
    const span = max - min + 2 * margin;
    for (const ratio of [0, 0.5, 1]) canvas.fillRect(x, y + ratio * h, w, 1, BORDER);
    const len = Math.max(a.length, b.length, 2);
    for (const [points, shade] of [[a, color], [b, METRIC_COLORS.rpm]]) {
        let previous;
        points.forEach((value, index) => {
            if (!Number.isFinite(value)) { previous = null; return; }
            const point = [x + w * (index + len - points.length) / (len - 1), y + h - (value - lo) / span * h];
            if (previous) canvas.line(previous[0], previous[1], point[0], point[1], 3, shade);
            else canvas.roundRect(point[0] - 2, point[1] - 2, 4, 4, 2, shade);
            previous = point;
        });
    }
}

function cell(index, count, area) {
    const cols = Math.min(count, 3);
    const rows = Math.ceil(count / cols);
    const w = (area.w - (cols - 1) * area.gap) / cols;
    const h = (area.h - (rows - 1) * area.gap) / rows;
    return { x: area.x + index % cols * (w + area.gap), y: area.y + Math.floor(index / cols) * (h + area.gap), w, h };
}

function measurementParts(value) {
    const measurement = /^(-?\d+(?:\.\d+)?)( [^\d]+| L\/100 km)$/.exec(value);
    return measurement ? [measurement[1], measurement[2]] : [value, ''];
}

function measurementWidth(canvas, [value, unit], size) {
    return canvas.textWidth(value, size, VALUE_FONT) + canvas.textWidth(unit, size);
}

function drawMeasurement(canvas, parts, x, y, size, color, rightAligned) {
    const left = rightAligned ? x - measurementWidth(canvas, parts, size) : x;
    const advance = canvas.text(parts[0], left, y, size, WHITE, VALUE_FONT);
    if (parts[1]) canvas.text(parts[1], left + advance, y, size, color);
}

function settingButton(canvas, targets, box, id, label, color, selected, enabled) {
    button(canvas, box, label, selected, !enabled, enabled ? color : '#888888');
    if (enabled) targets.push(Object.assign({ id }, box));
}

function drawSettings(canvas, { sae, cards }, color, targets) {
    const count = cards.length + 1;
    const units = cell(0, count, GRID);
    canvas.strokeRoundRect(units.x, units.y, units.w, units.h, 17, 2, BORDER);
    canvas.text('Display units', units.x + 30, units.y + 41, 34, color);
    [['Metric', 'metric', !sae], ['SAE', 'sae', sae]].forEach(([label, key, selected], index) => {
        const width = (units.w - 74) / 2;
        const box = { x: units.x + 30 + index * (width + 14), y: units.y + 86, w: width, h: 57 };
        settingButton(canvas, targets, box, 'units:' + key, label, selected ? color : WHITE, selected, true);
    });
    cards.forEach(({ key, label, max, limits }, index) => {
        const { x, y, w, h } = cell(index + 1, count, GRID);
        const left = x + 30;
        const right = x + w - 30;
        const accent = METRIC_COLORS[key] || color;
        canvas.strokeRoundRect(x, y, w, h, 17, 2, BORDER);
        canvas.text(label, left, y + 41, 34, accent);
        const drawRow = (row, name, setting, id, shade, toggle) => {
            const top = y + 53 + row * 47;
            canvas.text(name, left, top + 30, 28, shade);
            if (toggle) {
                const box = { x: left + 118, y: top, w: 104, h: 44 };
                settingButton(canvas, targets, box, id + ':on', setting.enabled ? 'On' : 'Off',
                    shade, setting.enabled, true);
            }
            drawMeasurement(canvas, measurementParts(setting.value), right - 183, top + 30, 30, shade, true);
            [['-', setting.canMinus], ['+', setting.canPlus]].forEach(([symbol, enabled], i) => {
                const box = { x: right - 160 + i * 84, y: top, w: 76, h: 44 };
                settingButton(canvas, targets, box, id + ':' + symbol, symbol, shade, enabled, enabled);
            });
        };
        if (max) drawRow(0, 'Max', max, key, accent, false);
        limits.forEach((limit, i) => drawRow(i + Number(!!max), limit.key === 'warn' ? 'Warn' : 'Alarm', limit,
            key + ':' + limit.key, THRESHOLD_COLORS[limit.key], true));
    });
}

function drawCard(canvas, box, card, pageColor) {
    const { x, y, w, h } = box;
    const left = x + 30;
    const right = x + w - 30;
    const color = METRIC_COLORS[card.metric] || pageColor;
    canvas.strokeRoundRect(x, y, w, h, 17, 2, BORDER);
    canvas.text(fit(canvas, card.title, w - 60, 36), left, y + 53, 36, color);
    if (card.rows) {
        const step = Math.min(54, (h - 87) / Math.max(1, card.rows.length));
        const size = Math.min(32, Math.floor(step * 0.7));
        card.rows.forEach(([label, value], index) => {
            const baseline = y + 80 + step * (index + 0.55);
            const reading = measurementParts(fit(canvas, value, (w - 60) * 0.47, size, VALUE_FONT));
            const limit = w - 96 - measurementWidth(canvas, reading, size);
            canvas.text(fit(canvas, label, limit, size), left, baseline, size, color);
            drawMeasurement(canvas, reading, right, baseline, size, color, true);
            canvas.fillRect(left, baseline + step * 0.24, w - 60, 1, BORDER);
        });
    } else if (card.value !== undefined) {
        const pieces = card.value.split(' ');
        const number = pieces.shift();
        const advance = canvas.text(number, left, y + 134, 72, WHITE, { font: 'num' });
        canvas.text(pieces.join(' '), left + advance + 16, y + 134, 34, color);
        if (card.target) {
            const targetColor = METRIC_COLORS.rpm;
            const target = measurementParts(card.target);
            canvas.text('Target  ', right - measurementWidth(canvas, target, 29), y + 134, 29, targetColor, { align: 'right' });
            drawMeasurement(canvas, target, right, y + 134, 29, targetColor, true);
        }
        if (card.trace) plot(canvas, card.trace, card.trace2 || [], left, y + 174, w - 60, Math.max(30, h - 209), color);
    }
}

function faultMeaning(canvas, description, x, y, width) {
    const words = description.split(' ');
    const first = [];
    while (words.length && canvas.textWidth(first.concat(words[0]).join(' '), 31, VALUE_FONT) <= width) {
        first.push(words.shift());
    }
    if (!first.length) {
        canvas.text(fit(canvas, description, width, 31, VALUE_FONT), x, y, 31, WHITE, VALUE_FONT);
        return;
    }
    canvas.text(first.join(' '), x, y, 31, WHITE, VALUE_FONT);
    if (words.length) canvas.text(fit(canvas, words.join(' '), width, 31, VALUE_FONT), x, y + 37, 31, WHITE, VALUE_FONT);
}

function drawFaultActions(canvas, controls, x, y, width, targets) {
    const gap = 12;
    const w = (width - (controls.length - 1) * gap) / controls.length;
    controls.forEach(({ id, label, tone, disabled }, index) => {
        const box = { x: x + index * (w + gap), y, w, h: 90 };
        const palette = FAULT_TONES[tone];
        const color = disabled ? palette.disabled : palette.text;
        if (!disabled) canvas.roundRect(box.x, box.y, w, box.h, 12, palette.fill);
        canvas.strokeRoundRect(box.x, box.y, w, box.h, 12, disabled ? 2 : 4, color);
        canvas.text(label, box.x + w / 2, y + 58, 36, color, { align: 'center' });
        if (!disabled) targets.push(Object.assign({ id }, box));
    });
}

function drawFaults(canvas, faults, color, targets) {
    const { x, y, w, h } = GRID;
    const leftW = 746;
    const rightX = x + leftW + GRID.gap;
    const rightW = w - leftW - GRID.gap;
    const statuses = { crit: FAULT_RED, warn: METRIC_COLORS.torque, dim: METRIC_COLORS.speed };
    const showCodePager = faults.codePaginated && !faults.confirmation;
    canvas.strokeRoundRect(x, y, leftW, h, 17, 2, BORDER);
    canvas.strokeRoundRect(rightX, y, rightW, h, 17, 2, BORDER);
    canvas.text('Control units', x + 30, y + 49, 36, color);
    const headingWidth = rightW - (showCodePager ? 490 : 60);
    canvas.text(fit(canvas, faults.heading || 'Fault codes', headingWidth, 36), rightX + 30, y + 49, 36, color);
    faults.units.forEach(({ address, addressLabel, name, count, selected }, index) => {
        const row = { x: x + 24, y: y + 72 + index * 66, w: leftW - 48, h: 56 };
        canvas.strokeRoundRect(row.x, row.y, row.w, row.h, 12, 2, selected ? color : BORDER);
        canvas.text(fit(canvas, name, 415, 32), row.x + 20, row.y + 39, 32, selected ? color : WHITE);
        canvas.text(addressLabel, row.x + 510, row.y + 39, 32, WHITE, { font: 'value', align: 'right' });
        canvas.text(String(count), row.x + row.w - 24, row.y + 39, 34, WHITE, { font: 'value', align: 'right' });
        if (!faults.confirmation) targets.push(Object.assign({ id: 'fault-unit:' + address }, row));
    });
    if (!faults.confirmation && (faults.unitPrevious || faults.unitNext)) {
        [{ id: 'unit-previous', label: 'Previous', enabled: faults.unitPrevious },
            { id: 'unit-next', label: 'Next', enabled: faults.unitNext }].forEach(({ id, label, enabled }, index) => {
            const box = { x: x + 24 + index * 216, y: y + h - 164, w: 200, h: 42 };
            button(canvas, box, label, false, !enabled);
            if (enabled) targets.push(Object.assign({ id }, box));
        });
    }
    drawFaultActions(canvas, faults.controls, x + 24, y + h - 110, leftW - 48, targets);
    if (faults.confirmation) {
        const center = rightX + rightW / 2;
        const question = fit(canvas, 'Clear fault memory on ' + faults.confirmation + '?', rightW - 60, 48);
        canvas.text(question, center, y + 255, 48, FAULT_RED, { align: 'center' });
        canvas.text('Confirm the vehicle is parked with the ignition on and engine off.',
            center, y + 336, 34, WHITE, { align: 'center' });
        return;
    }
    if (faults.clearWarning) {
        const { text, tone } = faults.clearWarning;
        canvas.text(text, rightX + 30, y + h - 17, 28, FAULT_TONES[tone].text);
    }
    if (showCodePager) {
        [{ id: 'previous', label: 'Previous', enabled: faults.codePrevious },
            { id: 'next', label: 'Next', enabled: faults.codeNext }].forEach(({ id, label, enabled }, index) => {
            const box = { x: rightX + rightW - 440 + index * 216, y: y + 14, w: 200, h: 42 };
            button(canvas, box, label, false, !enabled);
            if (enabled) targets.push(Object.assign({ id }, box));
        });
    }
    if (!faults.codes.length && faults.message) {
        canvas.text(faults.message, rightX + rightW / 2, y + 270, 36, WHITE, { align: 'center' });
    }
    faults.codes.forEach(({ code, label, severity, flag, meaning }, index) => {
        const left = rightX + 24;
        const top = y + 72 + index * 132;
        const width = rightW - 48;
        canvas.strokeRoundRect(left, top, width, 120, 12, 2, BORDER);
        canvas.fillRect(left + 20, top + 20, 4, 80, statuses[severity]);
        canvas.text(code, left + 40, top + 52, 43, WHITE, VALUE_FONT);
        canvas.text('Status flag', left + 40, top + 93, 25, color);
        canvas.text(flag, left + 196, top + 93, 28, WHITE, VALUE_FONT);
        canvas.text(label, left + 286, top + 50, 30, statuses[severity]);
        faultMeaning(canvas, meaning, left + 626, top + 49, width - 660);
    });
}

class ContentGrid {
    constructor(scale) {
        this.recording = new Recorder(SCREEN.w, SCREEN.h, { textScale: scale });
        this.targets = [];
        this.last = '';
    }

    update(view) {
        const key = JSON.stringify(view);
        if (key === this.last) return false;
        this.last = key;
        const canvas = this.recording.reset().clear();
        canvas.fillRect(0, APP.y, SCREEN.w, APP.h, '#000000');
        this.targets = drawTabs(canvas, view.pages, view.page);
        const content = view.content || {};
        const pageColor = PAGE_COLORS[view.page] || WHITE;
        if (content.faults) {
            const { canScan, statusTone, lastScan } = content.faults;
            const ready = 'Ready to scan';
            const size = 30;
            if (canScan) canvas.text(ready, GRID.x, 166, size, FAULT_TONES.ready.text);
            const statusX = canScan ? GRID.x + canvas.textWidth(ready, size) + 40 : GRID.x;
            let history = '—';
            if (lastScan) {
                const { at, count, modules } = lastScan;
                const date = new Date(at).toISOString().slice(0, 16).replace('T', ' ');
                history = `${count} codes · ${modules} modules read · ${date} UTC`;
            }
            const right = GRID.x + GRID.w;
            const historyX = right - canvas.textWidth(history, size, VALUE_FONT);
            const labelX = historyX - 22;
            canvas.text(history, historyX, 166, size, WHITE, VALUE_FONT);
            canvas.text('Last scan', labelX, 166, size, pageColor, { align: 'right' });
            if (content.subtitle) {
                const width = labelX - canvas.textWidth('Last scan', size) - statusX - 32;
                canvas.text(fit(canvas, content.subtitle, width, size), statusX, 166, size, FAULT_TONES[statusTone].text);
            }
        } else if (content.subtitle) canvas.text(content.subtitle, GRID.x, 162, 25, WHITE);
        if (content.readout) {
            const { label, metric, value } = content.readout;
            const color = METRIC_COLORS[metric];
            const parts = measurementParts(value);
            const right = GRID.x + GRID.w;
            canvas.text(label, right - measurementWidth(canvas, parts, 30) - 18, 162, 30, color, { align: 'right' });
            drawMeasurement(canvas, parts, right, 162, 30, color, true);
        }
        (content.controls || []).forEach((control, index, all) => {
            const x = SCREEN.w - GRID.x - (all.length - index) * 216 + 16;
            const box = { x, y: 140, w: 200, h: 39 };
            button(canvas, box, control.label, control.selected, control.disabled);
            if (!control.disabled) this.targets.push(Object.assign({ id: control.id }, box));
        });
        if (content.faults) {
            drawFaults(canvas, content.faults, pageColor, this.targets);
        } else if (content.settings) {
            drawSettings(canvas, content.settings, pageColor, this.targets);
        } else if (content.cards) {
            content.cards.forEach((card, index) => drawCard(canvas, cell(index, content.cards.length, GRID), card, pageColor));
        }
        return true;
    }
}

module.exports = { ContentGrid, drawTabs, SCREEN, APP };
