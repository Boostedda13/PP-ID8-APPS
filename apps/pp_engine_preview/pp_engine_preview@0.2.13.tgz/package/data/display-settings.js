'use strict';

const { displayUnit, toDisplay, fromDisplay } = require('./units');

// [label, native unit, default max, min, max, Metric step, SAE step]
const SCALES = {
    rpm: ['Engine speed', 'rpm', 8000, 5000, 12000, 500, 500],
    boost: ['Boost', 'bar', 2.5, 0.5, 5, 0.25, 5],
    power: ['Power', 'hp', 500, 200, 1500, 25, 25],
    torque: ['Torque', 'Nm', 700, 300, 1500, 50, 25],
    oil: ['Engine oil', '°C', 150, 100, 180, 5, 10],
    coolant: ['Coolant', '°C', 130, 100, 160, 5, 10],
    intake: ['Intake air', '°C', 80, 40, 120, 5, 10],
};
const LIMITS = { rpm: 'rpm', oil: 'oil', coolant: 'coolant', intake: 'intake', heat: 'intake' };
const LEVELS = ['warn', 'alarm'];
const finite = Number.isFinite;
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const own = (object, key) => Object.prototype.hasOwnProperty.call(object, key);

function display(value, unit, sae, difference = false) {
    const digits = unit === 'bar' ? (sae ? 1 : 2) : 0;
    return toDisplay(value, unit, sae, difference).toFixed(digits) + ' ' + displayUnit(unit, sae);
}

class DisplaySettings {
    constructor(saved) {
        this.scales = {};
        this.thresholds = {};
        for (const [key, [, , fallback, min, max]] of Object.entries(SCALES)) {
            const value = saved.scales && saved.scales[key];
            this.scales[key] = finite(value) && value >= min && value <= max ? value : fallback;
        }
        for (const [key, scaleKey] of Object.entries(LIMITS)) {
            const source = saved.thresholds && saved.thresholds[key];
            const max = SCALES[scaleKey][4];
            const entry = {};
            for (const level of LEVELS) {
                if (!source || !finite(source[level]) || source[level] < 0 || source[level] > max) continue;
                entry[level] = source[level];
                if (source[level + 'Off'] === true) entry[level + 'Off'] = true;
            }
            if (entry.warn > entry.alarm && !entry.warnOff && !entry.alarmOff) entry.warnOff = true;
            if (Object.keys(entry).length) this.thresholds[key] = entry;
        }
        this.units = saved.units === 'sae' || saved.units === 'metric' ? saved.units : undefined;
        this.mhdStrip = saved.mhdStrip === true;
        this.sae = this.units === 'sae';
    }

    get override() { return this.units === undefined ? undefined : this.units === 'sae'; }

    saved() { return { scales: this.scales, thresholds: this.thresholds, units: this.units, mhdStrip: this.mhdStrip }; }

    move(value, unit, difference, step) {
        const displayValue = toDisplay(value, unit, this.sae, difference);
        return Number(fromDisplay(displayValue + step, unit, this.sae, difference).toFixed(9));
    }

    bounds(key, level) {
        const values = this.thresholds[key] || {};
        const scaleKey = LIMITS[key];
        const max = this.scales[scaleKey];
        if (level === 'warn') return [0, !values.alarmOff && finite(values.alarm) ? Math.min(max, values.alarm) : max];
        const min = !values.warnOff && finite(values.warn) ? values.warn : 0;
        return [min, Math.max(max, min)];
    }

    editThreshold(key, level, direction) {
        const limits = this.thresholds[key] || {};
        const existing = limits[level];
        const off = level + 'Off';
        const [min, max] = this.bounds(key, level);
        const scaleKey = LIMITS[key];
        const [, unit] = SCALES[scaleKey];
        if (direction === 'on') {
            if (finite(existing) && !limits[off]) {
                limits[off] = true;
            } else {
                const hint = finite(existing) ? existing : Math.round(this.scales[scaleKey] * (level === 'warn' ? 0.75 : 0.9));
                limits[level] = clamp(hint, min, max);
                delete limits[off];
                this.thresholds[key] = limits;
            }
            return true;
        }
        if (!finite(existing) || limits[off] || (direction !== '+' && direction !== '-')) return false;
        const step = key === 'rpm' ? 100 : this.sae ? 10 : 5;
        const value = clamp(this.move(existing, unit, key === 'heat', direction === '+' ? step : -step), min, max);
        if (value === existing) return false;
        limits[level] = value;
        return true;
    }

    action(id) {
        if (id === 'settings:mhd') {
            this.mhdStrip = !this.mhdStrip;
            return true;
        }
        const [key, control, direction] = id.split(':');
        if (key === 'units' && (control === 'metric' || control === 'sae')) {
            if (this.units === control) return false;
            this.units = control;
            this.sae = control === 'sae';
            return true;
        }
        if (own(LIMITS, key) && LEVELS.includes(control)) return this.editThreshold(key, control, direction);
        if (!own(SCALES, key) || (control !== '+' && control !== '-')) return false;
        const [, unit, , min, max, metricStep, saeStep] = SCALES[key];
        const step = this.sae ? saeStep : metricStep;
        const existing = this.scales[key];
        const value = clamp(this.move(existing, unit, false, control === '+' ? step : -step), min, max);
        if (value === existing) return false;
        this.scales[key] = value;
        return true;
    }

    card(key, label, unit, max) {
        const values = this.thresholds[key] || {};
        const limits = own(LIMITS, key) ? LEVELS.map((level) => {
            const [low, high] = this.bounds(key, level);
            const value = values[level];
            const enabled = finite(value) && !values[level + 'Off'];
            return { key: level, enabled, value: enabled ? display(value, unit, this.sae, key === 'heat') : '',
                canMinus: enabled && value > low, canPlus: enabled && value < high };
        }) : [];
        return { key, label, max, limits };
    }

    view() {
        const cards = Object.entries(SCALES).map(([key, [label, unit, , min, max]]) => {
            const value = this.scales[key];
            return this.card(key, label, unit, { value: display(value, unit, this.sae), canMinus: value > min, canPlus: value < max });
        });
        cards.push(this.card('heat', 'Above outside', '°C', null));
        return { sae: this.sae, cards, mhdStrip: this.mhdStrip };
    }
}

module.exports = DisplaySettings;
