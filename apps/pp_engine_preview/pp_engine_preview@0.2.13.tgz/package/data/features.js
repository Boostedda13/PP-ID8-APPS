'use strict';

const path = require('path');
const { read, write } = require('./storage');
const { Diagnostics, uds, obd, EGS } = require('./diagnostics');
const { PAGES, ENGINE_READS, FUEL_READS, GEARBOX_ID, EGS_GEAR, EGS_LIVE, EGS_HISTORY,
    DETAIL_PAGES, detailValue } = require('./catalog');
const Flow = require('./kit/flow');
const { readGear, decode: decodeEgs, TCC } = require('./egs/egs');
const Faults = require('./faults');
const DisplaySettings = require('./display-settings');
const { Mhd } = require('./mhd');
const { displayUnit, toDisplay } = require('./units');

const PEAKS = ['rpm', 'boost', 'power', 'torque'];
const HISTORY_SAMPLE_MS = 5000;
const HISTORY_WINDOW_MS = 300000;
const EGS_VARIANTS = { '0F25D0': 'ZF 8HP', '0F21E0': 'ZF 8HP Hybrid' };
const EGS_GEARS = { 0: 'P', 1: 'R', 2: 'N', 3: '1', 4: '2', 5: '3', 6: '4', 7: '5', 8: '6', 9: '7', 16: '8' };
const EGS_POSITIONS = ['P', 'R', 'N', 'D', 'M'];
const SELECTOR_STAGES = { 1: 'P', 2: 'R', 3: 'N', 4: 'D', P: 'P', R: 'R', N: 'N', D: 'D' };
const OPTIONAL_GEARBOX_ID = Object.assign({ optional: true }, GEARBOX_ID);
const OPTIONAL_EGS_GEAR = Object.assign({ optional: true }, EGS_GEAR);
const finite = Number.isFinite;
const n = (value, unit, digits) => finite(value) ? value.toFixed(digits || 0) + (unit ? ' ' + unit : '') : '—';
const text = (value) => value === undefined || value === null ? '—' : String(value);
const u16 = (data, index) => data && data.length > index + 1 ? data[index] * 256 + data[index + 1] : undefined;
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

function liveGear(raw, speed) {
    const stage = SELECTOR_STAGES[raw.stage];
    if (stage && stage !== 'D') return stage;
    const wire = /^(?:[1-9]|1[0-2])$/.test(String(raw.gear)) ? Number(raw.gear) : 0;
    if (wire >= 3) return 'D' + (wire - 2);
    if (/^G(?:[1-9]|10)$/.test(String(raw.gear))) return 'D' + raw.gear.slice(1);
    if (!stage) {
        if (raw.gear === 'P' || raw.gear === 'N' || raw.gear === 'R') return raw.gear;
        if (wire === 1) return 'R';
        if (raw.gear === 'N_OR_P' || wire === 2) return 'P/N';
    }
    if (speed > 0 && Number.isInteger(raw.displayGear) && raw.displayGear >= 20 && raw.displayGear <= 27) {
        return 'D' + (raw.displayGear - 19);
    }
    return stage;
}

function reading(value, unit, sae, digits, difference = false) {
    return n(toDisplay(value, unit, sae, difference), displayUnit(unit, sae), digits);
}

function temperature(value, sae) { return reading(value, '°C', sae); }
function temperatureDifference(value, sae) { return reading(value, '°C', sae, 0, true); }
function pressure(value, sae, digits) { return reading(value, 'bar', sae, digits); }

class Features {
    constructor(connect, directory, faultBlockReason = () => ({ text: 'Open the Fault Codes tab', tone: 'warning' }),
        canAdjustMhd = () => false) {
        this.diagnostics = new Diagnostics(connect);
        this.faults = new Faults(this.diagnostics, directory, faultBlockReason);
        this.mhd = new Mhd(this.diagnostics, canAdjustMhd);
        this.settingsFile = path.join(directory, 'pp-settings.json');
        const saved = read(this.settingsFile);
        this.display = new DisplaySettings(saved);
        this.flow = new Flow(finite(saved.fuelScale) && saved.fuelScale > 0 ? saved.fuelScale : null);
        this.history = {};
        this.historyAt = 0;
        this.page = 'engine';
        this.offset = 0;
        this.peaks = {};
        this.lastSae = null;
    }

    select(page) {
        if (this.page === page || !PAGES.some(([key]) => key === page)) return;
        this.faults.cancel();
        this.mhd.cancel();
        this.page = page;
        this.offset = 0;
        this.diagnostics.reset();
        this.resetFuelFlow();
        if (page === 'engine') this.peaks = {};
    }

    pause() {
        this.faults.cancel();
        this.mhd.cancel();
        this.diagnostics.reset();
        this.peaks = {};
        this.resetFuelFlow();
    }

    resetFuelFlow() {
        this.flow = new Flow(this.flow.k);
        this.flowAt = 0;
        this.lph = undefined;
    }

    saveSettings() {
        write(this.settingsFile, Object.assign({ fuelScale: this.flow.k }, this.display.saved()));
    }

    cancelFaultOperation() {
        if (this.faults.cancel()) this.diagnostics.reset();
    }

    cancelMhdOperation() {
        if (!this.mhd.pending) return;
        this.mhd.cancel();
        this.diagnostics.reset();
    }

    action(id) {
        if (id.indexOf('page:') === 0) { this.select(id.slice(5)); return; }
        if (this.page === 'faults') { this.faults.action(id); return; }
        if (this.page === 'engine' && this.display.mhdStrip && id.indexOf('mhd:') === 0) { this.mhd.action(id); return; }
        if (this.page === 'details' && (id === 'previous' || id === 'next')) {
            const offset = clamp(this.offset + (id === 'next' ? 1 : -1), 0, DETAIL_PAGES.length - 1);
            if (offset !== this.offset) {
                this.offset = offset;
                this.diagnostics.reset();
            }
            return;
        }
        if (this.page === 'settings' && this.display.action(id)) this.saveSettings();
    }

    uds(id, now, age) { return this.diagnostics.reply(uds(id), now, age || 15000); }

    gearbox(now, maxAge = 60000) {
        const reply = this.diagnostics.reply(GEARBOX_ID, now, maxAge);
        if (!reply || reply.length < 6) return undefined;
        return Buffer.from(reply.slice(3, 6)).toString('hex').toUpperCase();
    }

    engineGear(primary, speed, now) {
        if (primary && primary !== 'P/N' && primary !== 'D') return primary;
        if (EGS_VARIANTS[this.gearbox(now, Infinity)]) {
            const [gear, position] = readGear(this.diagnostics.reply(EGS_GEAR, now, 4000));
            const reported = EGS_POSITIONS[position];
            const selector = reported === 'P' && speed > 1 ? undefined : reported;
            const number = Number(EGS_GEARS[gear]);
            if (primary === 'P/N') {
                if (selector === 'P' || selector === 'N') return selector;
            } else if ((!primary && selector) || (primary === 'D' && (selector === 'D' || selector === 'M'))) {
                return (selector === 'D' || selector === 'M') && finite(number) ? selector + number : selector;
            }
        }
        if (primary === 'P/N' || !(speed > 0)) return primary;
        const reply = this.diagnostics.reply(obd(0xa4), now, 5000);
        if (!reply || reply.length < 6 || reply[0] !== 0x41 || reply[1] !== 0xa4 || !(reply[2] & 1)) return primary;
        const gear = reply[3] >> 4;
        // Gear 1 can also denote reverse in this PID, so label it D1 only with a known Drive selector.
        return gear >= (primary === 'D' ? 1 : 2) && gear <= 10 ? 'D' + gear : primary;
    }

    engineGearRequest(primary, now) {
        if (primary && primary !== 'P/N' && primary !== 'D') return undefined;
        // Leave the first two Engine reads available for the existing fast boost path.
        if (!this.diagnostics.hasRequested(ENGINE_READS[1])) return undefined;
        const variant = this.gearbox(now, Infinity);
        if (!variant) return OPTIONAL_GEARBOX_ID;
        return EGS_VARIANTS[variant] ? OPTIONAL_EGS_GEAR : undefined;
    }

    requests(now) {
        switch (this.page) {
        case 'engine': return ENGINE_READS;
        case 'fuel': return FUEL_READS;
        case 'transmission': {
            const variant = this.gearbox(now);
            return EGS_VARIANTS[variant] ? [GEARBOX_ID].concat(EGS_LIVE, EGS_HISTORY) : [GEARBOX_ID];
        }
        case 'details': return DETAIL_PAGES[this.offset].requests;
        default: return [];
        }
    }

    intake(now) {
        const iat = this.diagnostics.obdValue(0x0f, now);
        if (finite(iat)) return iat;
        const frame = this.uds(0x580f, now);
        return frame && frame[3] !== undefined ? frame[3] * 0.75 - 48 : undefined;
    }

    boost(now, includeTarget) {
        const diag = this.diagnostics;
        const ambient = diag.obdValue(0x33, now);
        if (!finite(ambient)) return {};
        const pair = diag.reply(obd(0x70), now, 10000);
        const high = diag.reply(obd(0x87), now, 10000);
        const pressures = [diag.obdValue(0x0b, now)];
        if (pair && pair[2] & 2) pressures.push(u16(pair, 5) / 32);
        if (pair && pair[2] & 8) pressures.push(u16(pair, 9) / 32);
        if (high && high[2] & 1) pressures.push(u16(high, 3) / 32);
        const valid = pressures.filter(finite);
        let target;
        if (includeTarget) {
            target = u16(this.uds(0x4ab0, now), 3) / 256;
            if (!finite(target) && pair && pair[2] & 1) target = u16(pair, 3) / 32;
            if (!finite(target) && pair && pair[2] & 4) target = u16(pair, 7) / 32;
        }
        return { actual: valid.length ? (Math.max(...valid) - ambient) / 100 : undefined,
            target: finite(target) ? (target - ambient) / 100 : undefined };
    }

    sample(key, value, now) {
        const points = this.history[key] || (this.history[key] = []);
        points.push([now, finite(value) ? value : null]);
        while (points.length && points[0][0] < now - HISTORY_WINDOW_MS) points.shift();
    }

    trace(key, now) {
        const points = (this.history[key] || []).filter(([at]) => now - at <= HISTORY_WINDOW_MS);
        if (!points.length) return [];
        const latest = points[points.length - 1][0];
        const slots = Math.round((latest - points[0][0]) / HISTORY_SAMPLE_MS) + 1;
        const values = Array(slots).fill(null);
        for (const [at, value] of points) {
            values[slots - 1 - Math.round((latest - at) / HISTORY_SAMPLE_MS)] = value;
        }
        return values;
    }

    air(now, values, raw, includeTarget) {
        const diag = this.diagnostics;
        const intake = this.intake(now);
        const ambient = finite(raw.outside) && raw.outside < 255 ? raw.outside * 0.5 - 40 : diag.obdValue(0x46, now);
        const b = this.boost(now, includeTarget);
        const boost = finite(b.actual) ? b.actual : values.boostBar;
        return { intake, heat: intake - ambient, boost, target: b.target };
    }

    fuel(now, air) {
        const diag = this.diagnostics;
        const low = diag.reply(obd(0x0a), now, 15000);
        const lp = low && low[2] !== undefined ? low[2] * 0.03 : u16(this.uds(0x58f3, now), 3) * 0.001;
        return Object.assign({}, air, { lp, hp: diag.obdValue(0x23, now), timing: diag.obdValue(0x0e, now) });
    }

    fuelFlow(raw, now) {
        if (this.flowAt && now - this.flowAt < 1000) return this.lph;
        this.flowAt = now;
        const hasInjection = finite(raw.injection) && raw.injection >= 0 && raw.injection < 65535;
        if (hasInjection) this.flow.feed(raw.injection, now);
        const volume = u16(this.uds(0x5656, now, 7000), 3) * 0.00119209 * 3.6;
        const obdFlow = this.diagnostics.obdValue(0x5e, now);
        const mass = u16(this.uds(0x4521, now, 7000), 3) * 0.1 / 0.745;
        const reference = [volume, obdFlow, mass].find((value) => finite(value) && value >= 0 && value < 200);
        if (this.flow.learn(reference, now)) this.saveSettings();
        const learned = hasInjection ? this.flow.lph(now) : undefined;
        this.lph = finite(learned) ? learned : reference;
        return this.lph;
    }

    motion(raw, now) {
        const rpm = finite(raw.rpm) && raw.rpm < 65535 ? raw.rpm / 4 : this.diagnostics.obdValue(0x0c, now);
        const speed = finite(raw.speed) && raw.speed < 65535 ? raw.speed / 64 : this.diagnostics.obdValue(0x0d, now);
        return { rpm, speed };
    }

    enginePage(values, raw, now, motion = this.motion(raw, now), air = this.air(now, values, raw)) {
        const { rpm, speed } = motion;
        const engine = Object.assign({}, values);
        const sae = values.sae;
        if (finite(rpm) && values.rpm === '--') engine.rpm = n(rpm, 'rpm');
        const torque = values.torque !== '--' ? raw.torque / 2 - 1023.5 :
            this.diagnostics.obdValue(0x62, now) * this.diagnostics.obdValue(0x63, now) / 100;
        if (values.torque === '--' && finite(torque)) engine.torque = reading(torque, 'Nm', sae);
        if (values.power === '--' && finite(torque) && finite(rpm)) engine.power = n(rpm * torque / 9549.3 * 1.341, 'hp');
        if (finite(speed) && values.speed === '--') engine.speed = reading(speed, 'km/h', sae);
        if (finite(air.boost)) engine.boost = pressure(air.boost, sae, sae ? 1 : 2);
        if (values.oil === '--') engine.oil = temperature(this.diagnostics.obdValue(0x5c, now), sae).replace('—', '--');
        if (values.coolant === '--') engine.coolant = temperature(this.diagnostics.obdValue(0x05, now), sae).replace('—', '--');
        engine.intake = temperature(air.intake, sae).replace('—', '--');
        engine.heat = temperatureDifference(air.heat, sae).replace('—', '--');
        engine.gear = this.engineGear(liveGear(raw, speed), speed, now) || '';
        if (this.lastSae !== sae) { this.peaks = {}; this.lastSae = sae; }
        if (this.page === 'engine') PEAKS.forEach((key) => {
            const value = parseFloat(engine[key]);
            if (finite(value) && (!finite(this.peaks[key]) || value > this.peaks[key])) this.peaks[key] = value;
        });
        engine.peaks = this.peaks;
        engine.scales = this.display.scales;
        engine.thresholds = this.display.thresholds;
        return engine;
    }

    update(values, raw, now) {
        const motion = this.page === 'engine' ? this.motion(raw, now) : undefined;
        const gearRequest = motion ? this.engineGearRequest(liveGear(raw, motion.speed), now) : undefined;
        if (!this.mhd.pending) this.diagnostics.tick(this.requests(now), now, gearRequest);
        const sae = values.sae;
        this.display.sae = sae;
        const frame = { page: this.page, pages: PAGES };
        if (this.page === 'engine') {
            frame.engine = this.enginePage(values, raw, now, motion);
            if (this.display.mhdStrip) frame.engine.mhd = this.mhd.view();
        }
        if (this.page === 'fuel') frame.content = this.fuelPage(values, raw, now);
        if (this.page === 'transmission') frame.content = this.transmissionPage(sae, now);
        if (this.page === 'details') frame.content = this.detailsPage(now, raw, sae);
        if (this.page === 'faults') frame.content = this.faults.update(now);
        if (this.page === 'settings') frame.content = { settings: this.display.view() };
        return frame;
    }

    fuelPage(values, raw, now) {
        const sae = values.sae;
        const fuel = this.fuel(now, this.air(now, values, raw, true));
        if (now - this.historyAt >= HISTORY_SAMPLE_MS) {
            this.historyAt = now;
            Object.keys(fuel).forEach((key) => this.sample(key, fuel[key], now));
        }
        const lph = this.fuelFlow(raw, now);
        const readings = [
            ['Intake air', temperature(fuel.intake, sae), 'intake'], ['Intake above outside', temperatureDifference(fuel.heat, sae), 'heat'],
            ['Fuel rail pressure', pressure(fuel.hp, sae, 0), 'hp'], ['Low-pressure fuel', pressure(fuel.lp, sae, 1), 'lp'],
            ['Ignition advance', n(fuel.timing, '°', 1), 'timing'], ['Boost', pressure(fuel.boost, sae, sae ? 1 : 2), 'boost', 'target'],
        ];
        return { subtitle: '5-minute history', readout: { label: 'Fuel flow', metric: 'flow',
            value: reading(lph, 'L/h', sae, 1) }, cards: readings.map(([title, value, key, other]) => ({ title, value, metric: key,
            trace: this.trace(key, now), trace2: other ? this.trace(other, now) : undefined,
            target: other && finite(fuel.target) ? pressure(fuel.target, sae, sae ? 1 : 2) : undefined })) };
    }

    transmissionPage(sae, now) {
        const variant = this.gearbox(now);
        if (!EGS_VARIANTS[variant]) return { subtitle: 'Gearbox diagnostics', cards: [{ title: 'Transmission',
            rows: [['Variant', variant || '—'], ['Status', variant ? 'Unsupported gearbox variant' : this.diagnostics.status]] }] };
        const value = (id, keep) => {
            const req = uds(parseInt(id, 16), 0, EGS);
            const record = decodeEgs(id, this.diagnostics.reply(req, now, keep ? 600000 : 10000),
                id === '4441' && variant === '0F21E0' ? { raw: true } : undefined);
            return record.ok ? record.values : [];
        };
        const gear = readGear(this.diagnostics.reply(EGS_GEAR, now, 10000));
        const speeds = value('DA2A');
        const engine = value('DA34')[0];
        const times = value('4441', true);
        const total = times.reduce((sum, v) => sum + v, 0);
        const ranges = [['Below 40', 0, 4], ['40 to 70', 4, 6], ['70 to 100', 6, 10], ['100 to 120', 10, 14], ['Above 120', 14, 23]];
        const limit = (label) => sae ? label.replace(/\d+/g, (v) => Math.round(Number(v) * 1.8 + 32)) + ' °F' : label + ' °C';
        const percent = (first, last) => times.slice(first, last).reduce((sum, v) => sum + v, 0) / total * 100;
        const adaptations = ['413A', '4140', '4131', '4130'].map((id) => value(id, true));
        return { subtitle: EGS_VARIANTS[variant] + '   ' + variant, cards: [
            { title: 'Live gearbox', rows: [['Gear', text(EGS_GEARS[gear[0]])], ['Selector', text(EGS_POSITIONS[gear[1]])],
                ['Oil temperature', temperature(value('6000')[0], sae)], ['Input speed', n(speeds[0], 'rpm')], ['Output speed', n(speeds[1], 'rpm')],
                ['Converter slip', variant === '0F21E0' ? 'No converter' : n(engine - speeds[0], 'rpm')], ['Lock-up', text(TCC[value('DA22')[0]])]] },
            { title: 'Clutch adaptations', rows: [].concat(...[0, 1, 2, 3, 4].map((i) => [
                ['Clutch ' + 'ABCDE'[i], pressure(adaptations[0][i] / 1000, sae, 2) + '   ' + n(adaptations[1][i], 'ms')],
                ['Evaluations (P / T)', text(adaptations[2][i]) + ' / ' + text(adaptations[3][i])],
            ])) },
            { title: 'Oil temperature history', rows: ranges.map(([label, first, last]) => [limit(label), n(percent(first, last), '%')])
                .concat([['Operating hours', n(value('6081', true)[0] / 60, 'h')]]) },
        ] };
    }

    detailsPage(now, raw, sae) {
        const cards = DETAIL_PAGES[this.offset].cards.map(({ title, metric, items }) => {
            if (!items) return { title, metric, rows: this.dataLinkRows(raw) };
            const rows = items.map((item) => {
                const value = detailValue(item, this.diagnostics, now);
                return [item.name, finite(value) ? reading(value, item.u, sae, item.d, !!item.minus) : text(value)];
            });
            return { title, metric, rows };
        });
        return { subtitle: 'Engine data   ' + (this.offset + 1) + ' / ' + DETAIL_PAGES.length,
            controls: [{ id: 'previous', label: 'Previous', disabled: this.offset === 0 },
                { id: 'next', label: 'Next', disabled: this.offset === DETAIL_PAGES.length - 1 }], cards };
    }

    dataLinkRows(raw) {
        const stats = this.diagnostics.link && this.diagnostics.link.stats;
        return [['Diagnostic service', this.diagnostics.status],
            ['Vehicle speed (SOME/IP)', finite(raw.speed) ? 'Receiving' : 'Waiting'],
            ['Engine speed (SOME/IP)', finite(raw.rpm) ? 'Receiving' : 'Waiting'],
            ['Vbatt (LevelMonitor)', finite(raw.voltage) ? 'Receiving' : 'Waiting'],
            ['Requests sent', text(stats && stats.sent)], ['Replies', text(stats && stats.replies)],
            ['Timeouts', text(stats && stats.missed)], ['Average reply time', n(stats && stats.timed ? stats.ms / stats.timed : undefined, 'ms')]];
    }

}

module.exports = { Features };
