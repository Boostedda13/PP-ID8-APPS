'use strict';

const { displayUnit, toDisplay, fromDisplay, formatBoost } = require('./units');

// [label, native unit, default max, min, max, Metric hold step, SAE hold step]
const SCALES = {
    rpm: ['Engine speed', 'rpm', 8000, 5000, 12000, 100, 100],
    boost: ['Boost', 'bar', 2.5, 0.5, 5, 1, 5],
    power: ['Power', 'hp', 500, 200, 1500, 10, 10],
    torque: ['Torque', 'Nm', 700, 300, 1500, 10, 10],
    oil: ['Engine oil', '°C', 150, 100, 180, 5, 10],
    coolant: ['Coolant', '°C', 130, 100, 160, 5, 10],
    intake: ['Intake air', '°C', 80, 40, 120, 5, 10],
    heat: ['Above outside', '°C', 80, 40, 120, 5, 10],
};
const LIMITS = new Set(['rpm', 'boost', 'oil', 'coolant', 'intake', 'heat']);
const LEVELS = ['warn', 'alarm'];
const finite = Number.isFinite;
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const own = (object, key) => Object.prototype.hasOwnProperty.call(object, key);

function display(value, unit, sae, difference = false) {
    if (unit === 'bar') return formatBoost(value, sae);
    return toDisplay(value, unit, sae, difference).toFixed(0) + ' ' + displayUnit(unit, sae);
}

class DisplaySettings {
    constructor(saved) {
        this.scales = {};
        this.thresholds = {};
        for (const [key, [, , fallback, min, max]] of Object.entries(SCALES)) {
            const value = saved.scales && saved.scales[key];
            const initial = key === 'heat' ? this.scales.intake : fallback;
            this.scales[key] = finite(value) && value >= min && value <= max ? value : initial;
        }
        for (const key of LIMITS) {
            const source = saved.thresholds && saved.thresholds[key];
            const max = SCALES[key][4];
            const entry = {};
            for (const level of LEVELS) {
                if (!source || !finite(source[level]) || source[level] < 0 || source[level] > max) continue;
                entry[level] = source[level];
                if (source[level + 'Off'] === true) entry[level + 'Off'] = true;
            }
            if (entry.warn > entry.alarm && !entry.warnOff && !entry.alarmOff) entry.warnOff = true;
            if (Object.keys(entry).length) this.thresholds[key] = entry;
        }
        this.units = saved.units === 'sae' || saved.units === 'metric' ? saved.units : undefined;
        this.mhdStrip = saved.mhdStrip === true;
        this.sae = this.units === 'sae';
    }

    get override() { return this.units === undefined ? undefined : this.units === 'sae'; }

    saved() { return { scales: this.scales, thresholds: this.thresholds, units: this.units, mhdStrip: this.mhdStrip }; }

    move(value, unit, difference, step) {
        const displayValue = toDisplay(value, unit, this.sae, difference);
        return Number(fromDisplay(displayValue + step, unit, this.sae, difference).toFixed(9));
    }

    bounds(key, level) {
        const values = this.thresholds[key] || {};
        const max = this.scales[key];
        if (level === 'warn') return [0, !values.alarmOff && finite(values.alarm) ? Math.min(max, values.alarm) : max];
        const min = !values.warnOff && finite(values.warn) ? values.warn : 0;
        return [min, Math.max(max, min)];
    }

    editThreshold(key, level, direction, held) {
        const limits = this.thresholds[key] || {};
        const existing = limits[level];
        const off = level + 'Off';
        const [min, max] = this.bounds(key, level);
        const [, unit, , , , metricStep, saeStep] = SCALES[key];
        if (direction === 'on') {
            if (finite(existing) && !limits[off]) {
                limits[off] = true;
            } else {
                const defaultValue = this.scales[key] * (level === 'warn' ? 0.75 : 0.9);
                const hint = finite(existing) ? existing : Number(defaultValue.toFixed(unit === 'bar' ? 2 : 0));
                limits[level] = clamp(hint, min, max);
                delete limits[off];
                this.thresholds[key] = limits;
            }
            return true;
        }
        if (!finite(existing) || limits[off] || (direction !== '+' && direction !== '-')) return false;
        let step = 1;
        if (held) {
            if (key === 'rpm') step = 100;
            else if (unit === 'bar') step = this.sae ? saeStep : metricStep;
            else step = this.sae ? 10 : 5;
        }
        const value = clamp(this.move(existing, unit, key === 'heat', direction === '+' ? step : -step), min, max);
        if (value === existing) return false;
        limits[level] = value;
        return true;
    }

    action(id, held = false) {
        if (id === 'settings:mhd') {
            this.mhdStrip = !this.mhdStrip;
            return true;
        }
        const [key, control, direction] = id.split(':');
        if (key === 'units' && (control === 'metric' || control === 'sae')) {
            if (this.units === control) return false;
            this.units = control;
            this.sae = control === 'sae';
            return true;
        }
        if (LIMITS.has(key) && LEVELS.includes(control)) return this.editThreshold(key, control, direction, held);
        if (!own(SCALES, key) || (control !== '+' && control !== '-')) return false;
        const [, unit, , min, max, metricStep, saeStep] = SCALES[key];
        const step = held ? (this.sae ? saeStep : metricStep) : 1;
        const existing = this.scales[key];
        const value = clamp(this.move(existing, unit, key === 'heat', control === '+' ? step : -step), min, max);
        if (value === existing) return false;
        this.scales[key] = value;
        return true;
    }

    card(key, label, unit, max) {
        const values = this.thresholds[key] || {};
        const limits = LIMITS.has(key) ? LEVELS.map((level) => {
            const [low, high] = this.bounds(key, level);
            const value = values[level];
            const enabled = finite(value) && !values[level + 'Off'];
            return { key: level, enabled, value: enabled ? display(value, unit, this.sae, key === 'heat') : '',
                canMinus: enabled && value > low, canPlus: enabled && value < high };
        }) : [];
        return { key, label, max, limits };
    }

    view() {
        const cards = Object.entries(SCALES).map(([key, [label, unit, , min, max]]) => {
            const value = this.scales[key];
            return this.card(key, label, unit, { value: display(value, unit, this.sae, key === 'heat'), canMinus: value > min, canPlus: value < max });
        });
        const ordered = cards.filter(({ limits }) => limits.length).concat(cards.filter(({ limits }) => !limits.length));
        return { sae: this.sae, cards: ordered, mhdStrip: this.mhdStrip };
    }
}

module.exports = DisplaySettings;
