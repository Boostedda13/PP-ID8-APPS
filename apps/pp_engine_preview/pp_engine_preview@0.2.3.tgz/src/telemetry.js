'use strict';

const { sources } = require('./engine-config.js');

const REFRESH_MS = 500;
const STALE_MS = 5000;
const RETRY_MS = 15000;

function numberIn(value, lower, upper) {
    return Number.isFinite(value) && value >= lower && value <= upper;
}

function pressureUnit(raw) {
    if (raw === 'BAR' || raw === 'KPA' || raw === 'PSI') return raw;
    if (raw === 1 || raw === 2 || raw === 3) return ['BAR', 'KPA', 'PSI'][raw - 1];
    return undefined;
}

function voltage(raw) {
    if (!numberIn(raw, 6, 18000)) return undefined;
    const scaled = raw >= 5000 ? raw / 1000 : raw >= 500 ? raw / 100 : raw >= 50 ? raw / 10 : raw;
    return numberIn(scaled, 6, 18) ? scaled : undefined;
}

// Vehicle signal fields and scales follow the MIT-licensed iDrive App Kit.
function readings(raw) {
    const rpm = numberIn(raw.rpm, 0, 65534) ? raw.rpm / 4 : undefined;
    const torque = numberIn(raw.torque, 0, 4095) ? raw.torque / 2 - 1023.5 : undefined;
    const unit = pressureUnit(raw.pressureUnit);
    const sae = unit === 'PSI';
    const temperature = (value) => numberIn(value, 0, 254)
        ? (sae ? (value - 48) * 1.8 + 32 : value - 48) : undefined;
    const format = (value, digits, suffix) => value === undefined ? '--' : value.toFixed(digits) + ' ' + suffix;
    return {
        rpm: format(rpm, 0, 'rpm'),
        boost: format(unit && numberIn(raw.boost, 0, 254) ? raw.boost * (sae ? 0.1 : 0.01) : undefined,
            sae ? 1 : 2, sae ? 'psi' : 'bar'),
        power: format(rpm === undefined || torque === undefined ? undefined : rpm * torque / 9549.3 * 1.341, 0, 'hp'),
        torque: format(sae && torque !== undefined ? torque * 0.737562149 : torque, 0, sae ? 'lb-ft' : 'Nm'),
        speed: format(numberIn(raw.speed, 0, 65534) ? raw.speed * (sae ? 0.621371192 / 64 : 1 / 64) : undefined,
            0, sae ? 'mph' : 'km/h'),
        oil: format(temperature(raw.oil), 0, sae ? 'deg F' : 'deg C'),
        coolant: format(temperature(raw.coolant), 0, sae ? 'deg F' : 'deg C'),
        voltage: format(voltage(raw.voltage), 1, 'V'),
        sae,
    };
}

class Telemetry {
    constructor(connect, onReadings) {
        this.connect = connect;
        this.onReadings = onReadings;
        this.links = sources.map((source) => ({ source, proxy: null, pending: false, due: 0, events: {} }));
        this.session = null;
    }

    show(background = false) {
        if (this.session && this.session.background === background) return;
        this.hide();
        const session = { raw: {}, timer: null, background };
        this.session = session;
        this.links.forEach((link) => { link.due = 0; });
        session.timer = setInterval(() => this.refresh(session), background ? 1000 : REFRESH_MS);
        this.refresh(session);
    }

    hide() {
        if (!this.session) return;
        clearInterval(this.session.timer);
        this.session = null;
    }

    refresh(session) {
        const now = Date.now();
        const raw = {};
        for (const key of Object.keys(session.raw)) {
            const sample = session.raw[key];
            if (now - sample.at < STALE_MS) raw[key] = sample.value;
        }
        if (!session.background) for (const link of this.links) Object.assign(raw, link.events);
        this.onReadings(session.background ? null : readings(raw), raw, now);
        if (this.session !== session) return;
        for (const link of this.links) {
            if (link.source.subscribeOnly && link.proxy) continue;
            if (!link.pending && now >= link.due && (!session.background || link.source.background)) this.poll(link, session);
        }
    }

    async poll(link, session) {
        link.pending = true;
        const source = link.source;
        link.due = Date.now() + source.intervalMs;
        try {
            if (!link.proxy) {
                link.proxy = await this.connect(source.interface, source.instance, { timeoutMs: 5000 });
            }
            if (source.subscribeOnly) {
                await Promise.all(Object.keys(source.attributes).map(async (name) => {
                    const property = link.proxy[name];
                    if (!property || typeof property.subscribe !== 'function') return;
                    try {
                        await property.subscribe((value) => {
                            if (!value) return;
                            const columns = source.attributes[name];
                            for (const key of Object.keys(columns)) link.events[key] = value[columns[key]];
                        });
                    } catch (error) {
                        // A notifier absent on this firmware leaves the other gear sources available.
                    }
                }));
                return;
            }
            if (this.session !== session) return;
            const attributes = session.background ? source.background : Object.keys(source.attributes);
            await Promise.all(attributes.map(async (name) => {
                const property = link.proxy[name];
                if (!property || typeof property.getValue !== 'function') return;
                try {
                    const result = await property.getValue();
                    if (this.session !== session) return;
                    const columns = source.attributes[name];
                    const at = Date.now();
                    for (const key of Object.keys(columns)) {
                        session.raw[key] = { value: result && result[columns[key]], at };
                    }
                } catch (error) {
                    // A single missing getter does not prevent other attributes from updating.
                }
            }));
        } catch (error) {
            link.proxy = null;
            link.due = Date.now() + RETRY_MS;
        } finally {
            link.pending = false;
        }
    }
}

module.exports = { Telemetry, readings };
