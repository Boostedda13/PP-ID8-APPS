'use strict';

const OnlineApp = require('oap-sdk/src/core/OnlineApp.js');
const someipBuilders = require('oap-sdk/src/someip/someipBuilders');
const path = require('path');
const { id, rows } = require('./engine-config.js');
const { Telemetry } = require('./telemetry.js');
const connect = (name, instance, options) => someipBuilders.buildAndInitTypedProxy(name, instance, options);
const SOURCE = typeof __dirname === 'string' ? path.join(__dirname, '..') :
    path.join('/var/opt/public/oap', 'oap_' + process.getuid(), 'source');
const FOCUS_GRACE_MS = 300;

class EnginePage extends OnlineApp {
    constructor() {
        super();
        this.initialization = null;
        this.entryUuid = null;
        this.stopping = false;
        this.visible = false;
        this.focused = true;
        this.focusTimer = null;
        this.fields = {};
        this.painting = false;
        this.dashboard = null;
        this.features = null;
        this.latest = null;
        this.telemetry = new Telemetry(connect, (values, raw, now) => {
            if (values) this.paint(values, raw, now);
            else if (this.features) {
                this.features.updateTrip(raw, now, false);
                if (!this.features.trips.cur) this.telemetry.hide();
            }
        });
        this.on('initialized', () => {
            if (this.initialization) return;
            this.initialization = this.setup().catch((error) => console.error('PP DATA setup:', error.message));
        });
        this.on('entryPointExecute', (uuid) => {
            if (!this.initialization) return;
            this.initialization.then(() => this.open(uuid))
                .catch((error) => console.error('PP DATA open:', error.message));
        });
        this.on('shutdown', () => this.stop());
        this.on('changeVisibility', (event) => {
            if (event && event.visible != null && !flag(event.visible)) this.setVisible(false);
        });
        this.on('error', (error) => console.error('PP DATA:', error.message));
    }

    async setup() {
        const rhmi = this.rhmiApplication;
        if (!rhmi) return this.initialized();

        const screen = rhmi.getByName('ENGINE');
        if (!screen) throw new Error('ENGINE state unavailable');
        await screen.updateResources();
        try {
            // The Store links this file into javascript/app.js. The renderer is loaded from the installed package.
            const { EngineDashboard } = require(path.join(SOURCE, 'renderer', 'dashboard.js'));
            const { Features } = require(path.join(SOURCE, 'data', 'features.js'));
            this.features = new Features(connect, path.join(SOURCE, '..', 'data'));
            this.dashboard = new EngineDashboard(id, (action) => {
                if (!this.latest || !this.visible || !this.focused || this.stopping) return;
                this.features.action(action);
                this.paint(...this.latest);
            });
        } catch (error) {
            console.warn('PP DATA dashboard unavailable:', error.message);
        }
        for (const key of Object.keys(rows)) {
            const component = rhmi.getByName('METRIC_' + key.toUpperCase());
            if (component) this.fields[key] = { component, shown: null };
        }
        screen.on('visible', (event) => this.setVisible(event && flag(event.visible)));
        screen.on('focus', (event) => {
            clearTimeout(this.focusTimer);
            if (event && flag(event.focus)) {
                this.focused = true;
                this.updateTelemetry();
            } else if (this.visible) {
                // HMI transitions briefly drop focus. Pause only for sustained focus loss.
                this.focusTimer = setTimeout(() => {
                    this.focused = false;
                    this.updateTelemetry();
                }, FOCUS_GRACE_MS);
            }
        });

        const descriptor = this.appDescription.application.entryPoints[0];
        const entry = this.getEntryPoints().find((item) => item.getDescription().uuid === descriptor.uuid);
        if (entry) {
            await entry.init();
            await rhmi.mapEntryState(descriptor.uuid, screen);
            try {
                await entry.entryPoint.setText(descriptor.textId);
                await entry.entryPoint.setIcon(descriptor.icon);
            } catch (error) {
                console.warn('PP DATA tile resources:', error.message);
            }
            await entry.setAvailability('ENABLED');
            this.entryUuid = descriptor.uuid;
        }

        const lastEntry = this.getLastExecutedEntryPointUuid && this.getLastExecutedEntryPointUuid();
        const visibility = this.getVisibilityData && this.getVisibilityData();
        if (lastEntry || (visibility && visibility.visible)) {
            try {
                await this.registerActive();
            } catch (error) {
                console.warn('PP DATA active status:', error.message);
            }
        }
        await this.initialized();
        if (lastEntry) await this.open(lastEntry);
    }

    async open(uuid) {
        if (this.stopping || !this.entryUuid || uuid !== this.entryUuid) return;
        await this.rhmiApplication.openEntryState(uuid);
    }

    setVisible(visible) {
        clearTimeout(this.focusTimer);
        this.visible = !!visible;
        if (this.visible) this.focused = true;
        this.updateTelemetry();
    }

    updateTelemetry() {
        if (this.visible && this.focused && !this.stopping) {
            if (this.dashboard) this.dashboard.show();
            this.telemetry.show();
        } else {
            if (this.dashboard) this.dashboard.hide();
            if (this.features && this.latest) this.features.pause();
            this.latest = null;
            if (this.features && this.features.trips.cur && !this.stopping) this.telemetry.show(true);
            else this.telemetry.hide();
        }
    }

    async paint(values, raw, now) {
        this.latest = [values, raw, now];
        let view = { page: 'engine', pages: [], engine: values };
        if (this.features) {
            try {
                view = this.features.update(values, raw, now);
            } catch (error) {
                if (!this.featureError) console.warn('PP DATA pages:', error.message);
                this.featureError = true;
            }
        }
        if (this.dashboard && this.dashboard.update(view)) return;
        if (this.painting) return;
        this.painting = true;
        try {
            await Promise.all(Object.keys(this.fields).map(async (key) => {
                const field = this.fields[key];
                const text = rows[key] + '  ' + (view.engine[key] || '--').replace('°', 'deg ');
                if (field.shown === text) return;
                try {
                    await field.component.setValue(0, 'Text', text, 'Text');
                    field.shown = text;
                } catch (error) {
                    // The state can disappear while the SDK is updating a cell.
                }
            }));
        } finally {
            this.painting = false;
        }
    }

    async stop() {
        if (this.stopping) return;
        this.stopping = true;
        clearTimeout(this.focusTimer);
        this.updateTelemetry();
        try {
            if (this.initialization) await this.initialization;
            if (this.features && this.features.trips.cur) this.features.saveTrip(Date.now());
            await this.destroyBundles();
        } catch (error) {
            console.error('PP DATA shutdown:', error.message);
        }
        process.exit(0);
    }
}

const flag = (value) => value === true || value === 1 || value === 'true' || value === '1';
const app = new EnginePage();
app.start().catch((error) => console.error('PP DATA start:', error.message));
