'use strict';

const { Recorder } = require('./kit/record');
const { METRIC_COLORS, PAGE_COLORS } = require('./colors');

const SCREEN = { w: 2880, h: 960 };
const APP = { y: 76, h: 764 };
const WHITE = '#ffffff';
const BORDER = '#282828';
const VALUE_FONT = { font: 'value' };
const GRID = { x: 40, y: 177, w: 2800, h: 639, gap: 20 };

function button(canvas, box, label, selected, disabled) {
    const { x, y, w, h } = box;
    canvas.strokeRoundRect(x, y, w, h, 9, 2, selected ? WHITE : BORDER);
    canvas.text(label, x + w / 2, y + h / 2 + 10, disabled ? 28 : 30, WHITE, { align: 'center' });
}

function drawTabs(canvas, pages, active) {
    if (!pages.length) return [];
    const gap = 18;
    const width = (GRID.w - (pages.length - 1) * gap) / pages.length;
    return pages.map(([key, label], index) => {
        const box = { x: GRID.x + (width + gap) * index, y: APP.y + 12, w: width, h: 46 };
        button(canvas, box, label, key === active);
        return Object.assign({ id: 'page:' + key }, box);
    });
}

function fit(canvas, value, width, size, opts) {
    const str = String(value);
    if (canvas.textWidth(str, size, opts) <= width) return str;
    let end = str.length - 1;
    while (end > 1 && canvas.textWidth(str.slice(0, end) + '…', size, opts) > width) end--;
    return str.slice(0, end) + '…';
}

function plot(canvas, a, b, x, y, w, h, color) {
    const sample = a.concat(b).filter(Number.isFinite);
    if (!sample.length) return;
    const min = Math.min(...sample);
    const max = Math.max(...sample);
    const margin = (max - min) * 0.06 || 0.5;
    const lo = min - margin;
    const span = max - min + 2 * margin;
    for (const ratio of [0, 0.5, 1]) canvas.fillRect(x, y + ratio * h, w, 1, BORDER);
    const len = Math.max(a.length, b.length, 2);
    for (const [points, shade] of [[a, color], [b, METRIC_COLORS.rpm]]) {
        let previous;
        points.forEach((value, index) => {
            if (!Number.isFinite(value)) { previous = null; return; }
            const point = [x + w * (index + len - points.length) / (len - 1), y + h - (value - lo) / span * h];
            if (previous) canvas.line(previous[0], previous[1], point[0], point[1], 3, shade);
            else canvas.roundRect(point[0] - 2, point[1] - 2, 4, 4, 2, shade);
            previous = point;
        });
    }
}

function cell(index, count, area) {
    const cols = Math.min(count, 3);
    const rows = Math.ceil(count / cols);
    const w = (area.w - (cols - 1) * area.gap) / cols;
    const h = (area.h - (rows - 1) * area.gap) / rows;
    return { x: area.x + index % cols * (w + area.gap), y: area.y + Math.floor(index / cols) * (h + area.gap), w, h };
}

function measurementParts(value) {
    const measurement = /^(-?\d+(?:\.\d+)?)( [^\d]+| L\/100 km)$/.exec(value);
    return measurement ? [measurement[1], measurement[2]] : [value, ''];
}

function measurementWidth(canvas, [value, unit], size) {
    return canvas.textWidth(value, size, VALUE_FONT) + canvas.textWidth(unit, size);
}

function drawMeasurement(canvas, parts, x, y, size, color, rightAligned) {
    const left = rightAligned ? x - measurementWidth(canvas, parts, size) : x;
    const advance = canvas.text(parts[0], left, y, size, WHITE, VALUE_FONT);
    if (parts[1]) canvas.text(parts[1], left + advance, y, size, color);
}

function drawCard(canvas, box, card, pageColor) {
    const { x, y, w, h } = box;
    const left = x + 30;
    const right = x + w - 30;
    const color = METRIC_COLORS[card.metric] || pageColor;
    canvas.strokeRoundRect(x, y, w, h, 17, 2, BORDER);
    canvas.text(fit(canvas, card.title, w - 60, 36), left, y + 53, 36, color);
    if (card.rows) {
        const step = Math.min(54, (h - 87) / Math.max(1, card.rows.length));
        const size = Math.min(32, Math.floor(step * 0.7));
        card.rows.forEach(([label, value], index) => {
            const baseline = y + 80 + step * (index + 0.55);
            const reading = measurementParts(fit(canvas, value, (w - 60) * 0.47, size, VALUE_FONT));
            const limit = w - 96 - measurementWidth(canvas, reading, size);
            canvas.text(fit(canvas, label, limit, size), left, baseline, size, color);
            drawMeasurement(canvas, reading, right, baseline, size, color, true);
            canvas.fillRect(left, baseline + step * 0.24, w - 60, 1, BORDER);
        });
    } else if (card.value !== undefined) {
        const pieces = card.value.split(' ');
        const number = pieces.shift();
        const advance = canvas.text(number, left, y + 134, 72, WHITE, { font: 'num' });
        canvas.text(pieces.join(' '), left + advance + 16, y + 134, 34, color);
        if (card.target) {
            const targetColor = METRIC_COLORS.rpm;
            const target = measurementParts(card.target);
            canvas.text('Target  ', right - measurementWidth(canvas, target, 29), y + 134, 29, targetColor, { align: 'right' });
            drawMeasurement(canvas, target, right, y + 134, 29, targetColor, true);
        }
        if (card.trace) plot(canvas, card.trace, card.trace2 || [], left, y + 174, w - 60, Math.max(30, h - 209), color);
    }
}

class ContentGrid {
    constructor(scale) {
        this.recording = new Recorder(SCREEN.w, SCREEN.h, { textScale: scale });
        this.targets = [];
        this.last = '';
    }

    update(view) {
        const key = JSON.stringify(view);
        if (key === this.last) return false;
        this.last = key;
        const canvas = this.recording.reset().clear();
        canvas.fillRect(0, APP.y, SCREEN.w, APP.h, '#000000');
        this.targets = drawTabs(canvas, view.pages, view.page);
        const content = view.content || {};
        const pageColor = PAGE_COLORS[view.page] || WHITE;
        if (content.subtitle) canvas.text(content.subtitle, GRID.x, 162, 25, WHITE);
        (content.controls || []).forEach((control, index, all) => {
            const box = { x: SCREEN.w - GRID.x - (all.length - index) * 216 + 16, y: 140, w: 200, h: 39 };
            button(canvas, box, control.label, control.selected, control.disabled);
            if (!control.disabled) this.targets.push(Object.assign({ id: control.id }, box));
        });
        if (content.settings) {
            content.settings.forEach(([key, label, value], index) => {
                const box = cell(index, content.settings.length, GRID);
                canvas.strokeRoundRect(box.x, box.y, box.w, box.h, 17, 2, BORDER);
                const color = METRIC_COLORS[key] || pageColor;
                canvas.text(label, box.x + 30, box.y + 54, 36, color);
                drawMeasurement(canvas, measurementParts(value), box.x + 30, box.y + 129, 40, color);
                ['-', '+'].forEach((symbol, i) => {
                    const target = { x: box.x + box.w - 32 - (2 - i) * 105, y: box.y + 86, w: 90, h: 60 };
                    button(canvas, target, symbol);
                    this.targets.push(Object.assign({ id: key + ':' + symbol }, target));
                });
            });
        } else if (content.cards) {
            content.cards.forEach((card, index) => drawCard(canvas, cell(index, content.cards.length, GRID), card, pageColor));
        }
        return true;
    }
}

module.exports = { ContentGrid, drawTabs, SCREEN, APP };
