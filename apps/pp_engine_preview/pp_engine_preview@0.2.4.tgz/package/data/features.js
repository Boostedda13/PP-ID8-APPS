'use strict';

const fs = require('fs');
const path = require('path');
const { Diagnostics, uds, obd, EGS } = require('./diagnostics');
const { PAGES, ENGINE_READS, FUEL_READS, TRIP_FUEL, GEARBOX_ID, EGS_LIVE, EGS_HISTORY,
    ENGINE_GROUPS, DETAILS_READS, detailValue } = require('./catalog');
const { Trips, per100 } = require('./kit/trips');
const Flow = require('./kit/flow');
const { decode: decodeEgs, TCC } = require('./egs/egs');

const PEAKS = ['rpm', 'boost', 'power', 'torque'];
const HISTORY_SAMPLE_MS = 5000;
const HISTORY_WINDOW_MS = 300000;
const CURRENCY = ['USD', 'EUR', 'CAD', 'GBP', 'AUD', 'NZD', 'CHF', 'SEK', 'NOK', 'DKK', 'PLN', 'CZK', 'HUF', 'RON', 'ZAR', 'TRY'];
const PERIODS = [['today', 'Today'], ['week', '7 Days'], ['month', '30 Days']];
const SCALES = [
    ['rpm', 'Engine speed', 'rpm', 8000, 500, 5000, 12000], ['boost', 'Boost', 'bar', 2.5, 0.25, 0.5, 5],
    ['power', 'Power', 'hp', 500, 25, 200, 1500], ['torque', 'Torque', 'Nm', 700, 50, 300, 1500],
    ['oil', 'Engine oil', '°C', 150, 5, 100, 180], ['coolant', 'Coolant', '°C', 130, 5, 100, 160],
    ['intake', 'Intake air', '°C', 80, 5, 40, 120],
];
const EGS_VARIANTS = { '0F25D0': 'ZF 8HP', '0F21E0': 'ZF 8HP Hybrid' };
const EGS_GEARS = { 0: 'P', 1: 'R', 2: 'N', 3: '1', 4: '2', 5: '3', 6: '4', 7: '5', 8: '6', 9: '7', 16: '8' };
const EGS_POSITIONS = ['P', 'R', 'N', 'D', 'M'];
const RUN = { MOTOR_AUS: 'off', MOTOR_STARTET: 'starting', MOTOR_LAEUFT: 'running', 0: 'off', 1: 'starting', 2: 'running' };
const finite = Number.isFinite;
const n = (value, unit, digits) => finite(value) ? value.toFixed(digits || 0) + (unit ? ' ' + unit : '') : '—';
const text = (value) => value === undefined || value === null ? '—' : String(value);
const u16 = (data, index) => data && data.length > index + 1 ? data[index] * 256 + data[index + 1] : undefined;
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

function read(file) {
    try { return JSON.parse(fs.readFileSync(file, 'utf8')) || {}; } catch (error) { return {}; }
}

function write(file, value) {
    try {
        fs.writeFileSync(file + '.tmp', JSON.stringify(value));
        fs.renameSync(file + '.tmp', file);
    } catch (error) {
        console.warn('PP DATA storage:', error.message);
    }
}

function gearFrom(raw, diagnostic) {
    const stage = { 1: 'P', 2: 'R', 3: 'N', 4: 'D', P: 'P', R: 'R', N: 'N', D: 'D' }[raw.stage];
    if (stage && stage !== 'D') return stage;
    const gear = typeof raw.gear === 'number' && raw.gear >= 3 && raw.gear <= 12 ? raw.gear - 2 :
        (/^G\d+$/.test(String(raw.gear)) ? Number(raw.gear.slice(1)) : undefined);
    if (finite(gear)) return 'D' + gear;
    if (raw.speed > 0 && Number.isInteger(raw.displayGear) && raw.displayGear >= 20 && raw.displayGear <= 27) {
        return 'D' + (raw.displayGear - 19);
    }
    return diagnostic && diagnostic.length >= 4 && (diagnostic[2] & 2) && (diagnostic[3] >> 4) ?
        'D' + (diagnostic[3] >> 4) : stage;
}

function temperature(value, sae) { return n(sae && finite(value) ? value * 1.8 + 32 : value, sae ? '°F' : '°C'); }
function temperatureDifference(value, sae) { return n(sae ? value * 1.8 : value, sae ? '°F' : '°C'); }
function pressure(value, sae, digits) { return n(sae && finite(value) ? value * 14.5037738 : value, sae ? 'psi' : 'bar', digits); }
function elapsed(ms) { const mins = Math.floor(ms / 60000); return Math.floor(mins / 60) + ' h ' + mins % 60 + ' min'; }

class Features {
    constructor(connect, directory) {
        this.diagnostics = new Diagnostics(connect);
        this.settingsFile = path.join(directory, 'pp-settings.json');
        this.tripsFile = path.join(directory, 'pp-trips.json');
        const saved = read(this.settingsFile);
        this.scales = {};
        for (const [key, , , fallback, , min, max] of SCALES) {
            const limit = saved.scales && saved.scales[key];
            this.scales[key] = finite(limit) && limit >= min && limit <= max ? limit : fallback;
        }
        this.currency = CURRENCY.includes(saved.currency) ? saved.currency : 'USD';
        this.fuelPrice = finite(saved.fuelPrice) ? clamp(saved.fuelPrice, 0, 10000) : 1.8;
        this.flow = new Flow(finite(saved.fuelScale) && saved.fuelScale > 0 ? saved.fuelScale : null);
        this.trips = new Trips(read(this.tripsFile));
        this.trips.setPrice(this.fuelPrice);
        this.tripSaved = 0;
        this.lastFuelSample = 0;
        this.history = {};
        this.historyAt = 0;
        this.page = 'engine';
        this.offset = 0;
        this.period = 'week';
        this.peaks = {};
        this.lastSae = null;
    }

    select(page) {
        if (this.page === page || !PAGES.some(([key]) => key === page)) return;
        this.page = page;
        this.offset = 0;
        this.diagnostics.reset();
        if (page === 'engine') this.peaks = {};
    }

    pause() {
        this.diagnostics.reset();
        this.peaks = {};
        this.trips.last = null;
    }

    saveSettings() {
        write(this.settingsFile, { scales: this.scales, currency: this.currency,
            fuelPrice: this.fuelPrice, fuelScale: this.flow.k });
    }

    saveTrip(now) {
        write(this.tripsFile, this.trips.toJSON());
        this.tripSaved = now;
    }

    action(id) {
        if (id.indexOf('page:') === 0) { this.select(id.slice(5)); return; }
        if (id.indexOf('period:') === 0) {
            const period = id.slice(7);
            if (PERIODS.some(([key]) => key === period)) this.period = period;
            return;
        }
        if (id === 'previous' || id === 'next') {
            this.offset = Math.max(0, this.offset + (id === 'next' ? 1 : -1));
            return;
        }
        const [key, direction] = id.split(':');
        if (this.page !== 'settings' || (direction !== '+' && direction !== '-')) return;
        const change = direction === '+' ? 1 : -1;
        if (key === 'fuelPrice') {
            this.fuelPrice = Math.round(clamp(this.fuelPrice + change * 0.05, 0, 10000) * 100) / 100;
            this.trips.setPrice(this.fuelPrice);
        } else if (key === 'currency') {
            this.currency = CURRENCY[(CURRENCY.indexOf(this.currency) + CURRENCY.length + change) % CURRENCY.length];
        } else {
            const setting = SCALES.find(([name]) => name === key);
            if (!setting) return;
            this.scales[key] = clamp(this.scales[key] + change * setting[4], setting[5], setting[6]);
        }
        this.saveSettings();
    }

    uds(id, now, age) { return this.diagnostics.reply(uds(id), now, age || 15000); }

    gearbox(now) {
        const reply = this.diagnostics.reply(GEARBOX_ID, now, 60000);
        if (!reply || reply.length < 6) return undefined;
        return Buffer.from(reply.slice(3, 6)).toString('hex').toUpperCase();
    }

    requests(now, running) {
        switch (this.page) {
        case 'engine': return ENGINE_READS.concat(running ? TRIP_FUEL : []);
        case 'fuel': return FUEL_READS.concat(running ? TRIP_FUEL : []);
        case 'trips': return running ? TRIP_FUEL : [];
        case 'transmission': {
            const variant = this.gearbox(now);
            return EGS_VARIANTS[variant] ? [GEARBOX_ID].concat(EGS_LIVE, EGS_HISTORY) : [GEARBOX_ID];
        }
        case 'details': return DETAILS_READS;
        default: return [];
        }
    }

    intake(now) {
        const iat = this.diagnostics.obdValue(0x0f, now);
        if (finite(iat)) return iat;
        const frame = this.uds(0x580f, now);
        return frame && frame[3] !== undefined ? frame[3] * 0.75 - 48 : undefined;
    }

    boost(now) {
        const diag = this.diagnostics;
        const ambient = diag.obdValue(0x33, now);
        if (!finite(ambient)) return {};
        const pair = diag.reply(obd(0x70), now, 10000);
        const high = diag.reply(obd(0x87), now, 10000);
        const pressures = [diag.obdValue(0x0b, now)];
        if (pair && pair[2] & 2) pressures.push(u16(pair, 5) / 32);
        if (pair && pair[2] & 8) pressures.push(u16(pair, 9) / 32);
        if (high && high[2] & 1) pressures.push(u16(high, 3) / 32);
        const valid = pressures.filter(finite);
        let target = u16(this.uds(0x4ab0, now), 3) / 256;
        if (!finite(target) && pair && pair[2] & 1) target = u16(pair, 3) / 32;
        if (!finite(target) && pair && pair[2] & 4) target = u16(pair, 7) / 32;
        return { actual: valid.length ? (Math.max(...valid) - ambient) / 100 : undefined,
            target: finite(target) ? (target - ambient) / 100 : undefined };
    }

    sample(key, value, now) {
        const points = this.history[key] || (this.history[key] = []);
        points.push([now, finite(value) ? value : null]);
        while (points.length && points[0][0] < now - HISTORY_WINDOW_MS) points.shift();
    }

    trace(key, now) {
        const points = (this.history[key] || []).filter(([at]) => now - at <= HISTORY_WINDOW_MS);
        if (!points.length) return [];
        const latest = points[points.length - 1][0];
        const slots = Math.round((latest - points[0][0]) / HISTORY_SAMPLE_MS) + 1;
        const values = Array(slots).fill(null);
        for (const [at, value] of points) {
            values[slots - 1 - Math.round((latest - at) / HISTORY_SAMPLE_MS)] = value;
        }
        return values;
    }

    fuel(now, values, raw) {
        const diag = this.diagnostics;
        const intake = this.intake(now);
        const ambient = finite(raw.outside) && raw.outside < 255 ? raw.outside * 0.5 - 40 : diag.obdValue(0x46, now);
        const low = diag.reply(obd(0x0a), now, 15000);
        const lp = low && low[2] !== undefined ? low[2] * 0.03 : u16(this.uds(0x58f3, now), 3) * 0.001;
        const b = this.boost(now);
        const boost = finite(b.actual) ? b.actual : parseFloat(values.boost) / (values.sae ? 14.5037738 : 1);
        return { intake, heat: intake - ambient, lp, hp: diag.obdValue(0x23, now), timing: diag.obdValue(0x0e, now),
            boost, target: b.target };
    }

    trackTrip(raw, now, speed, run) {
        if (this.lastFuelSample && now - this.lastFuelSample < 950) return;
        this.lastFuelSample = now;
        const flow = this.flow;
        const tank = finite(raw.tank) && raw.tank >= 0 && raw.tank < 255 ? raw.tank : undefined;
        const odo = finite(raw.odo) && raw.odo >= 0 && raw.odo < 16777215 ? raw.odo : undefined;
        if (finite(raw.injection) && raw.injection >= 0 && raw.injection < 65535) flow.feed(raw.injection, now);
        const volume = u16(this.uds(0x5656, now, 7000), 3) * 0.00119209 * 3.6;
        const obdFlow = this.diagnostics.obdValue(0x5e, now);
        const mass = u16(this.uds(0x4521, now, 7000), 3) * 0.1 / 0.745;
        const reference = [volume, obdFlow, mass].find((value) => finite(value) && value >= 0 && value < 200);
        if (flow.learn(reference, now)) this.saveSettings();
        const learned = finite(raw.injection) ? flow.lph(now) : undefined;
        const moving = finite(speed) && speed > 2;
        const engineOn = run === 'running' || run === 'starting';
        const lph = engineOn || moving ? (finite(learned) ? learned : reference) : 0;
        this.tripLph = lph;
        const result = this.trips.feed(now, { running: run, speed, odo, tank, lph, src: finite(learned) ? 'Vehicle' : 'Engine' });
        if (result.started || result.ended || (this.trips.cur && now - this.tripSaved >= 60000)) this.saveTrip(now);
    }

    updateTrip(raw, now, diagnostic) {
        const rpm = finite(raw.rpm) && raw.rpm < 65535 ? raw.rpm / 4 : this.diagnostics.obdValue(0x0c, now);
        const run = RUN[raw.engineRun] || (finite(rpm) ? (rpm > 300 ? 'running' : 'off') : undefined);
        const speed = finite(raw.speed) && raw.speed < 65535 ? raw.speed / 64 : this.diagnostics.obdValue(0x0d, now);
        if (diagnostic) this.diagnostics.tick(this.requests(now, run !== 'off' && !!run), now);
        this.trackTrip(raw, now, speed, run);
        return { rpm, speed };
    }

    update(values, raw, now) {
        const { rpm, speed } = this.updateTrip(raw, now, true);

        const fuel = this.fuel(now, values, raw);
        if (now - this.historyAt >= HISTORY_SAMPLE_MS) {
            this.historyAt = now;
            Object.keys(fuel).forEach((key) => this.sample(key, fuel[key], now));
        }

        const engine = Object.assign({}, values);
        const sae = values.sae;
        if (finite(rpm) && values.rpm === '--') engine.rpm = n(rpm, 'rpm');
        const torque = values.torque !== '--' ? raw.torque / 2 - 1023.5 :
            this.diagnostics.obdValue(0x62, now) * this.diagnostics.obdValue(0x63, now) / 100;
        if (values.torque === '--' && finite(torque)) engine.torque = n(sae ? torque * 0.737562149 : torque, sae ? 'lb-ft' : 'Nm');
        if (values.power === '--' && finite(torque) && finite(rpm)) engine.power = n(rpm * torque / 9549.3 * 1.341, 'hp');
        if (finite(speed) && values.speed === '--') engine.speed = n(sae ? speed * 0.621371192 : speed, sae ? 'mph' : 'km/h');
        if (finite(fuel.boost)) engine.boost = pressure(fuel.boost, sae, sae ? 1 : 2);
        if (values.oil === '--') engine.oil = temperature(this.diagnostics.obdValue(0x5c, now), sae).replace('—', '--');
        if (values.coolant === '--') engine.coolant = temperature(this.diagnostics.obdValue(0x05, now), sae).replace('—', '--');
        engine.intake = temperature(fuel.intake, sae).replace('—', '--');
        engine.heat = temperatureDifference(fuel.heat, sae).replace('—', '--');
        engine.gear = gearFrom(raw, this.diagnostics.reply(obd(0xa4), now, 15000)) || '';
        if (this.lastSae !== sae) { this.peaks = {}; this.lastSae = sae; }
        if (this.page === 'engine') PEAKS.forEach((key) => {
            const value = parseFloat(engine[key]);
            if (finite(value) && (!finite(this.peaks[key]) || value > this.peaks[key])) this.peaks[key] = value;
        });
        engine.peaks = this.peaks;
        engine.scales = this.scales;

        const frame = { page: this.page, pages: PAGES, engine };
        if (this.page === 'fuel') frame.content = this.fuelPage(fuel, sae, now);
        if (this.page === 'trips') frame.content = this.tripsPage(sae, now);
        if (this.page === 'transmission') frame.content = this.transmissionPage(sae, now);
        if (this.page === 'details') frame.content = this.detailsPage(now, raw);
        if (this.page === 'settings') frame.content = this.settingsPage();
        return frame;
    }

    fuelPage(fuel, sae, now) {
        const readings = [
            ['Intake air', temperature(fuel.intake, sae), 'intake'], ['Intake above outside', temperatureDifference(fuel.heat, sae), 'heat'],
            ['Fuel rail pressure', pressure(fuel.hp, sae, 0), 'hp'], ['Low-pressure fuel', pressure(fuel.lp, sae, 1), 'lp'],
            ['Ignition advance', n(fuel.timing, '°', 1), 'timing'], ['Boost', pressure(fuel.boost, sae, sae ? 1 : 2), 'boost', 'target'],
        ];
        return { subtitle: '5-minute history', cards: readings.map(([title, value, key, other]) => ({ title, value, metric: key,
            trace: this.trace(key, now), trace2: other ? this.trace(other, now) : undefined,
            target: other && finite(fuel.target) ? pressure(fuel.target, sae, sae ? 1 : 2) : undefined })) };
    }

    tripsPage(sae, now) {
        const trips = this.trips;
        const last = trips.cur || trips.trips[trips.trips.length - 1];
        const total = trips.total(this.period, now);
        const distance = (v) => n(sae ? v * 0.621371192 : v, sae ? 'mi' : 'km', 1);
        const volume = (v) => n(sae ? v / 3.785411784 : v, sae ? 'gal' : 'L', 2);
        const economy = (l, km) => n(sae ? (l > 0 && km >= 1 ? km / l * 2.35214583 : undefined) : per100(km, l),
            sae ? 'mpg' : 'L/100 km', 1);
        const hasFuel = (trip) => trip.l > 0 || !trip.noFuelMs;
        const summary = (tr) => [['Distance', distance(tr.km)], ['Fuel used', hasFuel(tr) ? volume(tr.l) : '—'],
            ['Average economy', hasFuel(tr) ? economy(tr.l, tr.km) : '—'], ['Fuel cost', hasFuel(tr) ? n(trips.cost(tr), this.currency, 2) : '—'],
            ['Elapsed', elapsed(tr.driveMs + tr.idleMs)], ['Idle fuel', volume(tr.lIdle)],
            ['Average speed', n(tr.driveMs + tr.idleMs > 0 ? tr.km * 3600000 / (tr.driveMs + tr.idleMs) * (sae ? 0.621371192 : 1) : undefined, sae ? 'mph' : 'km/h')],
            ['Top speed', n(sae ? tr.vmax * 0.621371192 : tr.vmax, sae ? 'mph' : 'km/h')],
            ['Odometer', finite(tr.odo0) && finite(tr.odo1) ? distance(tr.odo0) + ' - ' + distance(tr.odo1) : '—'],
            ['Tank level', finite(tr.tank0) && finite(tr.tank1) ? volume(tr.tank0) + ' - ' + volume(tr.tank1) : '—']];
        return { subtitle: 'Fuel flow  ' + n(sae ? this.tripLph / 3.785411784 : this.tripLph, sae ? 'gal/h' : 'L/h', 1),
            controls: PERIODS.map(([key, label]) => ({ id: 'period:' + key, label, selected: key === this.period })),
            cards: [{ title: trips.cur ? 'Current trip' : 'Last trip', rows: last ? summary(last) : [['Status', 'No recorded trips']] },
                { title: 'Period totals', rows: [['Trips', text(total.n)], ['Distance', distance(total.km)], ['Fuel used', volume(total.l)],
                    ['Average economy', economy(total.l, total.km)], ['Fuel cost', n(total.cost, this.currency, 2)]] },
                { title: 'Recent trips', rows: trips.trips.slice().reverse().map((trip) => {
                    const date = new Date(trip.start);
                    return [[date.getMonth() + 1, date.getDate()].join('/') + '  ' + elapsed(trip.driveMs + trip.idleMs),
                        distance(trip.km) + '  ' + volume(trip.l)];
                }) }] };
    }

    transmissionPage(sae, now) {
        const variant = this.gearbox(now);
        if (!EGS_VARIANTS[variant]) return { subtitle: 'Gearbox diagnostics', cards: [{ title: 'Transmission',
            rows: [['Variant', variant || '—'], ['Status', variant ? 'Unsupported gearbox variant' : this.diagnostics.status]] }] };
        const value = (id, keep) => {
            const req = uds(parseInt(id, 16), 0, EGS);
            const record = decodeEgs(id, this.diagnostics.reply(req, now, keep ? 600000 : 10000),
                id === '4441' && variant === '0F21E0' ? { raw: true } : undefined);
            return record.ok ? record.values : [];
        };
        const gear = value('DA2E');
        const speeds = value('DA2A');
        const engine = value('DA34')[0];
        const times = value('4441', true);
        const total = times.reduce((sum, v) => sum + v, 0);
        const ranges = [['Below 40', 0, 4], ['40 to 70', 4, 6], ['70 to 100', 6, 10], ['100 to 120', 10, 14], ['Above 120', 14, 23]];
        const limit = (label) => sae ? label.replace(/\d+/g, (v) => Math.round(Number(v) * 1.8 + 32)) + ' °F' : label + ' °C';
        const percent = (first, last) => times.slice(first, last).reduce((sum, v) => sum + v, 0) / total * 100;
        const adaptations = ['413A', '4140', '4131', '4130'].map((id) => value(id, true));
        return { subtitle: EGS_VARIANTS[variant] + '   ' + variant, cards: [
            { title: 'Live gearbox', rows: [['Gear', text(EGS_GEARS[gear[0]])], ['Selector', text(EGS_POSITIONS[gear[1]])],
                ['Oil temperature', temperature(value('6000')[0], sae)], ['Input speed', n(speeds[0], 'rpm')], ['Output speed', n(speeds[1], 'rpm')],
                ['Converter slip', variant === '0F21E0' ? 'No converter' : n(engine - speeds[0], 'rpm')], ['Lock-up', text(TCC[value('DA22')[0]])]] },
            { title: 'Clutch adaptations', rows: [].concat(...[0, 1, 2, 3, 4].map((i) => [
                ['Clutch ' + 'ABCDE'[i], n(adaptations[0][i] / 1000, 'bar', 2) + '   ' + n(adaptations[1][i], 'ms')],
                ['Evaluations (P / T)', text(adaptations[2][i]) + ' / ' + text(adaptations[3][i])],
            ])) },
            { title: 'Oil temperature history', rows: ranges.map(([label, first, last]) => [limit(label), n(percent(first, last), '%')])
                .concat([['Operating hours', n(value('6081', true)[0] / 60, 'h')]]) },
        ] };
    }

    detailsPage(now, raw) {
        const groups = ENGINE_GROUPS.map(({ group, items }) => ({ title: group, rows: items.map((item) => {
            const value = detailValue(item, this.diagnostics, now);
            return [item.name, finite(value) ? n(value, item.u, item.d) : text(value)];
        }) }));
        const stats = this.diagnostics.link && this.diagnostics.link.stats;
        groups.push({ title: 'Data links', rows: [['Diagnostic service', this.diagnostics.status],
            ['Vehicle speed (SOME/IP)', finite(raw.speed) ? 'Receiving' : 'Waiting'],
            ['Engine speed (SOME/IP)', finite(raw.rpm) ? 'Receiving' : 'Waiting'],
            ['Vbatt (LevelMonitor)', finite(raw.voltage) ? 'Receiving' : 'Waiting'],
            ['Requests sent', text(stats && stats.sent)], ['Replies', text(stats && stats.replies)],
            ['Timeouts', text(stats && stats.missed)], ['Average reply time', n(stats && stats.timed ? stats.ms / stats.timed : undefined, 'ms')]] });
        const cards = [];
        for (const group of groups) {
            for (let start = 0; start < group.rows.length; start += 8) cards.push({
                title: group.title + (start ? ' (continued)' : ''), rows: group.rows.slice(start, start + 8),
            });
        }
        const count = Math.ceil(cards.length / 3);
        this.offset = Math.min(this.offset, count - 1);
        return { subtitle: 'Engine data   ' + (this.offset + 1) + ' / ' + count,
            controls: [{ id: 'previous', label: 'Previous', disabled: this.offset === 0 },
                { id: 'next', label: 'Next', disabled: this.offset === count - 1 }],
            cards: cards.slice(this.offset * 3, this.offset * 3 + 3) };
    }

    settingsPage() {
        const rows = SCALES.map(([key, name, unit]) => [key, name, n(this.scales[key], unit, key === 'boost' ? 2 : 0)]);
        rows.push(['fuelPrice', 'Fuel price per liter', n(this.fuelPrice, this.currency, 2)], ['currency', 'Currency', this.currency]);
        return { subtitle: 'Display scales and trip costs', settings: rows };
    }
}

module.exports = { Features };
