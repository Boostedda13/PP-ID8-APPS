'use strict';

const { Recorder, makeLayer, dropLayer } = require('./kit/record');
const { RenderClient } = require('./kit/renderd');
const { ContentGrid, drawTabs, SCREEN, APP } = require('./pages');
const { METRIC_COLORS } = require('./colors');

const INSET = 40;
const KEEPALIVE_MS = 1000;
const BAR_SLOPE = 0.28;
const BAR_EDGE_LENGTH = Math.sqrt(1 + BAR_SLOPE * BAR_SLOPE);

const WHITE = '#ffffff';
const VALUE_FONT = { font: 'value' };
const INTAKE_BAR_X = 520;
const INTAKE_ROW_H = 72;

const WIDE = { labelY: 68, valueY: 95, size: 89, align: 'right', trackY: 123, trackH: 28, tickY: 196 };
const SMALL = { labelY: 52, valueY: 118, size: 70, trackY: 135, trackH: 20, tickY: 196 };
const FOOTER = { labelY: 66, valueY: 88, size: 65, align: 'right', trackY: 111, trackH: 9, tickY: 151 };
const FOOTER_READOUT = { labelY: 58, valueY: 134, size: 78 };
const INTAKE = { labelY: 52, valueY: 55, size: 50, trackY: 29, trackH: 15, tickY: 72 };
const SPEED = { labelY: 68, valueY: 179, size: 119 };

const CARDS = [
    { key: 'rpm', label: 'Engine speed', unit: 'rpm', x: 40, y: 78, w: 1780, h: 224,
        style: WIDE, ticks: [0, 2000, 4000, 6000, 8000] },
    { key: 'boost', label: 'Boost', unit: 'bar', x: 40, y: 322, w: 1780, h: 224,
        style: WIDE, ticks: [0, 0.5, 1, 1.5, 2, 2.5], saeUnit: 'psi', saeTicks: [0, 10, 20, 30, 40], saeFactor: 14.5037738 },
    { key: 'power', label: 'Power', unit: 'hp', x: 1840, y: 322, w: 490, h: 224,
        style: SMALL, ticks: [0, 250, 500] },
    { key: 'torque', label: 'Torque', unit: 'Nm', x: 2350, y: 322, w: 490, h: 224,
        style: SMALL, ticks: [0, 350, 700], saeUnit: 'lb-ft', saeTicks: [0, 250, 500], saeFactor: 0.737562149 },
    { key: 'speed', label: 'Vehicle speed', unit: 'km/h', x: 1840, y: 78, w: 1000, h: 224,
        style: SPEED, saeUnit: 'mph' },
    { key: 'oil', label: 'Engine oil', unit: '°C', x: 40, y: 566, w: 560, h: 174,
        style: FOOTER, ticks: [0, 150], saeUnit: '°F', saeTicks: [32, 302], saeFactor: 1.8, saeOffset: 32 },
    { key: 'coolant', label: 'Coolant', unit: '°C', x: 620, y: 566, w: 560, h: 174,
        style: FOOTER, ticks: [0, 130], saeUnit: '°F', saeTicks: [32, 266], saeFactor: 1.8, saeOffset: 32 },
    { key: 'intake', label: 'Intake air', unit: '°C', x: 1200, y: 566, w: 1200, h: 174,
        style: INTAKE, ticks: [0, 80], saeUnit: '°F', saeTicks: [32, 176], saeFactor: 1.8, saeOffset: 32 },
    { key: 'voltage', label: 'Vbatt', unit: 'V', x: 2420, y: 566, w: 420, h: 174, style: FOOTER_READOUT },
];

function barFraction(value, ticks) {
    return (value - ticks[0]) / (ticks[ticks.length - 1] - ticks[0]);
}

function slantedBar(canvas, x, y, width, height, fraction, color) {
    const span = (width - height * BAR_SLOPE) * fraction;
    if (!(span > 0)) return;

    // Round the four vertices by stroking an inset parallelogram with round caps.
    const corner = Math.min(3.5, height * 0.18);
    const radius = Math.min(corner, span / (2 * BAR_EDGE_LENGTH));
    // Keep a very short fill inside the track's rounded leading edge.
    const inset = radius * BAR_EDGE_LENGTH + (corner - radius) * (BAR_EDGE_LENGTH + BAR_SLOPE);
    const topX = x + inset + (height - radius) * BAR_SLOPE;
    const bottomX = x + inset + radius * BAR_SLOPE;
    const top = y + radius;
    const bottom = y + height - radius;
    const innerWidth = span - 2 * radius * BAR_EDGE_LENGTH;
    if (innerWidth < 0.001) {
        canvas.line(topX, top, bottomX, bottom, 2 * radius, color);
        return;
    }
    const corners = [[topX, top], [topX + innerWidth, top],
        [bottomX + innerWidth, bottom], [bottomX, bottom]];
    canvas.quad(corners, color);
    canvas.polyline(corners.concat([corners[0]]), 2 * radius, color);
}

function drawScale(canvas, left, y, trackW, style, ticks) {
    const trackY = y + style.trackY;
    slantedBar(canvas, left, trackY, trackW, style.trackH, 1, '#292929');
    ticks.forEach((value, index) => {
        const tickX = left + barFraction(value, ticks) * (trackW - style.trackH * BAR_SLOPE);
        const align = index === 0 ? 'left' : index === ticks.length - 1 ? 'right' : 'center';
        if (style === WIDE || style === SMALL) canvas.fillRect(tickX - 1, trackY + style.trackH + 7, 2, 8, '#8c8c8c');
        canvas.text(String(value), tickX, y + style.tickY, 26, WHITE, { align, font: 'value' });
    });
}

function drawCard(canvas, { x, y, w, h, label, style, ticks, color, intakeRows }) {
    const left = x + INSET;
    canvas.strokeRoundRect(x, y, w, h, 18, 2, '#282828');
    if (intakeRows) {
        intakeRows.forEach((row, index) => {
            const rowY = y + index * INTAKE_ROW_H;
            canvas.text(row.label, left, rowY + style.labelY, 34, row.color);
            drawScale(canvas, x + INTAKE_BAR_X, rowY, w - INTAKE_BAR_X - INSET, style, row.ticks);
        });
        return;
    }
    canvas.text(label, left, y + style.labelY, 37, color);
    if (ticks) drawScale(canvas, left, y, w - INSET * 2, style, ticks);
}

function drawValue(canvas, value, unit, size, color, left, right, baseline) {
    const text = value === '--' ? '—' : value;
    const numOptions = { font: 'num' };
    const valueWidth = canvas.textWidth(text, size, numOptions);
    const unitOffset = 18;
    const unitSize = 34;
    const unitWidth = value === '--' ? 0 : unitOffset + canvas.textWidth(unit, unitSize);
    const start = right === null ? left : right - valueWidth - unitWidth;
    canvas.text(text, start, baseline, size, WHITE, numOptions);
    if (unitWidth) canvas.text(unit, start + valueWidth + unitOffset, baseline, unitSize, color);
}

function drawProgress(canvas, value, ticks, x, y, width, height, color) {
    const fraction = Math.max(0, Math.min(1, barFraction(Number(value), ticks)));
    slantedBar(canvas, x, y, width, height, fraction, color);
}

function drawReading(canvas, { x, y, w, key, unit, style, ticks, color, intakeRows }, value, peak, gear, heat) {
    if (intakeRows) {
        const readings = [value, heat];
        intakeRows.forEach((row, index) => {
            const rowY = APP.y + y + index * INTAKE_ROW_H;
            drawValue(canvas, readings[index], unit, style.size, row.color, x + INSET, x + INTAKE_BAR_X - 27, rowY + style.valueY);
            drawProgress(canvas, readings[index], row.ticks, x + INTAKE_BAR_X, rowY + style.trackY,
                w - INTAKE_BAR_X - INSET, style.trackH, row.color);
        });
        return;
    }
    const baseline = APP.y + y + style.valueY;
    const right = style.align === 'right' ? x + w - INSET : null;
    drawValue(canvas, value, unit, style.size, color, x + INSET, right, baseline);
    if (Number.isFinite(peak)) {
        const digits = key === 'boost' ? (unit === 'psi' ? 1 : 2) : 0;
        const peakValue = peak.toFixed(digits);
        const size = style === WIDE ? 25 : 24;
        const rowY = APP.y + y + (style === WIDE ? 103 : style.labelY);
        const label = 'Peak  ';
        const peakWidth = canvas.textWidth(label, size) + canvas.textWidth(peakValue, size, VALUE_FONT);
        const peakX = style === WIDE ? x + INSET : x + w - INSET - peakWidth;
        const advance = canvas.text(label, peakX, rowY, size, color);
        canvas.text(peakValue, peakX + advance, rowY, size, WHITE, VALUE_FONT);
    }
    if (key === 'speed' && gear) {
        const edge = x + w - INSET;
        canvas.text('Gear', edge, APP.y + y + 68, 31, color, { align: 'right' });
        canvas.text(gear, edge, baseline, 78, WHITE, { align: 'right', font: 'value' });
    }
    // Keep the reading visible at its actual value when it exceeds the bar scale.
    if (ticks) drawProgress(canvas, value, ticks, x + INSET, APP.y + y + style.trackY, w - INSET * 2, style.trackH, color);
}

function inUnits(card, sae, scales) {
    const unit = sae && card.saeUnit || card.unit;
    let ticks = sae && card.saeTicks || card.ticks;
    const max = scales[card.key];
    if (ticks && Number.isFinite(max) && max !== card.ticks[card.ticks.length - 1]) {
        const endpoint = sae ? max * (card.saeFactor || 1) + (card.saeOffset || 0) : max;
        const min = ticks[0];
        const steps = ticks.length - 1;
        ticks = ticks.map((_, index) => Number((min + (endpoint - min) * index / steps).toFixed(1)));
    }
    const color = METRIC_COLORS[card.key];
    const intakeRows = card.key === 'intake' ? [
        { label: card.label, color, ticks },
        { label: 'Above outside', color: METRIC_COLORS.heat, ticks: [0, ticks[ticks.length - 1] - ticks[0]] },
    ] : null;
    return Object.assign({}, card, { unit, ticks, color, intakeRows });
}

class MetricGrid {
    constructor(scale) {
        this.scale = scale;
        this.recording = new Recorder(SCREEN.w, SCREEN.h, { textScale: scale });
        this.values = [];
        this.background = null;
        this.styleKey = '';
        this.contentKey = '';
        this.targets = [];
    }

    update(values, pages) {
        // The existing telemetry reports rounded values with a unit suffix, or '--'.
        const number = (key) => (values[key] || '--').split(' ', 1)[0];
        const numbers = CARDS.map(({ key }) => number(key));
        const heat = number('heat');
        const sae = values.sae === true;
        const scales = values.scales || {};
        const peaks = values.peaks || {};
        const styleKey = JSON.stringify([sae, scales]);
        if (styleKey !== this.styleKey) {
            this.cards = CARDS.map((card) => inUnits(card, sae, scales));
            this.dispose();
            this.background = makeLayer(SCREEN.w, APP.h, (canvas) => {
                canvas.clear('#000000');
                for (const card of this.cards) drawCard(canvas, card);
            }, this.scale);
            this.styleKey = styleKey;
        }
        const contentKey = JSON.stringify([styleKey, pages, numbers, heat, peaks, values.gear]);
        if (contentKey === this.contentKey) return false;

        const canvas = this.recording.reset().clear().blit(this.background, 0, APP.y);
        this.cards.forEach((card, index) => drawReading(canvas, card, numbers[index], peaks[card.key], values.gear, heat));
        this.targets = drawTabs(canvas, pages || [], 'engine');
        this.values = numbers;
        this.contentKey = contentKey;
        return true;
    }

    dispose() {
        if (this.background) dropLayer(this.background);
    }
}

class EngineDashboard {
    constructor(appId, onAction) {
        this.appId = appId;
        this.onAction = onAction;
        this.client = null;
        this.grid = null;
        this.frame = { page: 'engine', pages: [], engine: {} };
        this.lastFrameAt = 0;
        this.failed = false;
    }

    show() {
        if (this.failed) return;
        if (this.client) {
            // The renderer can hide the layer while the RHMI state stays open.
            if (this.client.ready && !this.client.visible) this.present();
            return;
        }
        const client = new RenderClient(this.appId);
        this.client = client;
        client.on('rendererError', (error) => {
            if (this.client === client) this.fail(error);
        });
        client.on('closed', () => {
            if (this.client === client) this.pressed = null;
        });
        client.on('ready', ({ w, h }) => {
            if (this.client !== client) return;
            try {
                const scale = Math.min(w / SCREEN.w, h / SCREEN.h);
                if (!(scale > 0)) throw new Error('Invalid renderer screen size');
                if (!this.grid || this.grid.scale !== scale) {
                    if (this.grid) this.grid.dispose();
                    this.grid = new MetricGrid(scale);
                    this.content = new ContentGrid(scale);
                }
                client.place({ x: 0, y: 0, w, h, scale,
                    ox: (w - SCREEN.w * scale) / 2, oy: (h - SCREEN.h * scale) / 2 });
                if (this.onAction) client.claim([{ x: 0, y: APP.y, w: SCREEN.w, h: APP.h }]);
                this.present();
            } catch (error) {
                this.fail(error);
            }
        });
        client.on('touch', (phase, x, y) => {
            if (this.client !== client || !this.onAction || !this.rendered) return;
            const hit = this.rendered.targets.find((target) => x >= target.x && x < target.x + target.w &&
                y >= target.y && y < target.y + target.h);
            if (phase === 'down') this.pressed = hit && hit.id;
            if (phase === 'up') {
                const pressed = this.pressed;
                this.pressed = null;
                if (hit && hit.id === pressed) this.onAction(pressed);
            }
        });
        try {
            client.connect();
        } catch (error) {
            this.fail(error);
        }
    }

    present() {
        try {
            this.sendFrame(true);
            this.client.show(true);
        } catch (error) {
            this.fail(error);
        }
    }

    hide() {
        const client = this.client;
        this.client = null;
        this.frame = { page: 'engine', pages: [], engine: {} };
        this.pressed = null;
        this.failed = false;
        if (!client) return;
        client.show(false);
        client.close();
    }

    update(view) {
        this.frame = view;
        if (!this.client || !this.client.ready || !this.client.visible) return false;
        try {
            this.sendFrame(false);
            return true;
        } catch (error) {
            this.fail(error);
            return false;
        }
    }

    sendFrame(force) {
        const view = this.frame;
        const engine = view.page === 'engine';
        const background = this.grid.background;
        const changed = engine ? this.grid.update(view.engine, view.pages) : this.content.update({
            page: view.page, pages: view.pages, content: view.content,
        });
        const rendering = engine ? this.grid : this.content;
        const now = Date.now();
        if (!force && !changed && this.rendered === rendering && now - this.lastFrameAt < KEEPALIVE_MS) return;
        this.client.frame(rendering.recording);
        this.rendered = rendering;
        if (background && background !== this.grid.background) this.client.dropLayer(background.layerId);
        this.lastFrameAt = now;
    }

    fail(error) {
        this.hide();
        this.failed = true;
        console.warn('PP DATA dashboard:', error.message);
    }
}

module.exports = { EngineDashboard, MetricGrid, SCREEN, APP };
