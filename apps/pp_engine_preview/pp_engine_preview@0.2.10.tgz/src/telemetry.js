'use strict';

const { sources } = require('./engine-config.js');

const REFRESH_MS = 500;
const ENGINE_REFRESH_MS = 100;
const STALE_MS = 5000;
const RETRY_MS = 15000;
const FAULT_SAMPLE_MAX_AGE_MS = 2000;

function numberIn(value, lower, upper) {
    return Number.isFinite(value) && value >= lower && value <= upper;
}

function currentFaultValue(sample, now) {
    return sample && now >= sample.at && now - sample.at <= FAULT_SAMPLE_MAX_AGE_MS && numberIn(sample.value, 0, 65534)
        ? sample.value : undefined;
}

function pressureUnit(raw) {
    if (raw === 'BAR' || raw === 'KPA' || raw === 'PSI') return raw;
    if (raw === 1 || raw === 2 || raw === 3) return ['BAR', 'KPA', 'PSI'][raw - 1];
    return undefined;
}

function voltage(raw) {
    if (!numberIn(raw, 6, 18000)) return undefined;
    const scaled = raw >= 5000 ? raw / 1000 : raw >= 500 ? raw / 100 : raw >= 50 ? raw / 10 : raw;
    return numberIn(scaled, 6, 18) ? scaled : undefined;
}

// Vehicle signal fields and scales follow the MIT-licensed iDrive App Kit.
function readings(raw, page = 'engine') {
    const unit = pressureUnit(raw.pressureUnit);
    const sae = unit === 'PSI';
    if (page !== 'engine' && page !== 'fuel') return { sae };
    const format = (value, digits, suffix) => value === undefined ? '--' : value.toFixed(digits) + ' ' + suffix;
    const boost = format((unit || raw.boost === 0) && numberIn(raw.boost, 0, 254) ? raw.boost * (sae ? 0.1 : 0.01) : undefined,
        sae ? 1 : 2, sae ? 'psi' : 'bar');
    if (page === 'fuel') return { sae, boost };
    const rpm = numberIn(raw.rpm, 0, 65534) ? raw.rpm / 4 : undefined;
    const torque = numberIn(raw.torque, 0, 4095) ? raw.torque / 2 - 1023.5 : undefined;
    const temperature = (value) => numberIn(value, 0, 254)
        ? (sae ? (value - 48) * 1.8 + 32 : value - 48) : undefined;
    return {
        rpm: format(rpm, 0, 'rpm'),
        boost,
        power: format(rpm === undefined || torque === undefined ? undefined : rpm * torque / 9549.3 * 1.341, 0, 'hp'),
        torque: format(sae && torque !== undefined ? torque * 0.737562149 : torque, 0, sae ? 'lb-ft' : 'Nm'),
        speed: format(numberIn(raw.speed, 0, 65534) ? raw.speed * (sae ? 0.621371192 / 64 : 1 / 64) : undefined,
            0, sae ? 'mph' : 'km/h'),
        oil: format(temperature(raw.oil), 0, sae ? 'deg F' : 'deg C'),
        coolant: format(temperature(raw.coolant), 0, sae ? 'deg F' : 'deg C'),
        voltage: format(voltage(raw.voltage), 1, 'V'),
        sae,
    };
}

class Telemetry {
    constructor(connect, onReadings) {
        this.connect = connect;
        this.onReadings = onReadings;
        this.links = sources.map((source) => ({
            source, attributes: Object.keys(source.attributes), proxy: null, pending: false, due: {}, retryAt: 0, events: {},
        }));
        this.session = null;
    }

    show(page = 'engine') {
        const rate = page === 'engine' ? ENGINE_REFRESH_MS : REFRESH_MS;
        let session = this.session;
        if (!session) {
            session = { raw: {}, timer: null, page: null, rate: 0 };
            this.session = session;
            this.links.forEach((link) => { link.due = {}; link.retryAt = 0; });
        }
        if (session.page === page) return;
        if (page === 'faults') {
            delete session.raw.rpm;
            delete session.raw.speed;
        }
        session.page = page;
        if (session.rate !== rate) {
            clearInterval(session.timer);
            session.rate = rate;
            session.timer = setInterval(() => this.refresh(session), rate);
        }
        this.refresh(session);
    }

    hide() {
        if (!this.session) return;
        clearInterval(this.session.timer);
        this.session = null;
    }

    faultBlockReason(now = Date.now()) {
        const session = this.session;
        if (!session || session.page !== 'faults') return { text: 'Open the Fault Codes tab', tone: 'warning' };
        const speed = currentFaultValue(session.raw.speed, now);
        const rpm = currentFaultValue(session.raw.rpm, now);
        if (speed === undefined || rpm === undefined) return { text: 'Waiting for live speed and RPM before clearing', tone: 'warning' };
        if (speed / 64 >= 1) return { text: 'Stop the vehicle to clear faults', tone: 'error' };
        if (rpm / 4 >= 50) return { text: 'Switch the engine off to clear faults', tone: 'error' };
        return null;
    }

    refresh(session) {
        const now = Date.now();
        const raw = {};
        for (const key of Object.keys(session.raw)) {
            const sample = session.raw[key];
            if (now - sample.at < STALE_MS) raw[key] = sample.value;
        }
        for (const link of this.links) {
            if (link.source.pages.includes(session.page)) Object.assign(raw, link.events);
        }
        this.onReadings(readings(raw, session.page), raw, now);
        if (this.session !== session) return;
        for (const link of this.links) {
            const { source } = link;
            if (link.pending || now < link.retryAt || !source.pages.includes(session.page) ||
                (source.subscribeOnly && link.proxy)) continue;
            const attributes = link.attributes.filter((name) => {
                const pages = source.fieldPages && source.fieldPages[name];
                return now >= (link.due[name] || 0) && (!pages || pages.includes(session.page));
            });
            if (attributes.length) this.poll(link, session, attributes, now);
        }
    }

    async poll(link, session, attributes, now) {
        link.pending = true;
        const source = link.source;
        const page = session.page;
        for (const name of attributes) {
            const fast = session.rate === ENGINE_REFRESH_MS && source.fast && source.fast.includes(name);
            link.due[name] = now + (fast ? ENGINE_REFRESH_MS : source.intervalMs);
        }
        try {
            if (!link.proxy) {
                link.proxy = await this.connect(source.interface, source.instance, { timeoutMs: 5000 });
            }
            if (source.subscribeOnly) {
                await Promise.all(attributes.map(async (name) => {
                    const property = link.proxy[name];
                    if (!property || typeof property.subscribe !== 'function') return;
                    try {
                        await property.subscribe((value) => {
                            if (!value) return;
                            const columns = source.attributes[name];
                            for (const key of Object.keys(columns)) link.events[key] = value[columns[key]];
                        });
                    } catch (error) {
                        // Other telemetry sources remain available when a notifier is absent.
                    }
                }));
                return;
            }
            if (this.session !== session || session.page !== page) return;
            await Promise.all(attributes.map(async (name) => {
                const property = link.proxy[name];
                if (!property || typeof property.getValue !== 'function') return;
                try {
                    const result = await property.getValue();
                    if (this.session !== session || session.page !== page) return;
                    const columns = source.attributes[name];
                    const at = page === 'faults' ? now : Date.now();
                    for (const key of Object.keys(columns)) {
                        session.raw[key] = { value: result && result[columns[key]], at };
                    }
                } catch (error) {
                    // A single missing getter does not prevent other attributes from updating.
                    if (page === 'faults' && this.session === session && session.page === page) {
                        for (const key of Object.keys(source.attributes[name])) delete session.raw[key];
                    }
                }
            }));
        } catch (error) {
            link.proxy = null;
            link.retryAt = Date.now() + RETRY_MS;
        } finally {
            link.pending = false;
        }
    }
}

module.exports = { Telemetry, readings };
