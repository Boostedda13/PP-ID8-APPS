'use strict';
module.exports = {
  "rows": {
    "rpm": "Engine speed",
    "boost": "Boost",
    "power": "Power",
    "torque": "Torque",
    "speed": "Speed",
    "oil": "Engine oil",
    "coolant": "Coolant",
    "voltage": "Supply voltage"
  },
  "sources": [
    {
      "interface": "de.bmw.infotainment.vehicle.CDS",
      "instance": "1",
      "intervalMs": 500,
      "attributes": {
        "statusEngineSpeed2": {
          "rpm": "actualValueRPMEngineCrankshaft"
        },
        "statusEngineTemperature": {
          "oil": "temperatureEngineOilDrive",
          "coolant": "temperatureEngineDrive"
        }
      }
    },
    {
      "interface": "de.bmw.infotainment.vehicle.Vehicle2",
      "instance": "1",
      "intervalMs": 500,
      "attributes": {
        "statusCarSpeed2": {
          "speed": "speedVehicleCentreOfGravity"
        }
      }
    },
    {
      "interface": "de.bmw.infotainment.drivingexcitement.FES",
      "instance": "1",
      "intervalMs": 500,
      "attributes": {
        "statusActualValueTorque2": {
          "torque": "actualValueTorqueCrankshaft"
        },
        "statusSwitchDriveDynamicSport2": {
          "boost": "displayBoostPressure"
        }
      }
    },
    {
      "interface": "de.bmw.infotainment.vehicle.Vehicle",
      "instance": "1",
      "intervalMs": 2000,
      "attributes": {
        "statusNewCurrentUnitsStatusExt": {
          "pressureUnit": "unitOfMeasurementAirPressure"
        }
      }
    },
    {
      "interface": "com.harman.infotainment.systeminfrastructure.environment.levelmonitor.LevelMonitor",
      "instance": "Inst1",
      "intervalMs": 1000,
      "attributes": {
        "systemVoltage": {
          "voltage": "value"
        }
      }
    }
  ]
};
