'use strict';

const { sources } = require('./engine-config.js');

const REFRESH_MS = 500;
const STALE_MS = 5000;
const RETRY_MS = 15000;

function numberIn(value, lower, upper) {
    return Number.isFinite(value) && value >= lower && value <= upper;
}

function pressureUnit(raw) {
    if (raw === 'BAR' || raw === 'KPA' || raw === 'PSI') return raw;
    if (raw === 1 || raw === 2 || raw === 3) return ['BAR', 'KPA', 'PSI'][raw - 1];
    return undefined;
}

function voltage(raw) {
    if (!numberIn(raw, 6, 18000)) return undefined;
    const scaled = raw >= 5000 ? raw / 1000 : raw >= 500 ? raw / 100 : raw >= 50 ? raw / 10 : raw;
    return numberIn(scaled, 6, 18) ? scaled : undefined;
}

// Vehicle signal fields and scales follow the MIT-licensed iDrive App Kit.
function readings(raw) {
    const rpm = numberIn(raw.rpm, 0, 65534) ? raw.rpm / 4 : undefined;
    const torque = numberIn(raw.torque, 0, 4095) ? raw.torque / 2 - 1023.5 : undefined;
    const unit = pressureUnit(raw.pressureUnit);
    const format = (value, digits, suffix) => value === undefined ? '--' : value.toFixed(digits) + ' ' + suffix;
    return {
        rpm: format(rpm, 0, 'rpm'),
        boost: format(unit && numberIn(raw.boost, 0, 254) ? raw.boost * (unit === 'PSI' ? 0.1 / 14.5038 : 0.01) : undefined, 2, 'bar'),
        power: format(rpm === undefined || torque === undefined ? undefined : rpm * torque / 9549.3 * 1.341, 0, 'hp'),
        torque: format(torque, 0, 'Nm'),
        speed: format(numberIn(raw.speed, 0, 65534) ? raw.speed / 64 : undefined, 0, 'km/h'),
        oil: format(numberIn(raw.oil, 0, 254) ? raw.oil - 48 : undefined, 0, 'deg C'),
        coolant: format(numberIn(raw.coolant, 0, 254) ? raw.coolant - 48 : undefined, 0, 'deg C'),
        voltage: format(voltage(raw.voltage), 1, 'V'),
    };
}

class Telemetry {
    constructor(connect, onReadings) {
        this.connect = connect;
        this.onReadings = onReadings;
        this.links = sources.map((source) => ({ source, proxy: null, pending: false, due: 0 }));
        this.session = null;
    }

    show() {
        if (this.session) return;
        const session = { raw: {}, timer: null };
        this.session = session;
        this.links.forEach((link) => { link.due = 0; });
        this.refresh(session);
        session.timer = setInterval(() => this.refresh(session), REFRESH_MS);
    }

    hide() {
        if (!this.session) return;
        clearInterval(this.session.timer);
        this.session = null;
    }

    refresh(session) {
        const now = Date.now();
        const raw = {};
        for (const key of Object.keys(session.raw)) {
            const sample = session.raw[key];
            if (now - sample.at < STALE_MS) raw[key] = sample.value;
        }
        this.onReadings(readings(raw));
        for (const link of this.links) {
            if (!link.pending && now >= link.due) this.poll(link, session);
        }
    }

    async poll(link, session) {
        link.pending = true;
        const source = link.source;
        link.due = Date.now() + source.intervalMs;
        try {
            if (!link.proxy) {
                link.proxy = await this.connect(source.interface, source.instance, { timeoutMs: 5000 });
            }
            if (this.session !== session) return;
            await Promise.all(Object.keys(source.attributes).map(async (name) => {
                const property = link.proxy[name];
                if (!property || typeof property.getValue !== 'function') return;
                try {
                    const result = await property.getValue();
                    if (this.session !== session) return;
                    const columns = source.attributes[name];
                    const at = Date.now();
                    for (const key of Object.keys(columns)) {
                        session.raw[key] = { value: result && result[columns[key]], at };
                    }
                } catch (error) {
                    // A single missing getter does not prevent other attributes from updating.
                }
            }));
        } catch (error) {
            link.proxy = null;
            link.due = Date.now() + RETRY_MS;
        } finally {
            link.pending = false;
        }
    }
}

module.exports = { Telemetry, readings };
