'use strict';

const OnlineApp = require('oap-sdk/src/core/OnlineApp.js');
const someipBuilders = require('oap-sdk/src/someip/someipBuilders');
const { rows } = require('./engine-config.js');
const { Telemetry } = require('./telemetry.js');

class EnginePage extends OnlineApp {
    constructor() {
        super();
        this.initialization = null;
        this.entryUuid = null;
        this.stopping = false;
        this.visible = false;
        this.focused = true;
        this.fields = {};
        this.painting = false;
        this.telemetry = new Telemetry(
            (name, instance, options) => someipBuilders.buildAndInitTypedProxy(name, instance, options),
            (values) => this.paint(values)
        );
        this.on('initialized', () => {
            if (this.initialization) return;
            this.initialization = this.setup().catch((error) => console.error('PP DATA setup:', error.message));
        });
        this.on('entryPointExecute', (uuid) => {
            if (!this.initialization) return;
            this.initialization.then(() => this.open(uuid))
                .catch((error) => console.error('PP DATA open:', error.message));
        });
        this.on('shutdown', () => this.stop());
        this.on('changeVisibility', (event) => {
            if (event && event.visible != null && !flag(event.visible)) this.setVisible(false);
        });
        this.on('error', (error) => console.error('PP DATA:', error.message));
    }

    async setup() {
        const rhmi = this.rhmiApplication;
        if (!rhmi) return this.initialized();

        const screen = rhmi.getByName('ENGINE');
        if (!screen) throw new Error('ENGINE state unavailable');
        await screen.updateResources();
        for (const key of Object.keys(rows)) {
            const component = rhmi.getByName('METRIC_' + key.toUpperCase());
            if (component) this.fields[key] = { component, shown: null };
        }
        screen.on('visible', (event) => this.setVisible(event && flag(event.visible)));
        screen.on('focus', (event) => {
            this.focused = !!(event && flag(event.focus));
            this.updateTelemetry();
        });

        const descriptor = this.appDescription.application.entryPoints[0];
        const entry = this.getEntryPoints().find((item) => item.getDescription().uuid === descriptor.uuid);
        if (entry) {
            await entry.init();
            await rhmi.mapEntryState(descriptor.uuid, screen);
            try {
                await entry.entryPoint.setText(descriptor.textId);
                await entry.entryPoint.setIcon(descriptor.icon);
            } catch (error) {
                console.warn('PP DATA tile resources:', error.message);
            }
            await entry.setAvailability('ENABLED');
            this.entryUuid = descriptor.uuid;
        }

        const lastEntry = this.getLastExecutedEntryPointUuid && this.getLastExecutedEntryPointUuid();
        const visibility = this.getVisibilityData && this.getVisibilityData();
        if (lastEntry || (visibility && visibility.visible)) {
            try {
                await this.registerActive();
            } catch (error) {
                console.warn('PP DATA active status:', error.message);
            }
        }
        await this.initialized();
        if (lastEntry) await this.open(lastEntry);
    }

    async open(uuid) {
        if (this.stopping || !this.entryUuid || uuid !== this.entryUuid) return;
        await this.rhmiApplication.openEntryState(uuid);
    }

    setVisible(visible) {
        this.visible = !!visible;
        if (this.visible) this.focused = true;
        this.updateTelemetry();
    }

    updateTelemetry() {
        if (this.visible && this.focused && !this.stopping) this.telemetry.show();
        else this.telemetry.hide();
    }

    async paint(values) {
        if (this.painting) return;
        this.painting = true;
        try {
            await Promise.all(Object.keys(this.fields).map(async (key) => {
                const field = this.fields[key];
                const text = rows[key] + '  ' + values[key];
                if (field.shown === text) return;
                try {
                    await field.component.setValue(0, 'Text', text, 'Text');
                    field.shown = text;
                } catch (error) {
                    // The state can disappear while the SDK is updating a cell.
                }
            }));
        } finally {
            this.painting = false;
        }
    }

    async stop() {
        if (this.stopping) return;
        this.stopping = true;
        this.telemetry.hide();
        try {
            if (this.initialization) await this.initialization;
            await this.destroyBundles();
        } catch (error) {
            console.error('PP DATA shutdown:', error.message);
        }
        process.exit(0);
    }
}

const flag = (value) => value === true || value === 1 || value === 'true' || value === '1';
const app = new EnginePage();
app.start().catch((error) => console.error('PP DATA start:', error.message));
