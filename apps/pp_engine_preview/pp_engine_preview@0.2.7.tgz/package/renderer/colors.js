'use strict';

// Saturated colors with lightness high enough for small text on black.
const METRIC_COLORS = {
    rpm: '#b34fff', boost: '#00d9ff', power: '#ff3b9e', torque: '#ffb000', speed: '#529aff',
    oil: '#ff303b', coolant: '#00e676', intake: '#00d6b7', voltage: '#f5f000',
    heat: '#ff7a00', hp: '#ff3b9e', lp: '#ffb000', timing: '#b34fff', flow: '#00e676',
};

const PAGE_COLORS = {
    fuel: '#00d6b7', transmission: '#ffb000',
    details: '#b34fff', settings: '#00d9ff',
};

module.exports = { METRIC_COLORS, PAGE_COLORS };
